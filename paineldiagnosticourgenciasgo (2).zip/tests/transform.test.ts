import { readFileSync } from "node:fs";
import path from "node:path";
import Papa from "papaparse";
import { describe, expect, it } from "vitest";
import { classificarDisponibilidade, transformarLinhas, type LinhaBruta } from "../src/lib/transform";
import { apenasConsolidados, contarCnesDistintos, contarMunicipiosDistintos } from "../src/lib/indicadores";

function carregarLinhasReferencia(): LinhaBruta[] {
  const csv = readFileSync(path.join(process.cwd(), "scripts/fixtures/planilha-referencia.csv"), "utf-8");
  const parse = Papa.parse<LinhaBruta>(csv, { header: true, skipEmptyLines: false });
  return parse.data;
}

describe("transformarLinhas — planilha de referência real", () => {
  const { registros, linhasRecebidas, registrosValidos, registrosExcluidos } = transformarLinhas(carregarLinhasReferencia());

  it("processa as 172 respostas válidas da planilha, sem exclusões", () => {
    expect(linhasRecebidas).toBe(172);
    expect(registrosValidos).toBe(172);
    expect(registrosExcluidos).toBe(0);
  });

  it("identifica 144 municípios distintos, batendo com a nota técnica do prompt mestre", () => {
    expect(contarMunicipiosDistintos(registros)).toBe(144);
  });

  it("identifica 168 CNES distintos", () => {
    expect(contarCnesDistintos(registros)).toBe(168);
  });

  it("nunca inclui o campo 'Responsável pelo preenchimento' no registro anonimizado", () => {
    for (const r of registros) {
      expect(r.campos["responsavel_preenchimento"]).toBeUndefined();
      expect(Object.keys(r.campos)).not.toContain("Responsável pelo preenchimento");
    }
  });

  it("sinaliza duplicidade de CNES sem somar automaticamente (4 CNES duplicados = 8 linhas sinalizadas)", () => {
    const duplicados = registros.filter((r) => r.duplicadoCnes);
    expect(duplicados.length).toBe(8);
    const consolidados = apenasConsolidados(registros);
    expect(consolidados.length).toBe(168); // 172 - 4 respostas mais antigas descartadas da visão consolidada
  });

  it("sinaliza a categoria residual 'Opção 8' sem descartar o registro", () => {
    const residuais = registros.filter((r) => r.classificacaoResidual);
    expect(residuais.length).toBe(2);
    for (const r of residuais) {
      expect(r.classificacao).toBe("Opção 8");
      expect(r.alertas.some((a) => a.tipo === "categoria_residual")).toBe(true);
    }
  });

  it("preserva Goiânia como o município com mais respostas (12), seguido de Senador Canedo (4)", () => {
    const mapa = new Map<string, number>();
    for (const r of registros) mapa.set(r.municipio, (mapa.get(r.municipio) ?? 0) + 1);
    expect(mapa.get("Goiânia")).toBe(12);
    expect(mapa.get("Senador Canedo")).toBe(4);
  });

  it("trata zero como valor válido em campos numéricos de leitos", () => {
    const comLeitoZero = registros.find((r) => r.campos["leitos_sus_cirurgico"] === 0);
    expect(comLeitoZero).toBeDefined();
  });
});

describe("classificarDisponibilidade", () => {
  it("classifica número > 0 como verde e 0 como vermelho", () => {
    expect(classificarDisponibilidade(3)).toBe("verde");
    expect(classificarDisponibilidade(0)).toBe("vermelho");
  });
  it("classifica null/undefined como cinza (não informado)", () => {
    expect(classificarDisponibilidade(null)).toBe("cinza");
  });
  it("classifica expressões de ausência (com acento) como vermelho, não cinza", () => {
    expect(classificarDisponibilidade("Não possui")).toBe("vermelho");
    expect(classificarDisponibilidade("Não Oferta o Serviço")).toBe("vermelho");
  });
  it("classifica 'Sim' como verde e 'Não' como vermelho", () => {
    expect(classificarDisponibilidade("Sim")).toBe("verde");
    expect(classificarDisponibilidade("Não")).toBe("vermelho");
  });
  it("classifica disponibilidade 24h presencial como verde e sobreaviso como amarelo", () => {
    expect(classificarDisponibilidade("Disponibilidade 24h (Presencial)")).toBe("verde");
    expect(classificarDisponibilidade("Disponibilidade (Sobreaviso)")).toBe("amarelo");
  });
});
