import { describe, expect, it } from "vitest";
import {
  chaveNormalizada,
  ehValorExtremo,
  indicaAusencia,
  limparCnes,
  parseCarimbo,
  parseDuracaoTexto,
  parseMisto,
  parseNumero,
} from "../src/lib/clean";

describe("parseCarimbo", () => {
  it("converte carimbo do Google Forms (dd/mm/aaaa HH:MM:SS) para ISO", () => {
    expect(parseCarimbo("11/05/2026 14:47:52")).toBe("2026-05-11T14:47:52");
  });
  it("retorna null para valores vazios ou inválidos", () => {
    expect(parseCarimbo("")).toBeNull();
    expect(parseCarimbo(undefined)).toBeNull();
    expect(parseCarimbo("não é uma data")).toBeNull();
  });
});

describe("limparCnes", () => {
  it("preserva zeros à esquerda e não sinaliza CNES de 7 dígitos", () => {
    expect(limparCnes("0431451")).toEqual({ cnes: "0431451", atipico: false });
  });
  it("remove sufixo decimal do Excel", () => {
    expect(limparCnes("2382466.0")).toEqual({ cnes: "2382466", atipico: false });
  });
  it("sinaliza CNES com dígitos atípicos", () => {
    expect(limparCnes("23394663").atipico).toBe(true); // 8 dígitos
    expect(limparCnes("abc123").atipico).toBe(true);
  });
});

describe("parseNumero", () => {
  it("trata zero como valor válido", () => {
    expect(parseNumero("0")).toBe(0);
    expect(parseNumero("00")).toBe(0);
  });
  it("retorna null para vazio ou não numérico", () => {
    expect(parseNumero("")).toBeNull();
    expect(parseNumero(undefined)).toBeNull();
    expect(parseNumero("abc")).toBeNull();
  });
});

describe("parseMisto", () => {
  it("interpreta número quando possível", () => {
    expect(parseMisto("3")).toEqual({ numero: 3, texto: null, original: "3" });
  });
  it("preserva o texto original quando não numérico", () => {
    expect(parseMisto("Não dispõe da especialidade")).toEqual({
      numero: null,
      texto: "Não dispõe da especialidade",
      original: "Não dispõe da especialidade",
    });
  });
});

describe("parseDuracaoTexto", () => {
  it("interpreta 'Xh' como número de horas", () => {
    expect(parseDuracaoTexto("12h")).toEqual({ numero: 12, texto: null, original: "12h" });
  });
  it("preserva texto de ausência", () => {
    const r = parseDuracaoTexto("Não dispõe da especialidade");
    expect(r.numero).toBeNull();
    expect(r.texto).toBe("Não dispõe da especialidade");
  });
});

describe("indicaAusencia", () => {
  it("reconhece expressões de ausência com e sem acento", () => {
    expect(indicaAusencia("Não possui")).toBe(true);
    expect(indicaAusencia("Não Oferta o Serviço")).toBe(true);
    expect(indicaAusencia("Não disponível")).toBe(true);
    expect(indicaAusencia("Não dispõe da especialidade")).toBe(true);
  });
  it("não sinaliza valores positivos", () => {
    expect(indicaAusencia("Própria")).toBe(false);
    expect(indicaAusencia("Sim")).toBe(false);
    expect(indicaAusencia("24 horas/dia")).toBe(false);
  });
});

describe("chaveNormalizada", () => {
  it("remove acentos, espaços extras e caixa", () => {
    expect(chaveNormalizada("  Goiânia  ")).toBe("goiania");
    expect(chaveNormalizada("São João D'Aliança")).toBe("sao joao d'alianca");
  });
});

describe("ehValorExtremo", () => {
  it("sinaliza apenas acima do limite informado", () => {
    expect(ehValorExtremo(5, 30)).toBe(false);
    expect(ehValorExtremo(400, 30)).toBe(true);
  });
});
