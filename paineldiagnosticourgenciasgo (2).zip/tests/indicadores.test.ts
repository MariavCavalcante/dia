import { describe, expect, it } from "vitest";
import { transformarLinhas, type LinhaBruta } from "../src/lib/transform";
import {
  aplicarFiltros,
  disponibilidadeNumerica,
  divergenciaLeitosPorTipo,
  estatisticaNumerica,
  respostasPorMunicipio,
  somarCampoNumerico,
} from "../src/lib/indicadores";

function linha(overrides: Partial<Record<string, string>> = {}): LinhaBruta {
  return {
    "Carimbo de data/hora": "11/05/2026 10:00:00",
    Município: "Cidade Teste",
    "Responsável pelo preenchimento": "Fulano de Tal",
    "Nome da Unidade de Saúde": "Hospital Teste",
    "Número do CNES": "1234567",
    "Classificação do Estabelecimento": "Hospital Geral",
    ...overrides,
  } as LinhaBruta;
}

describe("respostasPorMunicipio", () => {
  it("ordena do maior para o menor e depois alfabeticamente em empate", () => {
    const { registros } = transformarLinhas([
      linha({ Município: "Beta", "Número do CNES": "1111111" }),
      linha({ Município: "Alfa", "Número do CNES": "2222222" }),
      linha({ Município: "Alfa", "Número do CNES": "3333333" }),
    ]);
    const ranking = respostasPorMunicipio(registros);
    expect(ranking[0].municipio).toBe("Alfa");
    expect(ranking[0].quantidade).toBe(2);
    expect(ranking[1].municipio).toBe("Beta");
  });
});

describe("aplicarFiltros", () => {
  const { registros } = transformarLinhas([
    linha({ Município: "Alfa", "Número do CNES": "1111111", "Classificação do Estabelecimento": "Hospital Geral" }),
    linha({ Município: "Beta", "Número do CNES": "2222222", "Classificação do Estabelecimento": "Unidade Mista" }),
  ]);

  it("filtra por município normalizado", () => {
    const filtrados = aplicarFiltros(registros, { municipio: "alfa" });
    expect(filtrados).toHaveLength(1);
    expect(filtrados[0].municipio).toBe("Alfa");
  });

  it("filtra por texto de busca em todos os campos", () => {
    const filtrados = aplicarFiltros(registros, { buscaTexto: "unidade mista", buscaCampo: "classificacao" });
    expect(filtrados).toHaveLength(1);
    expect(filtrados[0].municipio).toBe("Beta");
  });

  it("retorna vazio quando nenhum registro casa com o filtro", () => {
    expect(aplicarFiltros(registros, { municipio: "inexistente" })).toHaveLength(0);
  });
});

describe("somarCampoNumerico e divergenciaLeitosPorTipo", () => {
  it("soma zero como valor válido e calcula a diferença SUS - CNES", () => {
    const { registros } = transformarLinhas([
      linha({
        "Número do CNES": "1111111",
        "Informe o número de leitos operacionais disponíveis para o SUS. [Cirúrgico]": "0",
        "Informe o número de leitos Cadastrados no CNES. [Cirúrgico]": "5",
      }),
    ]);
    expect(somarCampoNumerico(registros, "leitos_sus_cirurgico")).toBe(0);
    const divergencia = divergenciaLeitosPorTipo(registros);
    const cirurgico = divergencia.find((d) => d.tipo === "Cirúrgico")!;
    expect(cirurgico.operacionalSus).toBe(0);
    expect(cirurgico.cadastradoCnes).toBe(5);
    expect(cirurgico.diferenca).toBe(-5);
  });
});

describe("disponibilidadeNumerica", () => {
  it("usa como denominador apenas quem respondeu o campo", () => {
    const { registros } = transformarLinhas([
      linha({ "Número do CNES": "1111111", "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Leitos]": "3" }),
      linha({ "Número do CNES": "2222222", "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Leitos]": "0" }),
    ]);
    const d = disponibilidadeNumerica(registros, "equip_leitos_sala_emergencia", "Leitos");
    expect(d.comResposta).toBe(2);
    expect(d.disponiveis).toBe(1);
    expect(d.percentual).toBe(0.5);
  });
});

describe("estatisticaNumerica", () => {
  it("calcula média, mediana, mínimo e máximo ignorando campos sem resposta", () => {
    const { registros } = transformarLinhas([
      linha({ "Número do CNES": "1111111", 'Qual a frequência média de recebimento de pacientes por dia via "Vaga Zero"? ': "10" }),
      linha({ "Número do CNES": "2222222", 'Qual a frequência média de recebimento de pacientes por dia via "Vaga Zero"? ': "0" }),
      linha({ "Número do CNES": "3333333", 'Qual a frequência média de recebimento de pacientes por dia via "Vaga Zero"? ': "20" }),
    ]);
    const stats = estatisticaNumerica(registros, "vaga_zero_frequencia");
    expect(stats.comResposta).toBe(3);
    expect(stats.media).toBe(10);
    expect(stats.mediana).toBe(10);
    expect(stats.minimo).toBe(0);
    expect(stats.maximo).toBe(20);
  });
});
