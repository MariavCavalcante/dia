// Passo de build usado apenas por `npm run build:demo`. O instantâneo real da
// planilha (src/data/dataset-preview.json) tem ~1MB — como JSON, é bastante
// repetitivo (117 campos por registro, mesmos nomes de chave repetidos em
// cada um dos 172 registros), então comprime muito bem com gzip. Embutir a
// versão comprimida no bundle (em vez do JSON puro) é o que permite o arquivo
// HTML final ficar pequeno o suficiente para caber com folga no limite de
// tamanho de URL do Chromium (~2.097.152 caracteres) — relevante quando o
// HTML é pré-visualizado via uma URL "data:" (por exemplo, num iframe de
// preview embutido), e não apenas aberto localmente com file://.
import { readFileSync, writeFileSync } from "node:fs";
import { gzipSync } from "node:zlib";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const origem = path.join(__dirname, "../src/data/dataset-preview.json");
const destino = path.join(__dirname, "../src/data/dataset-preview.gzip.ts");

const json = readFileSync(origem, "utf-8");
const comprimido = gzipSync(Buffer.from(json, "utf-8"), { level: 9 });
const base64 = comprimido.toString("base64");

writeFileSync(
  destino,
  `// GERADO AUTOMATICAMENTE por scripts/comprimir-dataset-preview.mjs — não editar à mão.
// Fonte: src/data/dataset-preview.json (${json.length.toLocaleString("pt-BR")} bytes),
// comprimido com gzip para ${comprimido.length.toLocaleString("pt-BR")} bytes
// (${Math.round((1 - comprimido.length / json.length) * 100)}% menor). Descomprimido em
// tempo de execução por src/hooks/useDatasetPreview.ts via DecompressionStream.
export const DATASET_PREVIEW_GZIP_BASE64 = "${base64}";
`,
  "utf-8"
);

console.log(
  `dataset-preview.gzip.ts gerado: ${json.length.toLocaleString("pt-BR")} bytes -> ${comprimido.length.toLocaleString(
    "pt-BR"
  )} bytes comprimidos (${base64.length.toLocaleString("pt-BR")} em base64, ${Math.round(
    (1 - comprimido.length / json.length) * 100
  )}% de redução).`
);
