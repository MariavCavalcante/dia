"""
Gera src/lib/dictionary.generated.ts a partir da planilha real de referência
(scripts/fixtures/planilha-referencia.csv), garantindo que cada cabeçalho
original usado no dicionário de dados é copiado literalmente do arquivo-fonte
(sem digitação manual, evitando erros de acentuação/espaço que quebrariam o
casamento de colunas em produção).

Uso único de desenvolvimento (não roda em produção). Reexecutar apenas se a
estrutura de colunas da planilha mudar.
"""
import pandas as pd
import json

df = pd.read_csv("scripts/fixtures/planilha-referencia.csv", dtype=str)
df.columns = [c for c in df.columns]  # preserva exatamente como veio
headers = list(df.columns)

# Sub-itens (grupos) em ordem estável para cada bloco de campos entre colchetes
LEITOS_TIPOS = ["Cirúrgico", "Clinico", "Obstétrico", "Pediátrico"]
EQUIP_ITENS = [
    "Leitos", "Pontos de Oxigênio (Rede/Fluxômetro)", "Pontos de Vácuo (Rede/Vacuômetro)",
    "Pontos de Ar Comprimido Medicinal", "Cilindros de O2 de Transporte (Carga Cheia)",
    "Cilindros de Reserva", "Tomadas de Emergência (mín. 4 por leito)",
    "Monitor Multiparamétrico (com ECG, Oximetria, PNI)", "Ventilador Mecânico Pulmonar (VMP)",
    "Desfibrilador / Cardioversor com Bateria e Pás", "Bomba de Infusão (mínimo 02 por leito)",
    "Carro de Emergência (Lacrado e Conferido)", "Aspirador de Secreções (Portátil ou de Parede)",
    "Kit Laringoscópio Completo (Cabos e Lâminas)", "Ambu (Bolsa-Válvula-Máscara) com reservatório",
    "Estetoscópio e Esfigmomanômetro",
]
EQUIP_KEYS = [
    "leitos_sala_emergencia", "pontos_oxigenio", "pontos_vacuo", "pontos_ar_comprimido",
    "cilindros_o2_transporte", "cilindros_reserva", "tomadas_emergencia", "monitor_multiparametrico",
    "ventilador_mecanico", "desfibrilador", "bomba_infusao", "carro_emergencia",
    "aspirador_secrecoes", "kit_laringoscopio", "ambu", "estetoscopio_esfigmomanometro",
]
IMAGEM_APARELHOS = ["Tomografia", "Ressonância", "Angiógrafo", "USG com Doppler", "Aparelho de RX"]
IMAGEM_KEYS = ["tomografia", "ressonancia", "angiografo", "usg_doppler", "raio_x"]
ESPECIALIDADES = [
    "Clínica Médica", "Pediatria", "Cirurgia Geral", "Ginecologia/Obstetrícia", "Neurocirurgia",
    "Cardiologia", "Cirurgia Vascular", "Ortopedia", "Urologia",
]
ESP_KEYS = [
    "clinica_medica", "pediatria", "cirurgia_geral", "ginecologia_obstetricia", "neurocirurgia",
    "cardiologia", "cirurgia_vascular", "ortopedia", "urologia",
]

entries = []

def add(key, header, eixo, indicador, tipo, grupo=None, unidade=None, categorias=None, regra="", viz=""):
    assert header in headers, f"Cabeçalho não encontrado na planilha: {header!r}"
    entries.append({
        "key": key, "header": header, "eixo": eixo, "indicador": indicador,
        "grupo": grupo, "tipo": tipo, "unidade": unidade, "categorias": categorias,
        "regra": regra, "viz": viz,
    })

# ---------- Campos base / identificação ----------
add("carimbo", "Carimbo de data/hora", "identificacao", "Carimbo de data/hora", "data",
    regra="Referência de inclusão e ordenação; linhas sem carimbo são descartadas.", viz="—")
add("municipio", "Município", "identificacao", "Município", "texto",
    regra="Normalizar espaços/capitalização apenas na apresentação; manter original para auditoria.", viz="Ranking, busca")
add("responsavel_preenchimento", "Responsável pelo preenchimento", "identificacao", "Responsável pelo preenchimento", "texto_pessoal",
    regra="Dado pessoal. Nunca exposto no painel público, em exportações, tooltips ou URLs.", viz="—")
add("unidade", "Nome da Unidade de Saúde", "identificacao", "Nome da Unidade de Saúde", "texto",
    regra="Normalizar espaços/capitalização na apresentação; validar preferencialmente pelo CNES.", viz="Busca, tabela")
add("cnes", "Número do CNES", "identificacao", "Número do CNES", "texto",
    regra="Tratado como texto; remove sufixo decimal do Excel sem eliminar zeros à esquerda; sinaliza dígitos atípicos.", viz="Busca, tabela")
add("classificacao", "Classificação do Estabelecimento", "identificacao", "Classificação do Estabelecimento", "categoria",
    categorias=["Hospital Geral", "Pronto Atendimento-UPA 24h", "Unidade Mista", "Pronto Socorro Geral",
                "Pronto Socorro Especializado", "Hospital Especializado", "Opção 8"],
    regra="'Opção 8' é categoria residual sinalizada para revisão institucional.", viz="Distribuição (barras/rosca)")

# ---------- Leitos ----------
for tipo in LEITOS_TIPOS:
    key_tipo = {"Cirúrgico": "cirurgico", "Clinico": "clinico", "Obstétrico": "obstetrico", "Pediátrico": "pediatrico"}[tipo]
    add(f"leitos_sus_{key_tipo}", f"Informe o número de leitos operacionais disponíveis para o SUS. [{tipo}]",
        "leitos", f"Leitos operacionais SUS — {tipo}", "numero", grupo=tipo, unidade="leitos",
        regra="Soma de valores numéricos válidos; zero é valor válido.", viz="Ranking, divergência")
for tipo in LEITOS_TIPOS:
    key_tipo = {"Cirúrgico": "cirurgico", "Clinico": "clinico", "Obstétrico": "obstetrico", "Pediátrico": "pediatrico"}[tipo]
    add(f"leitos_cnes_{key_tipo}", f"Informe o número de leitos Cadastrados no CNES. [{tipo}]",
        "leitos", f"Leitos cadastrados no CNES — {tipo}", "numero", grupo=tipo, unidade="leitos",
        regra="Soma de valores numéricos válidos; zero é valor válido.", viz="Ranking, divergência")

# ---------- Sala de emergência / equipamentos ----------
for item, key in zip(EQUIP_ITENS, EQUIP_KEYS):
    add(f"equip_{key}", f"Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [{item}]",
        "equipamentos", item, "numero", unidade="unidades",
        regra="Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
        viz="Matriz de disponibilidade, barras")

# ---------- Diagnóstico por imagem ----------
for ap, key in zip(IMAGEM_APARELHOS, IMAGEM_KEYS):
    add(f"img_{key}_quantidade", f"Quantidade de Aparelhos [{ap}]", "imagem", ap, "numero", grupo="Quantidade",
        unidade="aparelhos", regra="Zero é valor válido (unidade sem aparelho).", viz="Barras")
    add(f"img_{key}_funcionamento", f"Funcionamento do serviço (8/12/24h) [{ap}]", "imagem", ap, "categoria",
        grupo="Funcionamento", categorias=["Não possui", "08 horas/dia", "12 horas/dia", "24 horas/dia"],
        regra="Categórico; 'Não possui' tratado como ausência de serviço.", viz="Barras empilhadas")
    add(f"img_{key}_laudos", f"Emissão de Laudos (Presencial/Telemedicina) [{ap}]", "imagem", ap, "categoria",
        grupo="Emissão de laudos", categorias=["Não Oferta o Serviço", "Presencial", "Telemedicina"],
        regra="Categórico; usado para calcular ausência de serviço.", viz="Barras empilhadas")
    add(f"img_{key}_local", f"Local de Instalação do equipamento [{ap}]", "imagem", ap, "categoria",
        grupo="Local de instalação", categorias=["Não Oferta o Serviço", "Na Unidade", "Outra unidade"],
        regra="Separa oferta própria, oferta em outra unidade e ausência de serviço.", viz="Barras empilhadas")

# ---------- Especialidades médicas ----------
for esp, key in zip(ESPECIALIDADES, ESP_KEYS):
    add(f"esp_{key}_plantao24h", f"Informe a quantidade de especialistas na escala por plantão (24h). [{esp}]",
        "especialidades", esp, "misto_numero_texto", grupo="Plantão 24h",
        regra="Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza.", viz="Barras, lacunas")
    add(f"esp_{key}_presencial", f"Quantidade de especialistas em regime presencial [{esp}]",
        "especialidades", esp, "numero", grupo="Presencial", unidade="profissionais",
        regra="Numérico; zero é valor válido.", viz="Barras empilhadas por regime")
    add(f"esp_{key}_sobreaviso", f"Quantidade de especialistas em regime de Sobreaviso [{esp}]",
        "especialidades", esp, "numero", grupo="Sobreaviso", unidade="profissionais",
        regra="Numérico; zero é valor válido.", viz="Barras empilhadas por regime")
    add(f"esp_{key}_telemedicina", f"Quantidade de especialistas em regime de Telemedicina [{esp}]",
        "especialidades", esp, "numero", grupo="Telemedicina", unidade="profissionais",
        regra="Numérico; zero é valor válido.", viz="Barras empilhadas por regime")
    add(f"esp_{key}_carga_horaria", f"Carga Horária dos profissionais especialistas [{esp}]",
        "especialidades", esp, "duracao_texto", grupo="Carga horária",
        categorias=["4h", "6h", "8h", "12h", "24h", "Não dispõe da especialidade"],
        regra="Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência.", viz="Tabela, carga horária por especialidade")

# ---------- Capacidade de resposta cardiovascular ----------
add("cv_trombolise", "Capacidade de Resposta Cardiovascular [Realiza Trombólise]", "capacidade_resposta",
    "Realiza Trombólise", "categoria", grupo="Cardiovascular", categorias=["Própria", "Terceirizada", "Não possui"],
    regra="Categórico institucional.", viz="Semáforo, barras")
add("cv_hemodinamica", "Capacidade de Resposta Cardiovascular [Hemodinâmica (Cineangiocoronariografia)]",
    "capacidade_resposta", "Hemodinâmica (Cineangiocoronariografia)", "categoria", grupo="Cardiovascular",
    categorias=["Própria", "Terceirizada", "Não possui"], regra="Categórico institucional.", viz="Semáforo, barras")
add("cv_angioplastia", "Capacidade de Resposta Cardiovascular [Realiza Angioplastia Primária (24h)]",
    "capacidade_resposta", "Realiza Angioplastia Primária (24h)", "categoria", grupo="Cardiovascular",
    categorias=["Própria", "Terceirizada", "Não possui"], regra="Categórico institucional.", viz="Semáforo, barras")

# ---------- AVC / DRC ----------
h_avc = "Capacidade de resposta - Acidente Vascular Cerebral (AVC) e Doença Renal Crônica (DRC) [A unidade possui protocolo institucional de trombólise para AVC Isquêmico (AVCi) com disponibilidade de trombolítico e suporte de neuroimagem 24h?]"
h_hemo_uti = "Capacidade de resposta - Acidente Vascular Cerebral (AVC) e Doença Renal Crônica (DRC) [A unidade oferece suporte de Hemodiálise em ambiente de UTI?]"
h_hemo_int = "Capacidade de resposta - Acidente Vascular Cerebral (AVC) e Doença Renal Crônica (DRC) [A unidade possui capacidade para Hemodiálise (máquinas portáteis) em unidades de internação/enfermaria?]"
CAT_DISP = ["Disponibilidade 24h (Presencial)", "Disponibilidade (Sobreaviso)", "Não disponível"]
add("avc_protocolo_trombolise", h_avc, "capacidade_resposta", "Protocolo de trombólise para AVC isquêmico com neuroimagem 24h",
    "categoria", grupo="AVC / DRC", categorias=CAT_DISP, regra="Categórico institucional.", viz="Semáforo")
add("drc_hemodialise_uti", h_hemo_uti, "capacidade_resposta", "Hemodiálise em ambiente de UTI",
    "categoria", grupo="AVC / DRC", categorias=CAT_DISP, regra="Categórico institucional.", viz="Semáforo")
add("drc_hemodialise_internacao", h_hemo_int, "capacidade_resposta", "Hemodiálise em unidades de internação/enfermaria",
    "categoria", grupo="AVC / DRC", categorias=CAT_DISP, regra="Categórico institucional.", viz="Semáforo")

# ---------- Saúde mental ----------
add("sm_leitos_especificos", "A unidade dispõe de leitos específicos para internação/retaguarda em Saúde Mental?",
    "capacidade_resposta", "Leitos específicos para Saúde Mental", "sim_nao", grupo="Saúde mental",
    categorias=["Sim", "Não"], regra="Sim/Não.", viz="Semáforo")
add("sm_protocolo_crise", "Possui protocolo institucional para atendimento de crises ou surtos psicóticos (incluindo contenção física e química)? ",
    "capacidade_resposta", "Protocolo para crises/surtos psicóticos", "sim_nao", grupo="Saúde mental",
    categorias=["Sim", "Não"], regra="Sim/Não.", viz="Semáforo")

# ---------- Maternidade / neonatal ----------
add("maternidade_perfil", "Qual o perfil da maternidade/centro obstétrico da unidade? ", "capacidade_resposta",
    "Perfil da maternidade/centro obstétrico", "categoria", grupo="Maternidade",
    categorias=["Alto Risco", "Baixo Risco / Risco Habitual", "Unidade sem serviço de obstetrícia (Não realiza partos)"],
    regra="Categórico institucional.", viz="Distribuição")
add("incubadora_transporte", "A unidade possui Incubadora de Transporte equipada com ventilador mecânico pulmonar em pleno funcionamento? ",
    "capacidade_resposta", "Incubadora de transporte com ventilador mecânico", "sim_nao", grupo="Maternidade",
    categorias=["Sim", "Não"], regra="Sim/Não.", viz="Semáforo")

# ---------- Apoio ao leite humano ----------
add("leite_banco", "Estrutura de Apoio Nutricional (Leite Humano) [Banco de Leite Humano (Processamento e Distribuição)]",
    "capacidade_resposta", "Banco de Leite Humano", "sim_nao", grupo="Leite humano", categorias=["Sim", "Não"],
    regra="Sim/Não.", viz="Semáforo")
add("leite_posto", "Estrutura de Apoio Nutricional (Leite Humano) [Posto de Coleta de Leite Humano (Apenas coleta e armazenamento)]",
    "capacidade_resposta", "Posto de Coleta de Leite Humano", "sim_nao", grupo="Leite humano", categorias=["Sim", "Não"],
    regra="Sim/Não.", viz="Semáforo")
add("leite_nenhum", "Estrutura de Apoio Nutricional (Leite Humano) [Não possui estrutura específica]",
    "capacidade_resposta", "Sem estrutura específica de apoio ao leite humano", "sim_nao", grupo="Leite humano",
    categorias=["Sim", "Não"], regra="Sim/Não.", viz="Semáforo")

# ---------- Regulação, superlotação e transferências ----------
add("nir_ativo", "A unidade possui Núcleo Interno de Regulação (NIR) ativo para interface com a Central de Regulação? ",
    "regulacao", "Núcleo Interno de Regulação (NIR) ativo", "sim_nao", categorias=["Sim", "Não"],
    regra="Sim/Não.", viz="Semáforo")
add("vaga_zero_frequencia", 'Qual a frequência média de recebimento de pacientes por dia via "Vaga Zero"? ',
    "regulacao", 'Frequência média diária de "Vaga Zero"', "numero", unidade="pacientes/dia",
    regra="Numérico (remove zeros à esquerda tipo '00'/'01'); valores extremos (ex.: >100) sinalizados para revisão, não removidos.",
    viz="Distribuição, alerta de outlier")
add("vaga_zero_corredor", 'Qual a média diária de pacientes em "Vaga Zero" que permanecem aguardando em corredores?',
    "regulacao", 'Pacientes em "Vaga Zero" aguardando em corredores', "numero", unidade="pacientes/dia",
    regra="Numérico (remove zeros à esquerda); valores extremos sinalizados para revisão.", viz="Distribuição, alerta de outlier")
add("tempo_retencao_maca", "Tempo Médio [Qual tempo médio de retenção de maca (SAMU/Bombeiros) na unidade aguardando liberação?]",
    "regulacao", "Tempo médio de retenção de maca (SAMU/Bombeiros)", "categoria",
    categorias=["Menos de 10min", "Entre 11min e 20min", "Entre 21min e 40min", "Entre 41min e 59min", "Mais de 1h"],
    regra="Categórico ordinal por faixa de tempo.", viz="Barras ordenadas")
add("tempo_espera_uti", "Tempo Médio [Qual o tempo médio de espera para transferência de pacientes com indicação de UTI no último mês? (da solicitação à efetiva ocupação do leito).]",
    "regulacao", "Tempo médio de espera por leito de UTI", "categoria",
    categorias=["Menos de 10min", "Entre 11min e 20min", "Entre 21min e 40min", "Entre 41min e 59min", "Mais de 1h"],
    regra="Categórico ordinal por faixa de tempo.", viz="Barras ordenadas")
add("tempo_espera_retaguarda", "Tempo Médio [Após a estabilização do paciente na Sala Vermelha, qual o tempo médio de espera para transferência a um leito de retaguarda? Considerar o último mês e informar em horas. (Numérico) no ultimo mês]",
    "regulacao", "Tempo médio de espera por leito de retaguarda (pós Sala Vermelha)", "categoria",
    categorias=["Menos de 10min", "Entre 11min e 20min", "Entre 21min e 40min", "Entre 41min e 59min", "Mais de 1h"],
    regra="Categórico ordinal por faixa de tempo.", viz="Barras ordenadas")
add("plano_contingencia", "A unidade possui Plano de Contingência para Superlotação formalizado e atualizado?",
    "regulacao", "Plano de Contingência para Superlotação", "categoria", categorias=["Sim", "Não", "Em elaboração"],
    regra="Categórico (inclui estado intermediário 'Em elaboração').", viz="Semáforo (3 estados)")
add("disponibilidade_ambulancia", "Qual a disponibilidade de ambulância da unidade para transferência de pacientes?",
    "regulacao", "Disponibilidade de ambulância para transferência", "categoria",
    categorias=["Possui Ambulância Tipo D (UTI Móvel)", "Possui Ambulância Tipo B (Suporte Básico)", "Não possui"],
    regra="Categórico institucional.", viz="Distribuição")

# ---------- Trauma e suportes estratégicos ----------
CAT_DISP_TRAUMA = ["Disponibilidade 24h (Presencial)", "Disponibilidade (Sobreaviso)", "Não disponível"]
add("trauma_centro_cirurgico", "Capacidade de resposta - Trauma [Centro Cirúrgico Equipado]", "trauma",
    "Centro Cirúrgico Equipado", "categoria", grupo="Trauma", categorias=CAT_DISP_TRAUMA,
    regra="Categórico institucional.", viz="Semáforo")
add("trauma_cirurgiao_geral", "Capacidade de resposta - Trauma [Cirurgião Geral]", "trauma",
    "Cirurgião Geral", "categoria", grupo="Trauma", categorias=CAT_DISP_TRAUMA,
    regra="Categórico institucional.", viz="Semáforo")
add("trauma_ortopedista", "Capacidade de resposta - Trauma [Ortopedista]", "trauma",
    "Ortopedista", "categoria", grupo="Trauma", categorias=CAT_DISP_TRAUMA,
    regra="Categórico institucional.", viz="Semáforo")
add("trauma_neurocirurgiao", "Capacidade de resposta - Trauma [Neurocirurgião]", "trauma",
    "Neurocirurgião", "categoria", grupo="Trauma", categorias=CAT_DISP_TRAUMA,
    regra="Categórico institucional.", viz="Semáforo")
add("trauma_anestesiologista", "Capacidade de resposta - Trauma [Anestesiologista]", "trauma",
    "Anestesiologista", "categoria", grupo="Trauma", categorias=CAT_DISP_TRAUMA,
    regra="Categórico institucional.", viz="Semáforo")
add("suporte_hemoterapico", "Qual é a estrutura de suporte hemoterápico disponível para atendimento 24h?", "trauma",
    "Estrutura de suporte hemoterápico 24h", "categoria", grupo="Suporte estratégico",
    categorias=[
        "Agência Transfusional Própria (Estrutura interna completa para armazenamento e testes pré-transfusionais).",
        "Reserva Técnica (Estoque local vinculado a uma Agência externa/Hemocentro).",
        "Não possui no local (Dependência de envio externo sob demanda).",
    ], regra="Categórico institucional.", viz="Distribuição")
add("heliporto_ativo", "A unidade possui Ponto de Pouso ou Heliporto homologado pela ANAC e em condições de operação (ativo)? ",
    "trauma", "Ponto de Pouso/Heliporto homologado ANAC (ativo)", "sim_nao", grupo="Suporte estratégico",
    categorias=["Sim", "Não"], regra="Sim/Não.", viz="Semáforo")

print(f"Total de campos mapeados: {len(entries)} (colunas populadas na planilha: {len([h for h in headers if df[h].notna().sum() > 0])})")

used_headers = {e["header"] for e in entries}
all_populated = [h for h in headers if df[h].notna().sum() > 0]
missing = [h for h in all_populated if h not in used_headers]
if missing:
    print("AVISO — colunas populadas não mapeadas:")
    for m in missing:
        print("  -", repr(m))
else:
    print("OK: todas as colunas populadas da planilha estão mapeadas no dicionário.")

# ---------- Emite o arquivo TypeScript ----------
ts_lines = []
ts_lines.append("// GERADO AUTOMATICAMENTE por scripts/gerar-dicionario.py a partir de")
ts_lines.append("// scripts/fixtures/planilha-referencia.csv. Não editar manualmente:")
ts_lines.append("// para alterar, ajuste o gerador e rode `python3 scripts/gerar-dicionario.py`.")
ts_lines.append('import type { CampoDicionario } from "../types";')
ts_lines.append("")
ts_lines.append("export const DICIONARIO: CampoDicionario[] = ")
ts_lines.append(json.dumps(entries, ensure_ascii=False, indent=2))
ts_lines.append(";")
ts_lines.append("")

with open("src/lib/dictionary.generated.ts", "w", encoding="utf-8") as f:
    f.write("\n".join(ts_lines))

print("Arquivo gerado: src/lib/dictionary.generated.ts")

# ---------- Emite docs/dicionario-de-dados.md ----------
ROTULOS_EIXO = {
    "identificacao": "Identificação",
    "leitos": "Leitos e capacidade instalada",
    "equipamentos": "Sala de emergência e equipamentos",
    "imagem": "Diagnóstico por imagem",
    "especialidades": "Especialidades médicas",
    "capacidade_resposta": "Capacidade de resposta clínica",
    "regulacao": "Regulação, superlotação e transferências",
    "trauma": "Trauma e suportes estratégicos",
}

por_eixo = {}
for e in entries:
    por_eixo.setdefault(e["eixo"], []).append(e)

md = []
md.append("# Dicionário de dados")
md.append("")
md.append("Gerado automaticamente por `scripts/gerar-dicionario.py` a partir de")
md.append("`scripts/fixtures/planilha-referencia.csv` (172 respostas, coletadas entre")
md.append("11/05/2026 e 29/07/2026). Cada linha relaciona a coluna original da planilha a")
md.append("eixo, indicador, tipo, unidade, regra de limpeza e visualização recomendada —")
md.append("exigência da seção 2.3 do prompt mestre. Para reexecutar após uma mudança de")
md.append("estrutura na planilha: `python3 scripts/gerar-dicionario.py`.")
md.append("")
md.append(f"**Total de campos analíticos mapeados:** {len(entries)} (de 174 colunas originais;")
md.append("as demais estão integralmente vazias na base analisada e foram excluídas da")
md.append("camada analítica, sem alteração do arquivo-fonte).")
md.append("")

for eixo, rotulo in ROTULOS_EIXO.items():
    campos = por_eixo.get(eixo, [])
    if not campos:
        continue
    md.append(f"## {rotulo} ({len(campos)} campos)")
    md.append("")
    md.append("| Chave | Indicador | Grupo | Tipo | Unidade | Regra de limpeza | Visualização |")
    md.append("|---|---|---|---|---|---|---|")
    for c in campos:
        grupo = c["grupo"] or "—"
        unidade = c["unidade"] or "—"
        md.append(f"| `{c['key']}` | {c['indicador']} | {grupo} | {c['tipo']} | {unidade} | {c['regra']} | {c['viz']} |")
    md.append("")

md.append("## Campos de identificação (fora da camada de indicadores agregados)")
md.append("")
md.append("| Chave | Coluna original | Tipo | Regra |")
md.append("|---|---|---|---|")
for c in por_eixo.get("identificacao", []):
    md.append(f"| `{c['key']}` | {c['header']} | {c['tipo']} | {c['regra']} |")
md.append("")
md.append("> O campo `responsavel_preenchimento` (Responsável pelo preenchimento) é dado")
md.append("> pessoal: é lido apenas para fins de auditoria interna e **nunca** é incluído no")
md.append("> JSON anonimizado devolvido pela Netlify Function nem em qualquer exportação.")

with open("docs/dicionario-de-dados.md", "w", encoding="utf-8") as f:
    f.write("\n".join(md) + "\n")

print("Arquivo gerado: docs/dicionario-de-dados.md")
