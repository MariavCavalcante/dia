// Netlify Function: /api/dados
// Busca a Planilha Google (publicada em CSV), limpa, anonimiza e devolve
// somente os dados necessários ao painel. Nunca expõe a planilha bruta nem
// o campo "Responsável pelo preenchimento" (regras 2.3.1 e 2.4).
import type { Handler, HandlerEvent } from "@netlify/functions";
import { handleDadosRequest } from "../../src/lib/pipeline";

export const handler: Handler = async (event: HandlerEvent) => {
  const forceRefresh = event.queryStringParameters?.force === "1";
  const resultado = await handleDadosRequest({ forceRefresh });

  return {
    statusCode: resultado.status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      // Cache curto + revalidação no CDN da Netlify (regra 2.3.2). O evento
      // onFormSubmit (Apps Script, ver docs/integracao-google-forms.md) pode
      // chamar este endpoint com force=1 para invalidar o cache imediatamente.
      "Cache-Control": "public, max-age=30, stale-while-revalidate=120",
    },
    body: JSON.stringify(resultado.body),
  };
};
