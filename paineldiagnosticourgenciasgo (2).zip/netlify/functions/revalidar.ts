// Netlify Function: /api/revalidar
// Endpoint seguro para ser chamado pelo gatilho onFormSubmit do Google Apps
// Script (ver docs/integracao-google-forms.md), forçando a invalidação do
// cache imediatamente após uma nova resposta do Google Forms (regra 2.3.1 —
// "Atualização orientada a evento"). Protegido por um token simples via
// variável de ambiente REVALIDATE_TOKEN; sem o token configurado, o endpoint
// aceita qualquer chamada (modo aberto), o que é aceitável apenas porque não
// grava nem expõe dados — apenas força uma nova leitura da fonte pública.
import type { Handler, HandlerEvent } from "@netlify/functions";
import { handleDadosRequest } from "../../src/lib/pipeline";

export const handler: Handler = async (event: HandlerEvent) => {
  const tokenEsperado = process.env.REVALIDATE_TOKEN;
  if (tokenEsperado) {
    const tokenRecebido = event.queryStringParameters?.token;
    if (tokenRecebido !== tokenEsperado) {
      return { statusCode: 401, body: JSON.stringify({ erro: "Token inválido." }) };
    }
  }

  const resultado = await handleDadosRequest({ forceRefresh: true });
  return {
    statusCode: resultado.status,
    headers: { "Content-Type": "application/json; charset=utf-8" },
    body: JSON.stringify({ ok: resultado.status === 200, geradoEm: new Date().toISOString() }),
  };
};
