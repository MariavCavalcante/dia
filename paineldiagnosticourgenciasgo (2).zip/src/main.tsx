import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, HashRouter } from "react-router-dom";
import App from "./App";
import { corrigirConstrutorDeUrlEmOrigemOpaca } from "./lib/corrigirUrlOpaca";
import "./index.css";

// Ver comentário completo em src/lib/corrigirUrlOpaca.ts — precisa rodar
// antes de qualquer renderização do React Router, que constrói URLs
// internamente a cada rota. Precisa ser chamado aqui, antes do render, para
// garantir que o patch já esteja ativo no primeiro render de <Roteador>.
corrigirConstrutorDeUrlEmOrigemOpaca();

// Na build de demonstração estática (npm run build:demo), o painel é aberto
// como um único arquivo HTML local (file://), onde o roteamento por caminho
// (BrowserRouter) não funciona — o "pathname" vira o caminho do arquivo no
// disco. HashRouter (#/rota) funciona em qualquer contexto, inclusive
// file://, sem precisar de servidor. A build de produção normal continua
// usando BrowserRouter (URLs limpas, com fallback de SPA via netlify.toml).
const Roteador = import.meta.env.VITE_MODO_DEMO === "1" ? HashRouter : BrowserRouter;

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <Roteador>
      <App />
    </Roteador>
  </React.StrictMode>
);
