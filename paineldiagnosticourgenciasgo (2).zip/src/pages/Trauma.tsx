import { useMemo } from "react";
import type { RegistroUnidade } from "../types";
import { SemaforoBadge } from "../components/SemaforoBadge";
import { DonutChart } from "../components/charts/DonutChart";
import { EQUIPE_TRAUMA } from "../lib/grupos";
import { contarSemaforo, distribuicaoCategoria } from "../lib/indicadores";

export default function Trauma({ registros }: { registros: RegistroUnidade[] }) {
  const hemoterapico = useMemo(() => distribuicaoCategoria(registros, "suporte_hemoterapico"), [registros]);
  const heliporto = useMemo(() => contarSemaforo(registros, "heliporto_ativo"), [registros]);

  return (
    <div className="space-y-4">
      <div className="card p-4">
        <h3 className="mb-3 text-sm font-semibold text-gray-800 dark:text-gray-100">
          Disponibilidade da equipe e estrutura para suporte ao trauma
        </h3>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {EQUIPE_TRAUMA.map((item) => {
            const c = contarSemaforo(registros, item.chave);
            const total = c.verde + c.amarelo + c.vermelho + c.cinza || 1;
            return (
              <div key={item.chave} className="flex flex-col gap-1 rounded-lg border border-gray-100 p-3 dark:border-gray-800">
                <span className="text-xs font-medium text-gray-700 dark:text-gray-300">{item.rotulo}</span>
                <div className="flex flex-wrap gap-1.5">
                  <SemaforoBadge estado="verde" rotuloPersonalizado={`24h presencial: ${c.verde} (${Math.round((c.verde / total) * 100)}%)`} />
                  <SemaforoBadge estado="amarelo" rotuloPersonalizado={`Sobreaviso: ${c.amarelo}`} />
                  <SemaforoBadge estado="vermelho" rotuloPersonalizado={`Não disponível: ${c.vermelho}`} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <DonutChart titulo="Estrutura de suporte hemoterápico 24h" dados={hemoterapico.map((d) => ({ rotulo: d.categoria, valor: d.quantidade }))} />
        <div className="card p-4">
          <h3 className="mb-2 text-sm font-semibold text-gray-800 dark:text-gray-100">
            Ponto de Pouso / Heliporto homologado ANAC (ativo)
          </h3>
          <div className="flex gap-2">
            <SemaforoBadge estado="verde" rotuloPersonalizado={`${heliporto.verde} unidade(s) com heliporto ativo`} />
            <SemaforoBadge estado="vermelho" rotuloPersonalizado={`${heliporto.vermelho} sem heliporto`} />
          </div>
        </div>
      </div>
    </div>
  );
}
