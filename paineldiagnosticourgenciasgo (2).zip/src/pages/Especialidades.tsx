import { useMemo } from "react";
import type { RegistroUnidade } from "../types";
import { StackedBarChart } from "../components/charts/StackedBarChart";
import { ESPECIALIDADES } from "../lib/grupos";
import { resumoMisto, somarCampoNumerico } from "../lib/indicadores";
import { STATUS, CATEGORICA_LIGHT } from "../lib/paleta";

export default function Especialidades({ registros }: { registros: RegistroUnidade[] }) {
  const dadosRegime = useMemo(
    () =>
      ESPECIALIDADES.map((esp) => ({
        rotulo: esp.rotulo,
        presencial: somarCampoNumerico(registros, `${esp.prefixo}_presencial`),
        sobreaviso: somarCampoNumerico(registros, `${esp.prefixo}_sobreaviso`),
        telemedicina: somarCampoNumerico(registros, `${esp.prefixo}_telemedicina`),
      })),
    [registros]
  );

  const lacunas = useMemo(
    () =>
      ESPECIALIDADES.map((esp) => {
        const resumo = resumoMisto(registros, `${esp.prefixo}_plantao24h`);
        const total = registros.length || 1;
        return {
          especialidade: esp.rotulo,
          semEspecialidade: resumo.naoDispoe,
          percentualSem: Math.round((resumo.naoDispoe / total) * 100),
          totalProfissionaisPlantao: resumo.estatistica.comResposta,
        };
      }),
    [registros]
  );

  return (
    <div className="space-y-4">
      <StackedBarChart
        titulo="Profissionais por regime (soma no recorte)"
        percentual={false}
        dados={dadosRegime}
        series={[
          { chave: "presencial", rotulo: "Presencial", cor: CATEGORICA_LIGHT[0] },
          { chave: "sobreaviso", rotulo: "Sobreaviso", cor: STATUS.amarelo },
          { chave: "telemedicina", rotulo: "Telemedicina", cor: CATEGORICA_LIGHT[2] },
        ]}
      />

      <div className="card p-4">
        <h3 className="mb-3 text-sm font-semibold text-gray-800 dark:text-gray-100">
          Lacunas por especialidade — "Não dispõe da especialidade" no plantão de 24h
        </h3>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 text-left text-gray-600 dark:border-gray-800 dark:text-gray-300">
                <th className="p-2">Especialidade</th>
                <th className="p-2">Unidades sem a especialidade</th>
                <th className="p-2">% do recorte</th>
                <th className="p-2">Unidades com resposta numérica</th>
              </tr>
            </thead>
            <tbody>
              {lacunas.map((l) => (
                <tr key={l.especialidade} className="border-b border-gray-100 dark:border-gray-900">
                  <td className="p-2 font-medium">{l.especialidade}</td>
                  <td className="p-2 text-status-vermelho">{l.semEspecialidade}</td>
                  <td className="p-2">{l.percentualSem}%</td>
                  <td className="p-2">{l.totalProfissionaisPlantao}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
          Campo misto (regra 2.4): "Não dispõe da especialidade" nunca é somado como zero — é contado
          separadamente das respostas numéricas.
        </p>
      </div>
    </div>
  );
}
