import { useMemo } from "react";
import type { RegistroUnidade } from "../types";
import { SemaforoBadge } from "../components/SemaforoBadge";
import { DonutChart } from "../components/charts/DonutChart";
import { contarSemaforo, distribuicaoCategoria } from "../lib/indicadores";

const ITENS_SEMAFORO: { titulo: string; chave: string; grupo: string }[] = [
  { titulo: "Realiza Trombólise (cardiovascular)", chave: "cv_trombolise", grupo: "Cardiovascular" },
  { titulo: "Hemodinâmica (Cineangiocoronariografia)", chave: "cv_hemodinamica", grupo: "Cardiovascular" },
  { titulo: "Angioplastia Primária (24h)", chave: "cv_angioplastia", grupo: "Cardiovascular" },
  { titulo: "Protocolo de trombólise para AVCi com neuroimagem 24h", chave: "avc_protocolo_trombolise", grupo: "AVC / DRC" },
  { titulo: "Hemodiálise em ambiente de UTI", chave: "drc_hemodialise_uti", grupo: "AVC / DRC" },
  { titulo: "Hemodiálise em unidades de internação", chave: "drc_hemodialise_internacao", grupo: "AVC / DRC" },
  { titulo: "Leitos específicos para Saúde Mental", chave: "sm_leitos_especificos", grupo: "Saúde mental" },
  { titulo: "Protocolo para crises/surtos psicóticos", chave: "sm_protocolo_crise", grupo: "Saúde mental" },
  { titulo: "Incubadora de transporte com ventilador", chave: "incubadora_transporte", grupo: "Maternidade / neonatal" },
  { titulo: "Banco de Leite Humano", chave: "leite_banco", grupo: "Apoio ao leite humano" },
  { titulo: "Posto de Coleta de Leite Humano", chave: "leite_posto", grupo: "Apoio ao leite humano" },
];

function ResumoSemaforo({ titulo, chave, registros }: { titulo: string; chave: string; registros: RegistroUnidade[] }) {
  const c = contarSemaforo(registros, chave);
  const total = c.verde + c.amarelo + c.vermelho + c.cinza || 1;
  return (
    <div className="flex flex-col gap-1 rounded-lg border border-gray-100 p-3 dark:border-gray-800">
      <span className="text-xs font-medium text-gray-700 dark:text-gray-300">{titulo}</span>
      <div className="flex flex-wrap gap-1.5">
        <SemaforoBadge estado="verde" rotuloPersonalizado={`${c.verde} (${Math.round((c.verde / total) * 100)}%)`} />
        <SemaforoBadge estado="amarelo" rotuloPersonalizado={`${c.amarelo}`} />
        <SemaforoBadge estado="vermelho" rotuloPersonalizado={`${c.vermelho}`} />
        <SemaforoBadge estado="cinza" rotuloPersonalizado={`${c.cinza}`} />
      </div>
    </div>
  );
}

export default function CapacidadeResposta({ registros }: { registros: RegistroUnidade[] }) {
  const grupos = useMemo(() => {
    const mapa = new Map<string, typeof ITENS_SEMAFORO>();
    for (const item of ITENS_SEMAFORO) {
      const lista = mapa.get(item.grupo) ?? [];
      lista.push(item);
      mapa.set(item.grupo, lista);
    }
    return [...mapa.entries()];
  }, []);

  const perfilMaternidade = useMemo(() => distribuicaoCategoria(registros, "maternidade_perfil"), [registros]);

  return (
    <div className="space-y-4">
      {grupos.map(([grupo, itens]) => (
        <div key={grupo} className="card p-4">
          <h3 className="mb-3 text-sm font-semibold text-gray-800 dark:text-gray-100">{grupo}</h3>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {itens.map((item) => (
              <ResumoSemaforo key={item.chave} titulo={item.titulo} chave={item.chave} registros={registros} />
            ))}
          </div>
        </div>
      ))}

      <DonutChart
        titulo="Perfil da maternidade/centro obstétrico"
        dados={perfilMaternidade.map((d) => ({ rotulo: d.categoria, valor: d.quantidade }))}
      />

      <p className="text-xs text-gray-500 dark:text-gray-400">
        Verde = disponibilidade confirmada / situação positiva validada. Amarelo = cobertura parcial, sobreaviso
        ou terceirizada. Vermelho = indisponibilidade confirmada. Cinza = não informado. Nenhuma meta clínica é
        inferida sem fonte normativa (regra 2.10).
      </p>
    </div>
  );
}
