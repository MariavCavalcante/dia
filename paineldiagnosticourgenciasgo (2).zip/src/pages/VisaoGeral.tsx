import { useMemo } from "react";
import type { DatasetPainel, RegistroUnidade } from "../types";
import { StatCard } from "../components/StatCard";
import { BalaoMunicipios } from "../components/BalaoMunicipios";
import { BarRanking } from "../components/charts/BarRanking";
import { DonutChart } from "../components/charts/DonutChart";
import {
  contarCnesDistintos,
  contarMunicipiosDistintos,
  contarUnidadesDistintas,
  distribuicaoPorClassificacao,
  municipioComMaiorParticipacao,
  respostasPorMunicipio,
} from "../lib/indicadores";
import { useFiltros } from "../context/FiltrosContext";

export default function VisaoGeral({
  dataset,
  registrosConsolidados,
  registrosFiltrados,
}: {
  dataset: DatasetPainel;
  registrosConsolidados: RegistroUnidade[];
  registrosFiltrados: RegistroUnidade[];
}) {
  const { temFiltrosAtivos } = useFiltros();

  const ranking = useMemo(() => respostasPorMunicipio(registrosFiltrados), [registrosFiltrados]);
  const destaque = useMemo(() => municipioComMaiorParticipacao(registrosFiltrados), [registrosFiltrados]);
  const distribuicaoClassificacao = useMemo(() => distribuicaoPorClassificacao(registrosFiltrados), [registrosFiltrados]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        <StatCard
          titulo="Total de respostas válidas (consolidado)"
          valor={registrosFiltrados.length}
          subtitulo={`${dataset.totalRespostasValidas} respostas brutas válidas antes da deduplicação por CNES`}
          tom="azul"
        />
        <StatCard titulo="Municípios" valor={contarMunicipiosDistintos(registrosFiltrados)} tom="verde" />
        <StatCard titulo="Unidades de saúde" valor={contarUnidadesDistintas(registrosFiltrados)} />
        <StatCard titulo="CNES distintos" valor={contarCnesDistintos(registrosFiltrados)} />
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <BalaoMunicipios
          municipiosNoRecorte={contarMunicipiosDistintos(registrosFiltrados)}
          municipiosTotalRespondentes={dataset.municipiosRespondentes}
          temFiltro={temFiltrosAtivos}
          aoClicar={() => document.getElementById("ranking-municipios")?.scrollIntoView({ behavior: "smooth" })}
        />
        {destaque && (
          <StatCard
            titulo="Município com maior participação"
            valor={destaque.municipio}
            subtitulo={`${destaque.quantidade} resposta(s) — ${Math.round(destaque.percentual * 100)}% do recorte`}
            tom="amarelo"
          />
        )}
      </div>

      <div id="ranking-municipios">
        <BarRanking titulo="Municípios com maior número de respostas" itens={ranking.map((r) => ({ rotulo: r.municipio, valor: r.quantidade, percentual: r.percentual }))} unidade="respostas" />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <DonutChart titulo="Distribuição por classificação do estabelecimento" dados={distribuicaoClassificacao.map((d) => ({ rotulo: d.categoria, valor: d.quantidade }))} />
        <div className="card p-4">
          <h3 className="mb-2 text-sm font-semibold text-gray-800 dark:text-gray-100">Cobertura territorial e qualidade da base</h3>
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between border-b border-gray-100 pb-1 dark:border-gray-800">
              <dt className="text-gray-500 dark:text-gray-400">Completude média da base</dt>
              <dd className="font-semibold">{Math.round(dataset.completudeGeral * 100)}%</dd>
            </div>
            <div className="flex justify-between border-b border-gray-100 pb-1 dark:border-gray-800">
              <dt className="text-gray-500 dark:text-gray-400">Linhas recebidas da planilha</dt>
              <dd className="font-semibold">{dataset.status.linhasRecebidas}</dd>
            </div>
            <div className="flex justify-between border-b border-gray-100 pb-1 dark:border-gray-800">
              <dt className="text-gray-500 dark:text-gray-400">Registros válidos considerados</dt>
              <dd className="font-semibold">{dataset.status.registrosValidos}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-500 dark:text-gray-400">Registros excluídos (vazios/sem carimbo)</dt>
              <dd className="font-semibold">{dataset.status.registrosExcluidos}</dd>
            </div>
          </dl>
          <p className="mt-3 text-xs text-gray-500 dark:text-gray-400">
            Vazios assistenciais e completude detalhada por eixo estão na página{" "}
            <span className="font-medium text-go-azul">Qualidade dos dados</span>.
          </p>
        </div>
      </div>
    </div>
  );
}
