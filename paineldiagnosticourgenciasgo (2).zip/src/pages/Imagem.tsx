import { useMemo } from "react";
import type { RegistroUnidade } from "../types";
import { StackedBarChart } from "../components/charts/StackedBarChart";
import { APARELHOS_IMAGEM } from "../lib/grupos";
import { distribuicaoCategoria } from "../lib/indicadores";
import { STATUS, CATEGORICA_LIGHT } from "../lib/paleta";

function montarDadosEmpilhados(
  registros: RegistroUnidade[],
  sufixo: string,
  categorias: { chave: string; rotulo: string; cor: string }[]
) {
  return APARELHOS_IMAGEM.map((ap) => {
    const dist = distribuicaoCategoria(registros, `${ap.prefixo}_${sufixo}`);
    const total = registros.length || 1;
    const linha: Record<string, string | number> = { rotulo: ap.rotulo };
    for (const cat of categorias) {
      const item = dist.find((d) => d.categoria === cat.chave);
      linha[cat.chave] = item ? Math.round((item.quantidade / total) * 100) : 0;
    }
    return linha;
  });
}

export default function Imagem({ registros }: { registros: RegistroUnidade[] }) {
  const funcionamento = useMemo(
    () =>
      montarDadosEmpilhados(registros, "funcionamento", [
        { chave: "Não possui", rotulo: "Não possui", cor: STATUS.vermelho },
        { chave: "08 horas/dia", rotulo: "8h/dia", cor: STATUS.amarelo },
        { chave: "12 horas/dia", rotulo: "12h/dia", cor: CATEGORICA_LIGHT[2] },
        { chave: "24 horas/dia", rotulo: "24h/dia", cor: STATUS.verde },
      ]),
    [registros]
  );

  const local = useMemo(
    () =>
      montarDadosEmpilhados(registros, "local", [
        { chave: "Não Oferta o Serviço", rotulo: "Não oferta o serviço", cor: STATUS.vermelho },
        { chave: "Outra unidade", rotulo: "Outra unidade", cor: STATUS.amarelo },
        { chave: "Na Unidade", rotulo: "Na própria unidade", cor: STATUS.verde },
      ]),
    [registros]
  );

  const laudos = useMemo(
    () =>
      montarDadosEmpilhados(registros, "laudos", [
        { chave: "Não Oferta o Serviço", rotulo: "Não oferta o serviço", cor: STATUS.vermelho },
        { chave: "Telemedicina", rotulo: "Telemedicina", cor: STATUS.amarelo },
        { chave: "Presencial", rotulo: "Presencial", cor: STATUS.verde },
      ]),
    [registros]
  );

  return (
    <div className="space-y-4">
      <StackedBarChart
        titulo="Funcionamento do serviço por aparelho (% do recorte)"
        dados={funcionamento}
        series={[
          { chave: "Não possui", rotulo: "Não possui", cor: STATUS.vermelho },
          { chave: "08 horas/dia", rotulo: "8h/dia", cor: STATUS.amarelo },
          { chave: "12 horas/dia", rotulo: "12h/dia", cor: CATEGORICA_LIGHT[2] },
          { chave: "24 horas/dia", rotulo: "24h/dia", cor: STATUS.verde },
        ]}
      />
      <StackedBarChart
        titulo="Local de instalação do equipamento (% do recorte)"
        dados={local}
        series={[
          { chave: "Não Oferta o Serviço", rotulo: "Não oferta o serviço", cor: STATUS.vermelho },
          { chave: "Outra unidade", rotulo: "Outra unidade", cor: STATUS.amarelo },
          { chave: "Na Unidade", rotulo: "Na própria unidade", cor: STATUS.verde },
        ]}
      />
      <StackedBarChart
        titulo="Emissão de laudos (% do recorte)"
        dados={laudos}
        series={[
          { chave: "Não Oferta o Serviço", rotulo: "Não oferta o serviço", cor: STATUS.vermelho },
          { chave: "Telemedicina", rotulo: "Telemedicina", cor: STATUS.amarelo },
          { chave: "Presencial", rotulo: "Presencial", cor: STATUS.verde },
        ]}
      />
    </div>
  );
}
