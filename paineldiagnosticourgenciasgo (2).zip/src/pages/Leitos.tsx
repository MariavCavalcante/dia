import { useMemo } from "react";
import type { RegistroUnidade } from "../types";
import { StatCard } from "../components/StatCard";
import { DivergenceChart } from "../components/charts/DivergenceChart";
import { BarRanking } from "../components/charts/BarRanking";
import { DataTable } from "../components/DataTable";
import { TIPOS_LEITO } from "../lib/grupos";
import { divergenciaLeitosPorTipo, somarCampoNumerico } from "../lib/indicadores";

export default function Leitos({ registros }: { registros: RegistroUnidade[] }) {
  const divergencia = useMemo(() => divergenciaLeitosPorTipo(registros), [registros]);
  const totalSus = divergencia.reduce((a, d) => a + d.operacionalSus, 0);
  const totalCnes = divergencia.reduce((a, d) => a + d.cadastradoCnes, 0);

  const rankingPorMunicipio = useMemo(() => {
    const mapa = new Map<string, number>();
    for (const r of registros) {
      let soma = 0;
      for (const t of TIPOS_LEITO) {
        const v = r.campos[t.chaveSus];
        if (typeof v === "number") soma += v;
      }
      mapa.set(r.municipio, (mapa.get(r.municipio) ?? 0) + soma);
    }
    return [...mapa.entries()]
      .map(([rotulo, valor]) => ({ rotulo, valor }))
      .sort((a, b) => b.valor - a.valor);
  }, [registros]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard titulo="Leitos operacionais SUS (total)" valor={totalSus} tom="verde" />
        <StatCard titulo="Leitos cadastrados no CNES (total)" valor={totalCnes} tom="azul" />
        {TIPOS_LEITO.slice(0, 2).map((t) => (
          <StatCard key={t.rotulo} titulo={`Operacionais — ${t.rotulo}`} valor={somarCampoNumerico(registros, t.chaveSus)} />
        ))}
      </div>

      <DivergenceChart dados={divergencia} />

      <BarRanking titulo="Municípios por total de leitos operacionais SUS" itens={rankingPorMunicipio} unidade="leitos" />

      <DataTable registros={registros} />
    </div>
  );
}
