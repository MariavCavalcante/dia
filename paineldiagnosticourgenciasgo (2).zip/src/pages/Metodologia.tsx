import { useMemo, useState } from "react";
import type { DatasetPainel, EixoId } from "../types";
import { DICIONARIO } from "../lib/dictionary.generated";

const ROTULOS_EIXO: Record<EixoId, string> = {
  identificacao: "Identificação",
  leitos: "Leitos e capacidade instalada",
  equipamentos: "Sala de emergência e equipamentos",
  imagem: "Diagnóstico por imagem",
  especialidades: "Especialidades médicas",
  capacidade_resposta: "Capacidade de resposta clínica",
  regulacao: "Regulação, superlotação e transferências",
  trauma: "Trauma e suportes estratégicos",
  qualidade: "Qualidade dos dados",
};

const INDICADORES_METODOLOGIA: { nome: string; formula: string; numerador: string; denominador: string; regraAusentes: string }[] = [
  {
    nome: "Total de respostas",
    formula: "Contagem de linhas válidas com carimbo de data/hora",
    numerador: "Linhas com carimbo de data/hora válido",
    denominador: "—",
    regraAusentes: "Linhas sem carimbo são descartadas antes do cálculo",
  },
  {
    nome: "Municípios respondentes",
    formula: "Contagem distinta do município normalizado",
    numerador: "Municípios distintos (chave normalizada)",
    denominador: "—",
    regraAusentes: "Não aplicável",
  },
  {
    nome: "Respostas por município",
    formula: "Contagem de linhas válidas agrupadas por município, ordenada do maior para o menor (empate: alfabético)",
    numerador: "Respostas do município",
    denominador: "—",
    regraAusentes: "Não aplicável",
  },
  {
    nome: "Diferença de leitos",
    formula: "Leitos operacionais SUS − leitos cadastrados no CNES, por tipo e unidade",
    numerador: "Soma de leitos operacionais válidos",
    denominador: "Soma de leitos cadastrados no CNES válidos",
    regraAusentes: "Zero é valor válido; não preenchido não entra na soma",
  },
  {
    nome: "Disponibilidade de item",
    formula: "Percentual de unidades com valor > 0 para o item",
    numerador: "Unidades com valor numérico > 0",
    denominador: "Unidades com resposta válida para o item (não vazio)",
    regraAusentes: "Sem resposta não conta no denominador",
  },
  {
    nome: "Completude",
    formula: "Campos analíticos preenchidos ÷ total de campos analíticos aplicáveis",
    numerador: "Campos preenchidos (excluindo colunas integralmente vazias)",
    denominador: "Total de campos analíticos do eixo/base",
    regraAusentes: "Colunas integralmente vazias já excluídas da camada analítica",
  },
  {
    nome: "Cobertura territorial",
    formula: "Municípios com ao menos 1 resposta ÷ total oficial de municípios de Goiás",
    numerador: "Municípios respondentes",
    denominador: "246 municípios (IBGE) — usado apenas como referência informativa nesta v1",
    regraAusentes: "Não usado como indicador oficial sem validação institucional (regra 2.8/2.7.3)",
  },
];

export default function Metodologia({ dataset }: { dataset: DatasetPainel }) {
  const [eixoAberto, setEixoAberto] = useState<EixoId | null>("identificacao");

  const porEixo = useMemo(() => {
    const mapa = new Map<EixoId, typeof DICIONARIO>();
    for (const def of DICIONARIO) {
      const lista = mapa.get(def.eixo) ?? [];
      lista.push(def);
      mapa.set(def.eixo, lista);
    }
    return [...mapa.entries()];
  }, []);

  return (
    <div className="space-y-4">
      <div className="card p-4">
        <h2 className="mb-2 text-base font-semibold text-gray-900 dark:text-gray-50">Fonte de dados e sincronização</h2>
        <dl className="grid grid-cols-1 gap-2 text-sm sm:grid-cols-2">
          <div>
            <dt className="text-gray-500 dark:text-gray-400">Fonte</dt>
            <dd className="font-medium">Planilha Google publicada em CSV (Google Forms)</dd>
          </div>
          <div>
            <dt className="text-gray-500 dark:text-gray-400">Aba da planilha</dt>
            <dd className="font-medium">{dataset.fonte.aba}</dd>
          </div>
          <div>
            <dt className="text-gray-500 dark:text-gray-400">Variável de ambiente</dt>
            <dd className="font-mono text-xs">{dataset.fonte.urlVariavelAmbiente}</dd>
          </div>
          <div>
            <dt className="text-gray-500 dark:text-gray-400">Intervalo de verificação automática</dt>
            <dd className="font-medium">Entre 1 e 5 minutos (configurável)</dd>
          </div>
        </dl>
        <p className="mt-3 text-xs text-gray-500 dark:text-gray-400">
          Conectado à planilha real "DIAGNÓSTICO SITUACIONAL (respostas)" do Google Forms — os indicadores são
          calculados exclusivamente a partir da base atualizada obtida pela URL CSV pública, sem necessidade de novo
          build/deploy a cada nova resposta.
        </p>
      </div>

      <div className="card p-4">
        <h2 className="mb-3 text-base font-semibold text-gray-900 dark:text-gray-50">Indicadores e regras de cálculo</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-gray-200 text-left text-gray-600 dark:border-gray-800 dark:text-gray-300">
                <th className="p-2">Indicador</th>
                <th className="p-2">Fórmula</th>
                <th className="p-2">Numerador</th>
                <th className="p-2">Denominador</th>
                <th className="p-2">Regra para valores ausentes</th>
              </tr>
            </thead>
            <tbody>
              {INDICADORES_METODOLOGIA.map((i) => (
                <tr key={i.nome} className="border-b border-gray-100 align-top dark:border-gray-900">
                  <td className="p-2 font-medium">{i.nome}</td>
                  <td className="p-2 text-gray-600 dark:text-gray-400">{i.formula}</td>
                  <td className="p-2 text-gray-600 dark:text-gray-400">{i.numerador}</td>
                  <td className="p-2 text-gray-600 dark:text-gray-400">{i.denominador}</td>
                  <td className="p-2 text-gray-600 dark:text-gray-400">{i.regraAusentes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">Data de referência: {new Date(dataset.geradoEm).toLocaleDateString("pt-BR")}.</p>
      </div>

      <div className="card p-4">
        <h2 className="mb-3 text-base font-semibold text-gray-900 dark:text-gray-50">
          Dicionário de dados ({DICIONARIO.length} campos analíticos)
        </h2>
        <p className="mb-3 text-xs text-gray-500 dark:text-gray-400">
          Relaciona cada coluna original da planilha a eixo, indicador, tipo, unidade, regra de limpeza e
          visualização recomendada. Versão completa também disponível em{" "}
          <code>docs/dicionario-de-dados.md</code> no repositório do projeto.
        </p>
        {porEixo.map(([eixo, campos]) => (
          <div key={eixo} className="border-b border-gray-100 py-2 last:border-0 dark:border-gray-900">
            <button
              type="button"
              onClick={() => setEixoAberto(eixoAberto === eixo ? null : eixo)}
              className="flex w-full items-center justify-between py-1 text-left text-sm font-semibold text-gray-800 dark:text-gray-100"
              aria-expanded={eixoAberto === eixo}
            >
              {ROTULOS_EIXO[eixo] ?? eixo} ({campos.length})
              <span aria-hidden="true">{eixoAberto === eixo ? "▲" : "▼"}</span>
            </button>
            {eixoAberto === eixo && (
              <div className="mt-2 overflow-x-auto">
                <table className="min-w-full text-xs">
                  <thead>
                    <tr className="border-b border-gray-200 text-left text-gray-500 dark:border-gray-800">
                      <th className="p-1.5">Indicador</th>
                      <th className="p-1.5">Grupo</th>
                      <th className="p-1.5">Tipo</th>
                      <th className="p-1.5">Regra de limpeza</th>
                      <th className="p-1.5">Visualização</th>
                    </tr>
                  </thead>
                  <tbody>
                    {campos.map((c) => (
                      <tr key={c.key} className="border-b border-gray-50 align-top dark:border-gray-900">
                        <td className="p-1.5 font-medium">{c.indicador}</td>
                        <td className="p-1.5 text-gray-500">{c.grupo ?? "—"}</td>
                        <td className="p-1.5 text-gray-500">{c.tipo}</td>
                        <td className="p-1.5 text-gray-500">{c.regra}</td>
                        <td className="p-1.5 text-gray-500">{c.viz}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
