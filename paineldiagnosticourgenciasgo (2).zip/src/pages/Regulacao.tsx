import { useMemo } from "react";
import type { RegistroUnidade } from "../types";
import { StatCard } from "../components/StatCard";
import { SemaforoBadge } from "../components/SemaforoBadge";
import { DonutChart } from "../components/charts/DonutChart";
import { contarSemaforo, distribuicaoCategoria, estatisticaNumerica } from "../lib/indicadores";

const ORDEM_TEMPO = ["Menos de 10min", "Entre 11min e 20min", "Entre 21min e 40min", "Entre 41min e 59min", "Mais de 1h"];

function ordenarTempo(dist: { categoria: string; quantidade: number }[]) {
  return [...dist].sort((a, b) => {
    const ia = ORDEM_TEMPO.indexOf(a.categoria);
    const ib = ORDEM_TEMPO.indexOf(b.categoria);
    if (ia === -1 && ib === -1) return 0;
    if (ia === -1) return 1;
    if (ib === -1) return -1;
    return ia - ib;
  });
}

export default function Regulacao({ registros }: { registros: RegistroUnidade[] }) {
  const nir = useMemo(() => contarSemaforo(registros, "nir_ativo"), [registros]);
  const vagaZeroFrequencia = useMemo(() => estatisticaNumerica(registros, "vaga_zero_frequencia"), [registros]);
  const vagaZeroCorredor = useMemo(() => estatisticaNumerica(registros, "vaga_zero_corredor"), [registros]);
  const retencaoMaca = useMemo(() => ordenarTempo(distribuicaoCategoria(registros, "tempo_retencao_maca")), [registros]);
  const esperaUti = useMemo(() => ordenarTempo(distribuicaoCategoria(registros, "tempo_espera_uti")), [registros]);
  const esperaRetaguarda = useMemo(() => ordenarTempo(distribuicaoCategoria(registros, "tempo_espera_retaguarda")), [registros]);
  const planoContingencia = useMemo(() => distribuicaoCategoria(registros, "plano_contingencia"), [registros]);
  const ambulancia = useMemo(() => distribuicaoCategoria(registros, "disponibilidade_ambulancia"), [registros]);

  const alertasVagaZero = useMemo(
    () => registros.flatMap((r) => r.alertas.filter((a) => a.campo === "vaga_zero_frequencia" || a.campo === "vaga_zero_corredor").map((a) => ({ unidade: r.unidade, municipio: r.municipio, mensagem: a.mensagem }))),
    [registros]
  );

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="card p-4">
          <span className="text-xs font-medium uppercase tracking-wide text-gray-500 dark:text-gray-400">
            Núcleo Interno de Regulação (NIR) ativo
          </span>
          <div className="mt-2 flex gap-1.5">
            <SemaforoBadge estado="verde" rotuloPersonalizado={`${nir.verde} sim`} />
            <SemaforoBadge estado="vermelho" rotuloPersonalizado={`${nir.vermelho} não`} />
          </div>
        </div>
        <StatCard
          titulo='Vaga Zero — frequência média diária'
          valor={vagaZeroFrequencia.media !== null ? vagaZeroFrequencia.media.toFixed(1) : "—"}
          subtitulo={`Mediana ${vagaZeroFrequencia.mediana ?? "—"} · min ${vagaZeroFrequencia.minimo ?? "—"} · máx ${vagaZeroFrequencia.maximo ?? "—"}`}
        />
        <StatCard
          titulo='Vaga Zero — aguardando em corredores'
          valor={vagaZeroCorredor.media !== null ? vagaZeroCorredor.media.toFixed(1) : "—"}
          subtitulo={`Mediana ${vagaZeroCorredor.mediana ?? "—"} · min ${vagaZeroCorredor.minimo ?? "—"} · máx ${vagaZeroCorredor.maximo ?? "—"}`}
        />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {[
          { titulo: "Tempo médio de retenção de maca (SAMU/Bombeiros)", dados: retencaoMaca },
          { titulo: "Tempo médio de espera por leito de UTI", dados: esperaUti },
          { titulo: "Tempo médio de espera por leito de retaguarda", dados: esperaRetaguarda },
        ].map((g) => (
          <div key={g.titulo} className="card p-4">
            <h3 className="mb-2 text-sm font-semibold text-gray-800 dark:text-gray-100">{g.titulo}</h3>
            <ul className="space-y-1 text-sm">
              {g.dados.map((d) => (
                <li key={d.categoria} className="flex justify-between border-b border-gray-100 py-1 dark:border-gray-900">
                  <span className="text-gray-600 dark:text-gray-400">{d.categoria}</span>
                  <span className="font-medium">{d.quantidade}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <DonutChart titulo="Plano de Contingência para Superlotação" dados={planoContingencia.map((d) => ({ rotulo: d.categoria, valor: d.quantidade }))} />
        <DonutChart titulo="Disponibilidade de ambulância" dados={ambulancia.map((d) => ({ rotulo: d.categoria, valor: d.quantidade }))} />
      </div>

      {alertasVagaZero.length > 0 && (
        <div className="card border-status-amarelo/40 p-4">
          <h3 className="mb-2 text-sm font-semibold text-status-amarelo">
            Valores extremos sinalizados para revisão — Vaga Zero ({alertasVagaZero.length})
          </h3>
          <ul className="max-h-64 space-y-1 overflow-y-auto text-xs text-gray-600 dark:text-gray-400">
            {alertasVagaZero.map((a, i) => (
              <li key={i}>
                <span className="font-medium">{a.unidade}</span> ({a.municipio}): {a.mensagem}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
