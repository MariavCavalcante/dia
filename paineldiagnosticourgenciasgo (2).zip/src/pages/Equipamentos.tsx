import { useMemo } from "react";
import type { RegistroUnidade } from "../types";
import { BarRanking } from "../components/charts/BarRanking";
import { HeatmapGrid, type CelulaHeatmap } from "../components/charts/HeatmapGrid";
import { ITENS_EQUIPAMENTO } from "../lib/grupos";
import { disponibilidadeNumerica } from "../lib/indicadores";

export default function Equipamentos({ registros }: { registros: RegistroUnidade[] }) {
  const disponibilidade = useMemo(
    () => ITENS_EQUIPAMENTO.map((it) => disponibilidadeNumerica(registros, it.chave, it.rotulo)),
    [registros]
  );

  const { linhas, matriz } = useMemo(() => {
    const unidades = registros.slice(0, 60); // rolagem interna cobre o restante; evita travar o navegador com 172+ linhas
    const linhas = unidades.map((r) => `${r.unidade} (${r.municipio})`);
    const matriz: CelulaHeatmap[][] = unidades.map((r) =>
      ITENS_EQUIPAMENTO.map((it) => {
        const v = r.campos[it.chave];
        const n = typeof v === "number" ? v : null;
        return { valor: n === null ? null : Math.min(1, n / 5), rotulo: n === null ? "Não informado" : `${n} unidade(s)` };
      })
    );
    return { linhas, matriz };
  }, [registros]);

  return (
    <div className="space-y-4">
      <BarRanking
        titulo="Percentual de unidades com o item disponível (valor > 0)"
        itens={disponibilidade.map((d) => ({ rotulo: d.rotulo, valor: Math.round(d.percentual * 100), percentual: d.percentual }))}
        unidade="%"
        permitirTopN={false}
      />
      <HeatmapGrid
        titulo={`Matriz de disponibilidade por unidade e equipamento${registros.length > 60 ? " (primeiras 60 unidades do recorte)" : ""}`}
        linhas={linhas}
        colunas={ITENS_EQUIPAMENTO.map((i) => i.rotulo)}
        matriz={matriz}
      />
    </div>
  );
}
