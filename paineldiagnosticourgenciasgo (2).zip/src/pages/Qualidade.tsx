import { useMemo } from "react";
import type { RegistroUnidade } from "../types";
import { StatCard } from "../components/StatCard";
import { DataTable } from "../components/DataTable";
import { completudePorEixo } from "../lib/indicadores";

export default function Qualidade({
  registros,
  todosOsRegistros,
}: {
  registros: RegistroUnidade[];
  todosOsRegistros: RegistroUnidade[];
}) {
  const completude = useMemo(() => completudePorEixo(registros), [registros]);

  const duplicados = useMemo(() => todosOsRegistros.filter((r) => r.duplicadoCnes), [todosOsRegistros]);
  const atipicos = useMemo(() => todosOsRegistros.filter((r) => r.cnesAtipico), [todosOsRegistros]);
  const residuais = useMemo(() => todosOsRegistros.filter((r) => r.classificacaoResidual), [todosOsRegistros]);
  const comAlertas = useMemo(() => todosOsRegistros.filter((r) => r.alertas.length > 0), [todosOsRegistros]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard titulo="CNES duplicados" valor={duplicados.length} tom="amarelo" />
        <StatCard titulo="CNES com formato atípico" valor={atipicos.length} tom="amarelo" />
        <StatCard titulo="Classificação residual ('Opção 8')" valor={residuais.length} tom="amarelo" />
        <StatCard titulo="Registros com algum alerta" valor={comAlertas.length} />
      </div>

      <div className="card p-4">
        <h3 className="mb-3 text-sm font-semibold text-gray-800 dark:text-gray-100">Completude por eixo (recorte atual)</h3>
        <div className="space-y-2">
          {completude
            .sort((a, b) => a.percentual - b.percentual)
            .map((c) => (
              <div key={c.eixo} className="flex items-center gap-3">
                <span className="w-56 shrink-0 text-xs text-gray-600 dark:text-gray-400">{c.rotulo}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-gray-100 dark:bg-gray-800">
                  <div
                    className="h-full rounded-full bg-go-azul"
                    style={{ width: `${Math.round(c.percentual * 100)}%` }}
                  />
                </div>
                <span className="w-10 shrink-0 text-right text-xs font-medium">{Math.round(c.percentual * 100)}%</span>
              </div>
            ))}
        </div>
      </div>

      <div className="card p-4">
        <h3 className="mb-2 text-sm font-semibold text-gray-800 dark:text-gray-100">
          Tabela de pendências para revisão ({comAlertas.length})
        </h3>
        <p className="mb-3 text-xs text-gray-500 dark:text-gray-400">
          Sem exposição do responsável pelo preenchimento (regra 2.6/2.4). Duplicidades de CNES não são somadas
          automaticamente — a visão consolidada usa a resposta mais recente por CNES.
        </p>
        <DataTable registros={comAlertas} />
      </div>
    </div>
  );
}
