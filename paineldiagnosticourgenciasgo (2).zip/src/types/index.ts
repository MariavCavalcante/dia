// Tipos centrais do painel. Servem de contrato entre a camada de dados
// (scripts, Netlify Function, plugin de dev) e a interface React.

export type EixoId =
  | "identificacao"
  | "leitos"
  | "equipamentos"
  | "imagem"
  | "especialidades"
  | "capacidade_resposta"
  | "regulacao"
  | "trauma"
  | "qualidade";

export type TipoCampo =
  | "data"
  | "texto"
  | "texto_pessoal"
  | "numero"
  | "categoria"
  | "sim_nao"
  | "misto_numero_texto"
  | "duracao_texto";

/** Uma entrada do dicionário de dados: liga a coluna original da planilha
 * a eixo, indicador, tipo, unidade, regra de limpeza e visualização. */
export interface CampoDicionario {
  key: string;
  header: string;
  eixo: EixoId;
  indicador: string;
  grupo: string | null;
  tipo: TipoCampo;
  unidade: string | null;
  categorias: string[] | null;
  regra: string;
  viz: string;
}

/** Valor de um campo misto (numérico ou texto categórico, ex.: "3" ou
 * "Não dispõe da especialidade"). Preserva o original para auditoria. */
export interface ValorMisto {
  numero: number | null;
  texto: string | null;
  original: string | null;
}

/** Alerta de qualidade associado a um registro. */
export interface AlertaQualidade {
  tipo: "cnes_duplicado" | "cnes_atipico" | "valor_extremo" | "categoria_residual" | "campo_ausente";
  campo?: string;
  mensagem: string;
}

/** Registro anonimizado e limpo de uma unidade de saúde respondente. */
export interface RegistroUnidade {
  id: string; // chave técnica estável (cnes normalizado + índice de linha se duplicado)
  linha: number; // posição original na planilha (1-based, após cabeçalho) — para auditoria/dedupe
  carimbo: string; // ISO 8601
  municipio: string;
  municipioNormalizado: string;
  unidade: string;
  cnes: string;
  cnesAtipico: boolean;
  classificacao: string;
  classificacaoResidual: boolean;
  duplicadoCnes: boolean;
  maisRecenteEntreDuplicados: boolean;
  completude: number; // 0..1 — campos analíticos preenchidos / aplicáveis nesta resposta
  alertas: AlertaQualidade[];
  campos: Record<string, string | number | ValorMisto | null>;
}

export interface StatusSincronizacao {
  estado: "atualizado" | "atualizando" | "atrasado" | "falha";
  ultimaTentativa: string | null; // ISO
  ultimoSucesso: string | null; // ISO
  linhasRecebidas: number;
  registrosValidos: number;
  registrosExcluidos: number;
  erro: string | null;
}

export interface DatasetPainel {
  geradoEm: string; // ISO — quando esta resposta foi montada
  fonte: {
    tipo: "csv_publico";
    aba: string;
    urlVariavelAmbiente: "GOOGLE_SHEETS_CSV_URL";
  };
  status: StatusSincronizacao;
  registros: RegistroUnidade[];
  municipiosRespondentes: number;
  totalRespostasValidas: number;
  unidadesDistintas: number;
  cnesDistintos: number;
  completudeGeral: number; // 0..1
}
