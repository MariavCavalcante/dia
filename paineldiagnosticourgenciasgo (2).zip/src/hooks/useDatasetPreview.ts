// Hook usado APENAS na build de demonstração estática (npm run build:demo).
// Em vez de buscar /api/dados (que exige um servidor/Netlify Function), lê um
// snapshot já processado da planilha real, embutido no bundle em tempo de
// build. Isso permite abrir um único arquivo HTML e navegar por todo o
// painel sem precisar de backend — útil para pré-visualização, não substitui
// a integração ao vivo com o Google Forms usada em produção (ver
// src/hooks/useDataset.ts e docs/integracao-google-forms.md).
//
// O snapshot é embutido comprimido (gzip + base64, gerado por
// scripts/comprimir-dataset-preview.mjs a partir de
// src/data/dataset-preview.json) e descomprimido aqui em tempo de execução
// com a API nativa DecompressionStream — sem nenhuma biblioteca extra. Isso
// reduz o JSON de ~1MB para ~50KB no bundle final, o que é essencial para o
// arquivo HTML único caber com folga no limite de tamanho de URL do
// Chromium (~2.097.152 caracteres): esse limite é relevante quando o HTML é
// pré-visualizado via uma URL "data:" (por exemplo, num iframe de preview
// embutido), não apenas quando é aberto localmente com file://.
import { useCallback, useEffect, useState } from "react";
import type { DatasetPainel } from "../types";
import { DATASET_PREVIEW_GZIP_BASE64 } from "../data/dataset-preview.gzip";
import type { UseDatasetResultado } from "./useDataset";

function base64ParaBytes(base64: string): Uint8Array {
  const binario = atob(base64);
  const bytes = new Uint8Array(binario.length);
  for (let i = 0; i < binario.length; i++) bytes[i] = binario.charCodeAt(i);
  return bytes;
}

async function descomprimirSnapshot(): Promise<DatasetPainel> {
  const bytesComprimidos = base64ParaBytes(DATASET_PREVIEW_GZIP_BASE64);
  if (typeof DecompressionStream === "undefined") {
    // Navegador muito antigo, sem suporte à API nativa de descompressão —
    // caso extremamente raro em 2026, mas falha de forma explícita em vez de
    // travar silenciosamente.
    throw new Error(
      "Este navegador não tem suporte à descompressão nativa (DecompressionStream), necessária para a pré-visualização offline. Tente um navegador atualizado (Chrome, Edge, Firefox ou Safari recentes)."
    );
  }
  const streamDescompressao = new DecompressionStream("gzip");
  // Cast necessário: em versões recentes das definições de tipos do DOM,
  // Uint8Array<ArrayBufferLike> (o retorno padrão) não é aceito onde
  // BlobPart exige especificamente Uint8Array<ArrayBuffer> — na prática, em
  // tempo de execução, é sempre um ArrayBuffer comum aqui.
  const stream = new Blob([bytesComprimidos as unknown as BlobPart]).stream().pipeThrough(streamDescompressao);
  const texto = await new Response(stream).text();
  return JSON.parse(texto) as DatasetPainel;
}

export function useDatasetPreview(): UseDatasetResultado {
  const [dataset, setDataset] = useState<DatasetPainel | null>(null);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState<string | null>(null);

  const atualizar = useCallback(async () => {
    // Não-operacional na demonstração estática: não há fonte para revalidar,
    // só re-descomprime o mesmo instantâneo embutido.
  }, []);

  useEffect(() => {
    let cancelado = false;
    descomprimirSnapshot()
      .then((d) => {
        if (!cancelado) setDataset(d);
      })
      .catch((e) => {
        if (!cancelado) setErro(e instanceof Error ? e.message : String(e));
      })
      .finally(() => {
        if (!cancelado) setCarregando(false);
      });
    return () => {
      cancelado = true;
    };
  }, []);

  return { dataset, carregando, atualizando: false, erro, atualizar };
}
