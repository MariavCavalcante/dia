import { useCallback, useEffect, useRef, useState } from "react";
import type { DatasetPainel } from "../types";

// Intervalo de verificação automática — entre 1 e 5 minutos (regra 2.3).
// Configurável via VITE_SYNC_INTERVAL_MS; padrão de 2 minutos.
const INTERVALO_MS = Number(import.meta.env.VITE_SYNC_INTERVAL_MS ?? 120_000);

export interface UseDatasetResultado {
  dataset: DatasetPainel | null;
  carregando: boolean;
  atualizando: boolean;
  erro: string | null;
  atualizar: (forcar?: boolean) => Promise<void>;
}

export function useDataset(): UseDatasetResultado {
  const [dataset, setDataset] = useState<DatasetPainel | null>(null);
  const [carregando, setCarregando] = useState(true);
  const [atualizando, setAtualizando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const primeiraCarga = useRef(true);

  const atualizar = useCallback(async (forcar = false) => {
    if (primeiraCarga.current) setCarregando(true);
    else setAtualizando(true);
    try {
      const resposta = await fetch(`/api/dados${forcar ? "?force=1" : ""}`, {
        headers: { Accept: "application/json" },
      });
      const corpo = await resposta.json();
      if (!resposta.ok || "erro" in corpo) {
        throw new Error(corpo?.erro ?? `Falha ao buscar dados (HTTP ${resposta.status}).`);
      }
      setDataset(corpo as DatasetPainel);
      setErro(null);
    } catch (e) {
      setErro(e instanceof Error ? e.message : String(e));
    } finally {
      primeiraCarga.current = false;
      setCarregando(false);
      setAtualizando(false);
    }
  }, []);

  useEffect(() => {
    atualizar();
    const id = window.setInterval(() => atualizar(), INTERVALO_MS);

    const aoFicarVisivel = () => {
      if (document.visibilityState === "visible") atualizar();
    };
    document.addEventListener("visibilitychange", aoFicarVisivel);

    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", aoFicarVisivel);
    };
  }, [atualizar]);

  return { dataset, carregando, atualizando, erro, atualizar };
}
