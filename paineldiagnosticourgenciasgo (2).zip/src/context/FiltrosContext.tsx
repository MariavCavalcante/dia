import React, { createContext, useContext, useMemo, useState } from "react";
import type { FiltroPainel } from "../lib/indicadores";

interface FiltrosContextValor {
  filtro: FiltroPainel;
  definirFiltro: (parcial: Partial<FiltroPainel>) => void;
  limparFiltros: () => void;
  temFiltrosAtivos: boolean;
}

const FiltrosContext = createContext<FiltrosContextValor | null>(null);

export function FiltrosProvider({ children }: { children: React.ReactNode }) {
  const [filtro, setFiltro] = useState<FiltroPainel>({});

  const definirFiltro = (parcial: Partial<FiltroPainel>) =>
    setFiltro((atual) => ({ ...atual, ...parcial }));

  const limparFiltros = () => setFiltro({});

  const temFiltrosAtivos = useMemo(
    () => Object.values(filtro).some((v) => v !== undefined && v !== ""),
    [filtro]
  );

  return (
    <FiltrosContext.Provider value={{ filtro, definirFiltro, limparFiltros, temFiltrosAtivos }}>
      {children}
    </FiltrosContext.Provider>
  );
}

export function useFiltros(): FiltrosContextValor {
  const ctx = useContext(FiltrosContext);
  if (!ctx) throw new Error("useFiltros deve ser usado dentro de <FiltrosProvider>");
  return ctx;
}
