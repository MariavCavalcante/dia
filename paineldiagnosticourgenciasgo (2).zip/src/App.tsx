import { useMemo, useState } from "react";
import { Route, Routes } from "react-router-dom";
import { Header } from "./components/Header";
import { Sidebar } from "./components/Sidebar";
import { GlobalFilters } from "./components/GlobalFilters";
import { AdvancedSearch } from "./components/AdvancedSearch";
import { useDataset } from "./hooks/useDataset";
import { useDatasetPreview } from "./hooks/useDatasetPreview";
import { FiltrosProvider, useFiltros } from "./context/FiltrosContext";
import { apenasConsolidados } from "./lib/indicadores";
import { aplicarFiltros } from "./lib/indicadores";

import VisaoGeral from "./pages/VisaoGeral";
import Leitos from "./pages/Leitos";
import Equipamentos from "./pages/Equipamentos";
import Imagem from "./pages/Imagem";
import Especialidades from "./pages/Especialidades";
import CapacidadeResposta from "./pages/CapacidadeResposta";
import Regulacao from "./pages/Regulacao";
import Trauma from "./pages/Trauma";
import Qualidade from "./pages/Qualidade";
import Metodologia from "./pages/Metodologia";

const MODO_DEMO_ESTATICO = import.meta.env.VITE_MODO_DEMO === "1";

function ConteudoPainel() {
  // A condição acima é uma constante de build (substituída pelo Vite em tempo
  // de compilação) — apenas um dos dois ramos existe no bundle final, então
  // isto não viola a regra de hooks condicionais entre renderizações.
  const { dataset, carregando, atualizando, erro, atualizar } = MODO_DEMO_ESTATICO
    ? // eslint-disable-next-line react-hooks/rules-of-hooks
      useDatasetPreview()
    : // eslint-disable-next-line react-hooks/rules-of-hooks
      useDataset();
  const { filtro } = useFiltros();
  const [sidebarAberta, setSidebarAberta] = useState(false);

  const registrosConsolidados = useMemo(
    () => (dataset ? apenasConsolidados(dataset.registros) : []),
    [dataset]
  );
  const registrosFiltrados = useMemo(
    () => aplicarFiltros(registrosConsolidados, filtro),
    [registrosConsolidados, filtro]
  );

  return (
    <div className="min-h-screen">
      <a href="#conteudo-principal" className="skip-link">
        Pular para o conteúdo principal
      </a>
      <Header
        status={dataset?.status ?? null}
        atualizando={atualizando}
        onAtualizar={() => atualizar(true)}
        onAlternarMenu={() => setSidebarAberta((v) => !v)}
      />
      {MODO_DEMO_ESTATICO && (
        <div className="bg-status-amarelo/15 px-4 py-1.5 text-center text-xs font-medium text-yellow-900">
          Demonstração estática offline — instantâneo fixo das 172 respostas reais da planilha de referência,
          sem conexão ao vivo com o Google Forms. A versão de produção atualiza automaticamente (ver README).
        </div>
      )}
      <div className="mx-auto flex max-w-[1600px]">
        <Sidebar aberta={sidebarAberta} onFechar={() => setSidebarAberta(false)} />
        <main id="conteudo-principal" className="min-w-0 flex-1 space-y-4 p-4 sm:p-6">
          {carregando ? (
            <div className="card p-8 text-center text-sm text-gray-500">Carregando dados do painel…</div>
          ) : erro && !dataset ? (
            <div className="card border-status-vermelho/40 p-8 text-center text-sm text-status-vermelho">
              Não foi possível carregar os dados agora. {erro}
            </div>
          ) : (
            dataset && (
              <>
                <AdvancedSearch registrosFiltrados={registrosFiltrados} />
                <GlobalFilters registros={registrosConsolidados} />
                <Routes>
                  <Route
                    path="/"
                    element={<VisaoGeral dataset={dataset} registrosConsolidados={registrosConsolidados} registrosFiltrados={registrosFiltrados} />}
                  />
                  <Route path="/leitos" element={<Leitos registros={registrosFiltrados} />} />
                  <Route path="/equipamentos" element={<Equipamentos registros={registrosFiltrados} />} />
                  <Route path="/imagem" element={<Imagem registros={registrosFiltrados} />} />
                  <Route path="/especialidades" element={<Especialidades registros={registrosFiltrados} />} />
                  <Route path="/capacidade-resposta" element={<CapacidadeResposta registros={registrosFiltrados} />} />
                  <Route path="/regulacao" element={<Regulacao registros={registrosFiltrados} />} />
                  <Route path="/trauma" element={<Trauma registros={registrosFiltrados} />} />
                  <Route path="/qualidade" element={<Qualidade registros={registrosFiltrados} todosOsRegistros={dataset.registros} />} />
                  <Route path="/metodologia" element={<Metodologia dataset={dataset} />} />
                </Routes>
              </>
            )
          )}
          <footer className="pt-6 text-center text-[11px] text-gray-400 dark:text-gray-600">
            Painel do Diagnóstico Situacional da Rede de Atenção às Urgências — Secretaria de Estado da Saúde de
            Goiás. Dados anonimizados; consulte a página de Metodologia para regras de cálculo e dicionário de
            dados.
          </footer>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <FiltrosProvider>
      <ConteudoPainel />
    </FiltrosProvider>
  );
}
