import type { StatusSincronizacao } from "../types";

function formatarHorario(iso: string | null): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

const ESTADO_CONFIG: Record<
  StatusSincronizacao["estado"],
  { rotulo: string; cor: string; ponto: string }
> = {
  atualizado: { rotulo: "Atualizado", cor: "text-status-verde", ponto: "bg-status-verde" },
  atualizando: { rotulo: "Atualizando…", cor: "text-go-azul", ponto: "bg-go-azul animate-pulse" },
  atrasado: { rotulo: "Atualização atrasada", cor: "text-status-amarelo", ponto: "bg-status-amarelo" },
  falha: { rotulo: "Falha de sincronização", cor: "text-status-vermelho", ponto: "bg-status-vermelho" },
};

export function SyncBadge({
  status,
  atualizando,
  onAtualizar,
}: {
  status: StatusSincronizacao | null;
  atualizando: boolean;
  onAtualizar: () => void;
}) {
  const estadoEfetivo = atualizando ? "atualizando" : (status?.estado ?? "falha");
  const cfg = ESTADO_CONFIG[estadoEfetivo];

  return (
    <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm">
      <span className="flex items-center gap-1.5" role="status" aria-live="polite">
        <span className={`h-2 w-2 rounded-full ${cfg.ponto}`} aria-hidden="true" />
        <span className={`font-medium ${cfg.cor}`}>{cfg.rotulo}</span>
      </span>
      <span className="text-gray-500 dark:text-gray-400">
        Última sincronização: {formatarHorario(status?.ultimoSucesso ?? null)} (America/Sao_Paulo)
      </span>
      <button
        type="button"
        onClick={onAtualizar}
        className="btn-secondary !px-2.5 !py-1 text-xs"
        aria-label="Atualizar dados agora"
        disabled={atualizando}
      >
        {atualizando ? "Atualizando…" : "Atualizar dados agora"}
      </button>
      {status?.erro && status.estado === "falha" && (
        <span className="chip !border-status-vermelho/30 !bg-status-vermelho/10 !text-status-vermelho">
          Exibindo última versão válida — {status.erro}
        </span>
      )}
    </div>
  );
}
