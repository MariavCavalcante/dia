import { Link, useLocation } from "react-router-dom";
import { NAVEGACAO } from "../lib/navegacao";

export function Sidebar({ aberta, onFechar }: { aberta: boolean; onFechar: () => void }) {
  // Comparação manual do caminho ativo (em vez de <NavLink>'s isActive) —
  // internamente o React Router calcula isActive chamando
  // history.encodeLocation(), que constrói "new URL(caminho, origem)". Isso
  // lança "TypeError: Failed to construct 'URL': Invalid URL" sempre que a
  // página é renderizada num documento com origem opaca (ex.: iframe
  // srcdoc/sandboxed, como no preview embutido do Cowork), pois
  // window.location.origin vira a string "null" e o React Router cai para
  // window.location.href ("about:srcdoc") como base — e resolver um caminho
  // relativo contra um esquema "about:" não é suportado pelo parser de URL.
  // Comparar a string do pathname diretamente evita esse construtor por
  // completo, sem perder o destaque do item ativo no menu.
  const { pathname } = useLocation();
  return (
    <>
      {aberta && (
        <div
          className="fixed inset-0 z-30 bg-black/30 lg:hidden"
          onClick={onFechar}
          aria-hidden="true"
        />
      )}
      <nav
        aria-label="Navegação principal do painel"
        className={`fixed inset-y-0 left-0 z-40 w-72 shrink-0 transform overflow-y-auto border-r border-gray-200 bg-white pb-8 pt-4 transition-transform dark:border-gray-800 dark:bg-gray-950 lg:sticky lg:top-[73px] lg:h-[calc(100vh-73px)] lg:translate-x-0 ${
          aberta ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <ul className="flex flex-col gap-1 px-3">
          {NAVEGACAO.map((item) => {
            const ativo =
              item.rota === "/" ? pathname === "/" : pathname === item.rota || pathname.startsWith(`${item.rota}/`);
            return (
              <li key={item.rota}>
                <Link
                  to={item.rota}
                  onClick={onFechar}
                  aria-current={ativo ? "page" : undefined}
                  className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                    ativo
                      ? "bg-go-azul text-white"
                      : "text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-900"
                  }`}
                >
                  <span aria-hidden="true">{item.icone}</span>
                  {item.rotulo}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </>
  );
}
