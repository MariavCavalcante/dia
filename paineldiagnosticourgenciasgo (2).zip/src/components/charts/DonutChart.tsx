import { Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { CATEGORICA_LIGHT, STATUS } from "../../lib/paleta";

export function DonutChart({
  titulo,
  dados,
  paleta = CATEGORICA_LIGHT,
}: {
  titulo: string;
  dados: { rotulo: string; valor: number }[];
  paleta?: string[];
}) {
  const total = dados.reduce((a, d) => a + d.valor, 0);
  const cores = [...paleta, STATUS.cinza, STATUS.amarelo];

  return (
    <div className="card p-4">
      <h3 className="mb-2 text-sm font-semibold text-gray-800 dark:text-gray-100">{titulo}</h3>
      {dados.length === 0 || total === 0 ? (
        <p className="py-8 text-center text-sm text-gray-500">Sem dados para o recorte atual.</p>
      ) : (
        <ResponsiveContainer width="100%" height={220}>
          <PieChart>
            <Pie
              data={dados}
              dataKey="valor"
              nameKey="rotulo"
              innerRadius={50}
              outerRadius={80}
              paddingAngle={2}
              stroke="#fff"
              strokeWidth={2}
            >
              {dados.map((_, i) => (
                <Cell key={i} fill={cores[i % cores.length]} />
              ))}
            </Pie>
            <Tooltip formatter={(v: number, n) => [`${v} (${Math.round((v / total) * 100)}%)`, n]} />
            <Legend wrapperStyle={{ fontSize: 11 }} layout="vertical" align="right" verticalAlign="middle" />
          </PieChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
