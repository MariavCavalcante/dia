import { SEQUENCIAL_AZUL } from "../../lib/paleta";

export interface CelulaHeatmap {
  valor: number | null; // 0..1, ou null para "não informado"
  rotulo?: string; // texto do tooltip/acessibilidade
}

function corPara(valor: number | null): string {
  if (valor === null) return "#f3f4f6";
  const idx = Math.min(SEQUENCIAL_AZUL.length - 1, Math.round(valor * (SEQUENCIAL_AZUL.length - 1)));
  return SEQUENCIAL_AZUL[idx];
}

/** Matriz unidade × equipamento (ou especialidade), com rótulos legíveis por
 * leitor de tela via <table> semântica — o heatmap é apenas o reforço visual
 * (regra 2.11: nunca depender só de cor). Rolagem interna evita achatar o
 * layout quando há muitas linhas/colunas. */
export function HeatmapGrid({
  titulo,
  linhas,
  colunas,
  matriz,
}: {
  titulo: string;
  linhas: string[];
  colunas: string[];
  matriz: CelulaHeatmap[][]; // matriz[linha][coluna]
}) {
  return (
    <div className="card p-4">
      <h3 className="mb-2 text-sm font-semibold text-gray-800 dark:text-gray-100">{titulo}</h3>
      {linhas.length === 0 ? (
        <p className="py-8 text-center text-sm text-gray-500">Sem dados para o recorte atual.</p>
      ) : (
        <div className="max-h-[420px] overflow-auto rounded border border-gray-200 dark:border-gray-800">
          <table className="min-w-full border-collapse text-xs">
            <caption className="sr-only">{titulo}</caption>
            <thead className="sticky top-0 z-10 bg-white dark:bg-gray-900">
              <tr>
                <th scope="col" className="sticky left-0 z-20 min-w-[180px] border-b border-r border-gray-200 bg-white p-2 text-left dark:border-gray-800 dark:bg-gray-900">
                  Unidade
                </th>
                {colunas.map((c) => (
                  <th key={c} scope="col" className="min-w-[64px] border-b border-gray-200 p-1 text-center font-medium dark:border-gray-800">
                    <span className="line-clamp-3 leading-tight">{c}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {linhas.map((linha, i) => (
                <tr key={linha + i}>
                  <th scope="row" className="sticky left-0 z-10 min-w-[180px] border-r border-gray-200 bg-white p-2 text-left font-normal dark:border-gray-800 dark:bg-gray-900">
                    {linha}
                  </th>
                  {colunas.map((_, j) => {
                    const cel = matriz[i]?.[j];
                    return (
                      <td
                        key={j}
                        className="border-b border-gray-100 p-0 text-center dark:border-gray-900"
                        title={cel?.rotulo}
                      >
                        <div
                          className="mx-auto my-1 h-5 w-5 rounded"
                          style={{ backgroundColor: corPara(cel?.valor ?? null) }}
                          aria-label={cel?.rotulo ?? "Não informado"}
                        />
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <div className="mt-2 flex items-center gap-2 text-[11px] text-gray-500 dark:text-gray-400">
        <span>Menor</span>
        {SEQUENCIAL_AZUL.map((c) => (
          <span key={c} className="h-3 w-3 rounded" style={{ backgroundColor: c }} />
        ))}
        <span>Maior</span>
        <span className="ml-3 h-3 w-3 rounded bg-gray-100" /> <span>Não informado</span>
      </div>
    </div>
  );
}
