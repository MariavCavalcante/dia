import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { CATEGORICA_LIGHT, STATUS, TINTA } from "../../lib/paleta";

export interface SerieEmpilhada {
  chave: string;
  rotulo: string;
  cor?: string;
}

export function StackedBarChart({
  titulo,
  dados,
  series,
  percentual = true,
}: {
  titulo: string;
  dados: Record<string, string | number>[];
  series: SerieEmpilhada[];
  percentual?: boolean;
}) {
  const altura = Math.max(160, dados.length * 34 + 60);
  const cores = [STATUS.verde, STATUS.amarelo, CATEGORICA_LIGHT[0], STATUS.cinza, STATUS.vermelho];

  return (
    <div className="card p-4">
      <h3 className="mb-2 text-sm font-semibold text-gray-800 dark:text-gray-100">{titulo}</h3>
      {dados.length === 0 ? (
        <p className="py-8 text-center text-sm text-gray-500">Sem dados para o recorte atual.</p>
      ) : (
        <ResponsiveContainer width="100%" height={altura}>
          <BarChart data={dados} layout="vertical" margin={{ left: 8, right: 16, top: 4, bottom: 4 }}>
            <CartesianGrid stroke={TINTA.grade} horizontal={false} />
            <XAxis
              type="number"
              stroke={TINTA.muted}
              fontSize={11}
              domain={percentual ? [0, 100] : undefined}
              unit={percentual ? "%" : undefined}
            />
            <YAxis type="category" dataKey="rotulo" stroke={TINTA.muted} fontSize={11} width={150} />
            <Tooltip />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            {series.map((s, i) => (
              <Bar key={s.chave} dataKey={s.chave} name={s.rotulo} stackId="a" fill={s.cor ?? cores[i % cores.length]} maxBarSize={20} />
            ))}
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
