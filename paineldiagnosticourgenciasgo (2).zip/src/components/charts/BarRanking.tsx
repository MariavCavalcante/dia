import { useState } from "react";
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { CATEGORICA_LIGHT, TINTA } from "../../lib/paleta";

export interface ItemRanking {
  rotulo: string;
  valor: number;
  percentual?: number;
}

export function BarRanking({
  titulo,
  itens,
  unidade = "",
  permitirTopN = true,
  corBarra = CATEGORICA_LIGHT[0],
}: {
  titulo: string;
  itens: ItemRanking[];
  unidade?: string;
  permitirTopN?: boolean;
  corBarra?: string;
}) {
  const [topN, setTopN] = useState<5 | 10 | 999>(10);
  const dados = itens.slice(0, topN).map((i) => ({ ...i, rotuloCurto: i.rotulo.length > 28 ? `${i.rotulo.slice(0, 27)}…` : i.rotulo }));
  const altura = Math.max(160, dados.length * 32 + 40);

  return (
    <div className="card p-4">
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <h3 className="text-sm font-semibold text-gray-800 dark:text-gray-100">{titulo}</h3>
        {permitirTopN && (
          <div className="flex gap-1" role="group" aria-label="Selecionar quantidade exibida">
            {[5, 10, 999].map((n) => (
              <button
                key={n}
                onClick={() => setTopN(n as 5 | 10 | 999)}
                className={`rounded px-2 py-1 text-xs font-medium ${
                  topN === n ? "bg-go-azul text-white" : "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300"
                }`}
                aria-pressed={topN === n}
              >
                {n === 999 ? "Todos" : `Top ${n}`}
              </button>
            ))}
          </div>
        )}
      </div>
      {dados.length === 0 ? (
        <p className="py-8 text-center text-sm text-gray-500">Sem dados para o recorte atual.</p>
      ) : (
        <ResponsiveContainer width="100%" height={altura}>
          <BarChart data={dados} layout="vertical" margin={{ left: 8, right: 24, top: 4, bottom: 4 }}>
            <CartesianGrid stroke={TINTA.grade} horizontal={false} />
            <XAxis type="number" stroke={TINTA.muted} fontSize={11} allowDecimals={false} />
            <YAxis type="category" dataKey="rotuloCurto" stroke={TINTA.muted} fontSize={11} width={140} />
            <Tooltip
              formatter={((valor: number, _n: unknown, item: any) => [
                `${valor}${unidade ? ` ${unidade}` : ""}${item?.payload?.percentual !== undefined ? ` (${Math.round(item.payload.percentual * 100)}%)` : ""}`,
                "Valor",
              ]) as any}
              labelFormatter={((_l: unknown, payload: any) => payload?.[0]?.payload?.rotulo ?? "") as any}
            />
            <Bar dataKey="valor" radius={[0, 4, 4, 0]} maxBarSize={18}>
              {dados.map((_, i) => (
                <Cell key={i} fill={corBarra} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
