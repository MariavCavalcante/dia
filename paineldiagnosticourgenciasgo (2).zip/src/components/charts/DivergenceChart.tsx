import { Bar, BarChart, CartesianGrid, Cell, Legend, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { DivergenciaLeitos } from "../../lib/indicadores";
import { DIVERGENTE, TINTA } from "../../lib/paleta";

export function DivergenceChart({ dados }: { dados: DivergenciaLeitos[] }) {
  const dadosGrafico = dados.map((d) => ({ ...d, diferencaExibida: d.diferenca }));

  return (
    <div className="card p-4">
      <h3 className="mb-1 text-sm font-semibold text-gray-800 dark:text-gray-100">
        Divergência: leitos operacionais SUS vs. cadastrados no CNES
      </h3>
      <p className="mb-2 text-xs text-gray-500 dark:text-gray-400">
        Positivo = mais leitos operacionais do que cadastrados. Negativo = mais leitos cadastrados do que
        operacionalmente disponíveis.
      </p>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={dadosGrafico} margin={{ left: 8, right: 16, top: 8, bottom: 4 }}>
          <CartesianGrid stroke={TINTA.grade} vertical={false} />
          <XAxis dataKey="tipo" stroke={TINTA.muted} fontSize={12} />
          <YAxis stroke={TINTA.muted} fontSize={11} allowDecimals={false} />
          <ReferenceLine y={0} stroke={TINTA.muted} />
          <Tooltip />
          <Legend wrapperStyle={{ fontSize: 11 }} />
          <Bar
            dataKey="diferencaExibida"
            name="Diferença (operacional − CNES)"
            radius={[4, 4, 0, 0]}
            maxBarSize={48}
          >
            {dadosGrafico.map((d, i) => (
              <Cell key={i} fill={d.diferenca >= 0 ? DIVERGENTE.positivo : DIVERGENTE.negativo} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      <dl className="mt-3 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
        {dados.map((d) => (
          <div key={d.tipo} className="rounded border border-gray-200 p-2 dark:border-gray-800">
            <dt className="font-medium text-gray-600 dark:text-gray-300">{d.tipo}</dt>
            <dd className="text-gray-500 dark:text-gray-400">
              SUS: {d.operacionalSus} · CNES: {d.cadastradoCnes}
            </dd>
            <dd className={d.diferenca === 0 ? "text-gray-500" : d.diferenca > 0 ? "text-status-verde" : "text-status-vermelho"}>
              Diferença: {d.diferenca > 0 ? "+" : ""}
              {d.diferenca}
            </dd>
          </div>
        ))}
      </dl>
      <p className="sr-only">
        Cores da divergência: {DIVERGENTE.positivo} para diferença positiva, {DIVERGENTE.negativo} para negativa.
      </p>
    </div>
  );
}
