import { useFiltros } from "../context/FiltrosContext";

// Regra 2.7.3: balão de destaque "Municípios que responderam". Sem filtros,
// mostra a contagem de municípios respondentes da base (fotografia inicial:
// 144). Com filtro/pesquisa ativos, mostra a contagem no recorte filtrado.
// Nunca usa o total oficial de 246 municípios como denominador sem fonte e
// regra metodológica documentada (regra 2.7.3 / 2.8) — por isso o percentual
// exibido aqui é sempre sobre o universo respondente, nunca sobre os 246.
export function BalaoMunicipios({
  municipiosNoRecorte,
  municipiosTotalRespondentes,
  temFiltro,
  aoClicar,
}: {
  municipiosNoRecorte: number;
  municipiosTotalRespondentes: number;
  temFiltro: boolean;
  aoClicar: () => void;
}) {
  const { limparFiltros } = useFiltros();
  const percentual =
    municipiosTotalRespondentes > 0 ? Math.round((municipiosNoRecorte / municipiosTotalRespondentes) * 100) : 0;

  return (
    <button
      type="button"
      onClick={aoClicar}
      className="card flex w-full flex-col gap-1 border-go-azul/40 p-4 text-left transition hover:shadow-md sm:w-auto"
    >
      <span className="text-xs font-medium uppercase tracking-wide text-go-azul dark:text-blue-300">
        Municípios que responderam
      </span>
      <span className="text-3xl font-bold text-gray-900 dark:text-gray-50">
        {temFiltro ? `${municipiosNoRecorte} município(s) encontrado(s)` : municipiosNoRecorte}
      </span>
      <span className="text-xs text-gray-500 dark:text-gray-400">
        {temFiltro
          ? `${percentual}% dos ${municipiosTotalRespondentes} municípios respondentes da base atual`
          : `de um total de ${municipiosTotalRespondentes} municípios que já enviaram respostas`}
      </span>
      {temFiltro && (
        <span
          role="link"
          tabIndex={-1}
          onClick={(e) => {
            e.stopPropagation();
            limparFiltros();
          }}
          className="mt-1 text-xs font-medium text-go-azul underline"
        >
          Limpar pesquisa e voltar à visão geral
        </span>
      )}
    </button>
  );
}
