export function StatCard({
  titulo,
  valor,
  subtitulo,
  onClick,
  tom = "neutro",
}: {
  titulo: string;
  valor: string | number;
  subtitulo?: string;
  onClick?: () => void;
  tom?: "neutro" | "verde" | "amarelo" | "vermelho" | "azul";
}) {
  const bordas: Record<string, string> = {
    neutro: "border-gray-200 dark:border-gray-800",
    verde: "border-status-verde/40",
    amarelo: "border-status-amarelo/40",
    vermelho: "border-status-vermelho/40",
    azul: "border-go-azul/40",
  };

  const Componente = onClick ? "button" : "div";

  return (
    <Componente
      onClick={onClick}
      className={`card flex flex-col gap-1 border p-4 text-left ${bordas[tom]} ${
        onClick ? "cursor-pointer transition hover:shadow-md" : ""
      }`}
    >
      <span className="text-xs font-medium uppercase tracking-wide text-gray-500 dark:text-gray-400">{titulo}</span>
      <span className="text-2xl font-bold text-gray-900 dark:text-gray-50">{valor}</span>
      {subtitulo && <span className="text-xs text-gray-500 dark:text-gray-400">{subtitulo}</span>}
    </Componente>
  );
}
