import { useState } from "react";
import type { StatusSincronizacao } from "../types";
import { SyncBadge } from "./SyncBadge";

export function Header({
  status,
  atualizando,
  onAtualizar,
  onAlternarMenu,
}: {
  status: StatusSincronizacao | null;
  atualizando: boolean;
  onAtualizar: () => void;
  onAlternarMenu: () => void;
}) {
  const [altoContraste, setAltoContraste] = useState(false);

  function alternarContraste() {
    const novo = !altoContraste;
    setAltoContraste(novo);
    document.documentElement.classList.toggle("contraste-alto", novo);
  }

  return (
    <header className="sticky top-0 z-40 border-b border-go-azul/20 bg-white/95 backdrop-blur dark:bg-gray-950/95">
      {/*
        Duas linhas empilhadas (marca / status+ações), cada uma ocupando a
        largura total do cabeçalho — em vez de um único container
        flex-wrap com 4 itens, cuja largura do bloco de status dependia do
        conteúdo interno e sobrava espaço em branco de forma inconsistente
        em larguras intermediárias (ex.: painel embutido mais estreito que
        um monitor de desktop). Em telas grandes (lg+) as duas linhas
        voltam a ficar lado a lado, como uma barra única.
      */}
      <div className="mx-auto flex max-w-[1600px] flex-col gap-2 px-4 py-3 sm:px-6 lg:flex-row lg:items-center lg:justify-between lg:gap-4">
        <div className="flex min-w-0 items-center gap-4">
          <button
            type="button"
            onClick={onAlternarMenu}
            className="btn-secondary !p-2 lg:hidden"
            aria-label="Abrir ou fechar menu de navegação"
          >
            <span aria-hidden="true">☰</span>
          </button>

          {/*
            Sem o Brasão Oficial (removido a pedido — ver
            docs/identidade-visual.md). Em seu lugar, uma barra decorativa
            discreta nas cores oficiais do Estado de Goiás (azul e verde
            institucionais, com um traço fino de amarelo — usado com
            parcimônia, conforme a paleta oficial), só para manter a
            identidade visual do cabeçalho.
          */}
          <span
            aria-hidden="true"
            className="flex h-12 w-1.5 shrink-0 flex-col overflow-hidden rounded-full"
          >
            <span className="flex-1 bg-go-azul" />
            <span className="h-1 bg-go-amarelo" />
            <span className="flex-1 bg-go-verde" />
          </span>

          <div className="min-w-0 flex-1">
            <p className="truncate text-[11px] font-semibold uppercase tracking-wide text-go-azul dark:text-blue-300">
              Governo do Estado de Goiás · Secretaria de Estado da Saúde
            </p>
            <h1 className="truncate text-base font-bold text-gray-900 dark:text-gray-50 sm:text-lg">
              Painel do Diagnóstico Situacional da Rede de Atenção às Urgências
            </h1>
            <p className="text-xs text-gray-500 dark:text-gray-400">Estado de Goiás</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-go-azul/10 pt-2 dark:border-gray-800 lg:justify-end lg:border-t-0 lg:pt-0">
          <SyncBadge status={status} atualizando={atualizando} onAtualizar={onAtualizar} />
          <button
            type="button"
            onClick={alternarContraste}
            className="btn-secondary shrink-0 !px-2.5 !py-1 text-xs"
            aria-pressed={altoContraste}
          >
            {altoContraste ? "Contraste padrão" : "Alto contraste"}
          </button>
        </div>
      </div>
    </header>
  );
}
