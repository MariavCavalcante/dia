import { useMemo, useState } from "react";
import type { RegistroUnidade } from "../types";
import { exportarRegistrosCsv } from "../lib/exportar";

export interface ColunaTabela {
  key: string;
  rotulo: string;
  obter: (r: RegistroUnidade) => string | number;
  ordenavel?: boolean;
}

const COLUNAS_BASE: ColunaTabela[] = [
  { key: "municipio", rotulo: "Município", obter: (r) => r.municipio, ordenavel: true },
  { key: "unidade", rotulo: "Unidade de Saúde", obter: (r) => r.unidade, ordenavel: true },
  { key: "cnes", rotulo: "CNES", obter: (r) => r.cnes, ordenavel: true },
  { key: "classificacao", rotulo: "Classificação", obter: (r) => r.classificacao, ordenavel: true },
  { key: "carimbo", rotulo: "Data da resposta", obter: (r) => new Date(r.carimbo).toLocaleDateString("pt-BR"), ordenavel: true },
  { key: "completude", rotulo: "Completude", obter: (r) => `${Math.round(r.completude * 100)}%`, ordenavel: true },
  { key: "alertas", rotulo: "Alertas", obter: (r) => r.alertas.length, ordenavel: true },
];

export function DataTable({ registros, tamanhoPagina = 15 }: { registros: RegistroUnidade[]; tamanhoPagina?: number }) {
  const [colunasVisiveis, setColunasVisiveis] = useState<Set<string>>(new Set(COLUNAS_BASE.map((c) => c.key)));
  const [ordenacao, setOrdenacao] = useState<{ coluna: string; direcao: "asc" | "desc" }>({
    coluna: "municipio",
    direcao: "asc",
  });
  const [pagina, setPagina] = useState(1);
  const [expandidoId, setExpandidoId] = useState<string | null>(null);

  const colunas = COLUNAS_BASE.filter((c) => colunasVisiveis.has(c.key));

  const ordenados = useMemo(() => {
    const coluna = COLUNAS_BASE.find((c) => c.key === ordenacao.coluna);
    if (!coluna) return registros;
    const copia = [...registros];
    copia.sort((a, b) => {
      const va = coluna.obter(a);
      const vb = coluna.obter(b);
      const cmp = typeof va === "number" && typeof vb === "number" ? va - vb : String(va).localeCompare(String(vb), "pt-BR");
      return ordenacao.direcao === "asc" ? cmp : -cmp;
    });
    return copia;
  }, [registros, ordenacao]);

  const totalPaginas = Math.max(1, Math.ceil(ordenados.length / tamanhoPagina));
  const paginaAtual = Math.min(pagina, totalPaginas);
  const visiveis = ordenados.slice((paginaAtual - 1) * tamanhoPagina, paginaAtual * tamanhoPagina);

  function alternarOrdenacao(colunaKey: string) {
    setOrdenacao((atual) =>
      atual.coluna === colunaKey ? { coluna: colunaKey, direcao: atual.direcao === "asc" ? "desc" : "asc" } : { coluna: colunaKey, direcao: "asc" }
    );
  }

  return (
    <div className="card p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h3 className="text-sm font-semibold text-gray-800 dark:text-gray-100">
          Tabela detalhada ({ordenados.length} registro(s))
        </h3>
        <div className="flex flex-wrap items-center gap-2">
          <details className="relative">
            <summary className="btn-secondary cursor-pointer !py-1 text-xs">Colunas</summary>
            <div className="absolute right-0 z-20 mt-1 w-56 rounded-lg border border-gray-200 bg-white p-2 shadow-lg dark:border-gray-800 dark:bg-gray-900">
              {COLUNAS_BASE.map((c) => (
                <label key={c.key} className="flex items-center gap-2 rounded px-2 py-1 text-xs hover:bg-gray-50 dark:hover:bg-gray-800">
                  <input
                    type="checkbox"
                    checked={colunasVisiveis.has(c.key)}
                    onChange={(e) => {
                      const novo = new Set(colunasVisiveis);
                      if (e.target.checked) novo.add(c.key);
                      else novo.delete(c.key);
                      setColunasVisiveis(novo);
                    }}
                  />
                  {c.rotulo}
                </label>
              ))}
            </div>
          </details>
          <button
            type="button"
            className="btn-secondary !py-1 text-xs"
            onClick={() => exportarRegistrosCsv(ordenados)}
            aria-label="Exportar recorte filtrado e anonimizado em CSV"
          >
            Exportar recorte (CSV)
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full border-collapse text-sm">
          <thead>
            <tr className="border-b border-gray-200 dark:border-gray-800">
              {colunas.map((c) => (
                <th key={c.key} scope="col" className="p-2 text-left font-semibold text-gray-600 dark:text-gray-300">
                  {c.ordenavel ? (
                    <button
                      type="button"
                      onClick={() => alternarOrdenacao(c.key)}
                      className="inline-flex items-center gap-1 hover:text-go-azul"
                    >
                      {c.rotulo}
                      {ordenacao.coluna === c.key && <span aria-hidden="true">{ordenacao.direcao === "asc" ? "▲" : "▼"}</span>}
                    </button>
                  ) : (
                    c.rotulo
                  )}
                </th>
              ))}
              <th scope="col" className="p-2 text-left font-semibold text-gray-600 dark:text-gray-300">
                Detalhes
              </th>
            </tr>
          </thead>
          <tbody>
            {visiveis.map((r) => (
              <>
                <tr key={r.id} className="border-b border-gray-100 hover:bg-gray-50 dark:border-gray-900 dark:hover:bg-gray-900">
                  {colunas.map((c) => (
                    <td key={c.key} className="p-2 text-gray-700 dark:text-gray-300">
                      {c.obter(r)}
                    </td>
                  ))}
                  <td className="p-2">
                    <button
                      type="button"
                      className="text-xs font-medium text-go-azul underline"
                      onClick={() => setExpandidoId(expandidoId === r.id ? null : r.id)}
                      aria-expanded={expandidoId === r.id}
                    >
                      {expandidoId === r.id ? "Ocultar" : "Ver mais"}
                    </button>
                  </td>
                </tr>
                {expandidoId === r.id && (
                  <tr className="bg-gray-50 dark:bg-gray-900">
                    <td colSpan={colunas.length + 1} className="p-3">
                      <p className="mb-1 text-xs font-semibold text-gray-600 dark:text-gray-300">
                        Alertas de qualidade ({r.alertas.length})
                      </p>
                      {r.alertas.length === 0 ? (
                        <p className="text-xs text-gray-500">Nenhum alerta para este registro.</p>
                      ) : (
                        <ul className="list-inside list-disc text-xs text-gray-600 dark:text-gray-400">
                          {r.alertas.map((a, i) => (
                            <li key={i}>{a.mensagem}</li>
                          ))}
                        </ul>
                      )}
                    </td>
                  </tr>
                )}
              </>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-3 flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
        <span>
          Página {paginaAtual} de {totalPaginas}
        </span>
        <div className="flex gap-2">
          <button className="btn-secondary !py-1 text-xs" disabled={paginaAtual <= 1} onClick={() => setPagina((p) => p - 1)}>
            Anterior
          </button>
          <button className="btn-secondary !py-1 text-xs" disabled={paginaAtual >= totalPaginas} onClick={() => setPagina((p) => p + 1)}>
            Próxima
          </button>
        </div>
      </div>
    </div>
  );
}
