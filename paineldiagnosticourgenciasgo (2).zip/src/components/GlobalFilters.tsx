import { useMemo } from "react";
import { useFiltros } from "../context/FiltrosContext";
import type { RegistroUnidade } from "../types";

export function GlobalFilters({ registros }: { registros: RegistroUnidade[] }) {
  const { filtro, definirFiltro, limparFiltros } = useFiltros();

  const municipios = useMemo(() => {
    const mapa = new Map<string, string>();
    for (const r of registros) mapa.set(r.municipioNormalizado, r.municipio);
    return [...mapa.entries()].sort((a, b) => a[1].localeCompare(b[1], "pt-BR"));
  }, [registros]);

  const classificacoes = useMemo(
    () => [...new Set(registros.map((r) => r.classificacao))].sort((a, b) => a.localeCompare(b, "pt-BR")),
    [registros]
  );

  return (
    <div className="card flex flex-wrap items-end gap-3 p-4">
      <div className="flex flex-col gap-1">
        <label htmlFor="filtro-municipio" className="text-xs font-semibold text-gray-600 dark:text-gray-400">
          Município
        </label>
        <select
          id="filtro-municipio"
          value={filtro.municipio ?? ""}
          onChange={(e) => definirFiltro({ municipio: e.target.value || undefined })}
          className="min-w-[180px] rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
        >
          <option value="">Todos os municípios</option>
          {municipios.map(([chave, nome]) => (
            <option key={chave} value={chave}>
              {nome}
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1">
        <label htmlFor="filtro-classificacao" className="text-xs font-semibold text-gray-600 dark:text-gray-400">
          Classificação do estabelecimento
        </label>
        <select
          id="filtro-classificacao"
          value={filtro.classificacao ?? ""}
          onChange={(e) => definirFiltro({ classificacao: e.target.value || undefined })}
          className="min-w-[220px] rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
        >
          <option value="">Todas as classificações</option>
          {classificacoes.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1">
        <label htmlFor="filtro-periodo-inicio" className="text-xs font-semibold text-gray-600 dark:text-gray-400">
          Período — de
        </label>
        <input
          id="filtro-periodo-inicio"
          type="date"
          value={filtro.periodoInicio?.slice(0, 10) ?? ""}
          onChange={(e) => definirFiltro({ periodoInicio: e.target.value ? `${e.target.value}T00:00:00` : undefined })}
          className="rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label htmlFor="filtro-periodo-fim" className="text-xs font-semibold text-gray-600 dark:text-gray-400">
          Período — até
        </label>
        <input
          id="filtro-periodo-fim"
          type="date"
          value={filtro.periodoFim?.slice(0, 10) ?? ""}
          onChange={(e) => definirFiltro({ periodoFim: e.target.value ? `${e.target.value}T23:59:59` : undefined })}
          className="rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
        />
      </div>

      <div className="ml-auto flex gap-2">
        <button type="button" className="btn-secondary" onClick={limparFiltros}>
          Limpar filtros
        </button>
        <button
          type="button"
          className="btn-secondary"
          onClick={() => {
            limparFiltros();
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
        >
          Restaurar visão inicial
        </button>
      </div>
    </div>
  );
}
