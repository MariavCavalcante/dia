import { STATUS } from "../lib/paleta";

const CONFIG: Record<string, { rotulo: string; cor: string; icone: string }> = {
  verde: { rotulo: "Disponível", cor: STATUS.verde, icone: "✔" },
  amarelo: { rotulo: "Atenção", cor: STATUS.amarelo, icone: "!" },
  vermelho: { rotulo: "Indisponível", cor: STATUS.vermelho, icone: "✕" },
  cinza: { rotulo: "Não informado", cor: STATUS.cinza, icone: "?" },
};

/** Semáforo textual (cor + ícone + rótulo — nunca cor isolada, regra 2.11). */
export function SemaforoBadge({ estado, rotuloPersonalizado }: { estado: "verde" | "amarelo" | "vermelho" | "cinza"; rotuloPersonalizado?: string }) {
  const cfg = CONFIG[estado];
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium"
      style={{ backgroundColor: `${cfg.cor}1A`, color: cfg.cor }}
    >
      <span aria-hidden="true">{cfg.icone}</span>
      {rotuloPersonalizado ?? cfg.rotulo}
    </span>
  );
}
