import { useMemo, useState } from "react";
import { useFiltros } from "../context/FiltrosContext";
import type { RegistroUnidade } from "../types";

// Grupos do menu "Buscar por" (regra 2.7.1). Os quatro campos de
// identificação têm busca textual direta e imediata nesta v1; os demais
// eixos (leitos, equipamentos, especialidades, capacidade de resposta,
// regulação) são explorados via os filtros e tabelas de cada página
// temática, que já respeitam o mesmo contexto de busca/filtro global —
// ver docs/metodologia.md, seção "Escopo da busca avançada".
const GRUPOS_BUSCA: { grupo: string; opcoes: { valor: string; rotulo: string }[] }[] = [
  {
    grupo: "Identificação",
    opcoes: [
      { valor: "todos", rotulo: "Todos os campos relevantes" },
      { valor: "municipio", rotulo: "Município" },
      { valor: "unidade", rotulo: "Nome da Unidade de Saúde" },
      { valor: "cnes", rotulo: "Número do CNES" },
      { valor: "classificacao", rotulo: "Classificação do Estabelecimento" },
    ],
  },
];

export function AdvancedSearch({ registrosFiltrados }: { registrosFiltrados: RegistroUnidade[] }) {
  const { filtro, definirFiltro, limparFiltros, temFiltrosAtivos } = useFiltros();
  const [termo, setTermo] = useState(filtro.buscaTexto ?? "");
  const [campo, setCampo] = useState(filtro.buscaCampo ?? "todos");

  const sugestoes = useMemo(() => {
    if (!termo || termo.length < 2) return [];
    const termoNorm = termo.toLocaleLowerCase("pt-BR");
    const valores = new Set<string>();
    for (const r of registrosFiltrados) {
      for (const v of [r.municipio, r.unidade]) {
        if (v.toLocaleLowerCase("pt-BR").includes(termoNorm)) valores.add(v);
      }
      if (valores.size >= 8) break;
    }
    return [...valores].slice(0, 8);
  }, [termo, registrosFiltrados]);

  function pesquisar(e?: React.FormEvent) {
    e?.preventDefault();
    definirFiltro({ buscaTexto: termo || undefined, buscaCampo: campo });
  }

  function limpar() {
    setTermo("");
    setCampo("todos");
    limparFiltros();
  }

  const rotuloCampoAtivo = GRUPOS_BUSCA.flatMap((g) => g.opcoes).find((o) => o.valor === (filtro.buscaCampo ?? "todos"))?.rotulo;

  return (
    <div className="card p-4">
      <form onSubmit={pesquisar} className="flex flex-wrap items-end gap-3" role="search" aria-label="Busca avançada">
        <div className="flex flex-col gap-1">
          <label htmlFor="buscar-por" className="text-xs font-semibold text-gray-600 dark:text-gray-400">
            Buscar por
          </label>
          <select
            id="buscar-por"
            value={campo}
            onChange={(e) => setCampo(e.target.value)}
            className="rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
          >
            {GRUPOS_BUSCA.map((g) => (
              <optgroup key={g.grupo} label={g.grupo}>
                {g.opcoes.map((o) => (
                  <option key={o.valor} value={o.valor}>
                    {o.rotulo}
                  </option>
                ))}
              </optgroup>
            ))}
          </select>
        </div>

        <div className="relative flex flex-1 min-w-[220px] flex-col gap-1">
          <label htmlFor="termo-busca" className="text-xs font-semibold text-gray-600 dark:text-gray-400">
            Digite para pesquisar
          </label>
          <input
            id="termo-busca"
            type="search"
            value={termo}
            onChange={(e) => setTermo(e.target.value)}
            placeholder="Ex.: Goiânia, Hospital Municipal, 2382466…"
            className="rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
            list="sugestoes-busca"
            autoComplete="off"
          />
          <datalist id="sugestoes-busca">
            {sugestoes.map((s) => (
              <option key={s} value={s} />
            ))}
          </datalist>
        </div>

        <button type="submit" className="btn-primary">
          Pesquisar
        </button>
        <button type="button" onClick={limpar} className="btn-secondary">
          Limpar
        </button>
      </form>

      {temFiltrosAtivos && (
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="text-xs text-gray-500 dark:text-gray-400">Filtros ativos:</span>
          {filtro.buscaTexto && (
            <span className="chip">
              {rotuloCampoAtivo}: “{filtro.buscaTexto}”
            </span>
          )}
          {filtro.municipio && <span className="chip">Município selecionado</span>}
          {filtro.classificacao && <span className="chip">Classificação: {filtro.classificacao}</span>}
          {filtro.periodoInicio && <span className="chip">A partir de {filtro.periodoInicio.slice(0, 10)}</span>}
          {filtro.periodoFim && <span className="chip">Até {filtro.periodoFim.slice(0, 10)}</span>}
          <span className="text-xs text-gray-500 dark:text-gray-400">
            {registrosFiltrados.length} registro(s) no universo filtrado
          </span>
        </div>
      )}
    </div>
  );
}
