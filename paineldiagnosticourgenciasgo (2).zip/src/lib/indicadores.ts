// Cálculo de indicadores a partir de registros já limpos. Cada função aqui
// corresponde a uma regra da seção "2.8 Indicadores e regras de cálculo" do
// prompt mestre — ver docs/metodologia.md para fórmula, numerador e denominador.
import type { EixoId, RegistroUnidade, ValorMisto } from "../types";
import { classificarDisponibilidade } from "./transform";
import { DICIONARIO } from "./dictionary.generated";

const ROTULOS_EIXO: Record<EixoId, string> = {
  identificacao: "Identificação",
  leitos: "Leitos e capacidade instalada",
  equipamentos: "Sala de emergência e equipamentos",
  imagem: "Diagnóstico por imagem",
  especialidades: "Especialidades médicas",
  capacidade_resposta: "Capacidade de resposta clínica",
  regulacao: "Regulação, superlotação e transferências",
  trauma: "Trauma e suportes estratégicos",
  qualidade: "Qualidade dos dados",
};

export interface CompletudeEixo {
  eixo: EixoId;
  rotulo: string;
  percentual: number;
}

/** Completude por eixo temático (regra 2.8: "Completude... e por eixo"). */
export function completudePorEixo(registros: RegistroUnidade[]): CompletudeEixo[] {
  const camposPorEixo = new Map<EixoId, string[]>();
  for (const def of DICIONARIO) {
    if (def.tipo === "texto_pessoal") continue;
    // Campos de identificação (carimbo, município, unidade, CNES, classificação)
    // vivem em propriedades próprias de RegistroUnidade, não em r.campos — ver
    // src/lib/transform.ts. Eles são sempre exigidos para o registro existir,
    // então não entram neste cálculo de completude por eixo (evita falso 0%).
    if (def.eixo === "identificacao") continue;
    const lista = camposPorEixo.get(def.eixo) ?? [];
    lista.push(def.key);
    camposPorEixo.set(def.eixo, lista);
  }
  const resultado: CompletudeEixo[] = [];
  for (const [eixo, chaves] of camposPorEixo) {
    if (chaves.length === 0) continue;
    let preenchidos = 0;
    let aplicaveis = 0;
    for (const r of registros) {
      for (const chave of chaves) {
        aplicaveis += 1;
        const v = r.campos[chave];
        if (v === null || v === undefined) continue;
        if (typeof v === "object" && v.numero === null && v.texto === null) continue;
        preenchidos += 1;
      }
    }
    resultado.push({ eixo, rotulo: ROTULOS_EIXO[eixo] ?? eixo, percentual: aplicaveis > 0 ? preenchidos / aplicaveis : 0 });
  }
  return resultado;
}

/** Considera, na visão consolidada, apenas a resposta mais recente por CNES
 * (duplicidades não são somadas — regra 2.4). Use esta função para totais e
 * rankings "consolidados"; use os registros completos para auditoria/tabela. */
export function apenasConsolidados(registros: RegistroUnidade[]): RegistroUnidade[] {
  return registros.filter((r) => r.maisRecenteEntreDuplicados);
}

export interface ContagemMunicipio {
  municipio: string;
  quantidade: number;
  percentual: number;
}

export function respostasPorMunicipio(registros: RegistroUnidade[]): ContagemMunicipio[] {
  const total = registros.length;
  const mapa = new Map<string, { municipio: string; quantidade: number }>();
  for (const r of registros) {
    const atual = mapa.get(r.municipioNormalizado);
    if (atual) atual.quantidade += 1;
    else mapa.set(r.municipioNormalizado, { municipio: r.municipio, quantidade: 1 });
  }
  return [...mapa.values()]
    .map((v) => ({ ...v, percentual: total > 0 ? v.quantidade / total : 0 }))
    .sort((a, b) => b.quantidade - a.quantidade || a.municipio.localeCompare(b.municipio, "pt-BR"));
}

export function municipioComMaiorParticipacao(registros: RegistroUnidade[]): ContagemMunicipio | null {
  const ranking = respostasPorMunicipio(registros);
  return ranking[0] ?? null;
}

export function contarMunicipiosDistintos(registros: RegistroUnidade[]): number {
  return new Set(registros.map((r) => r.municipioNormalizado)).size;
}

export function contarUnidadesDistintas(registros: RegistroUnidade[]): number {
  return new Set(registros.map((r) => (r.cnes ? r.cnes : `${r.municipioNormalizado}|${r.unidade}`))).size;
}

export function contarCnesDistintos(registros: RegistroUnidade[]): number {
  return new Set(registros.filter((r) => r.cnes).map((r) => r.cnes)).size;
}

export interface DistribuicaoItem {
  categoria: string;
  quantidade: number;
  percentual: number;
}

export function distribuicaoPorClassificacao(registros: RegistroUnidade[]): DistribuicaoItem[] {
  const total = registros.length;
  const mapa = new Map<string, number>();
  for (const r of registros) mapa.set(r.classificacao, (mapa.get(r.classificacao) ?? 0) + 1);
  return [...mapa.entries()]
    .map(([categoria, quantidade]) => ({ categoria, quantidade, percentual: total > 0 ? quantidade / total : 0 }))
    .sort((a, b) => b.quantidade - a.quantidade);
}

/** Distribuição de um campo categórico (ou sim/não) qualquer, considerando
 * apenas respostas preenchidas — vazios entram como "Não informado" à parte
 * (regra 2.4: categoria "Não informado" apenas para visualização). */
export function distribuicaoCategoria(registros: RegistroUnidade[], campoKey: string): DistribuicaoItem[] {
  const mapa = new Map<string, number>();
  let semResposta = 0;
  for (const r of registros) {
    const v = r.campos[campoKey];
    if (v === null || v === undefined || v === "") {
      semResposta += 1;
      continue;
    }
    const chave = String(v);
    mapa.set(chave, (mapa.get(chave) ?? 0) + 1);
  }
  const total = registros.length;
  const itens = [...mapa.entries()].map(([categoria, quantidade]) => ({
    categoria,
    quantidade,
    percentual: total > 0 ? quantidade / total : 0,
  }));
  if (semResposta > 0) {
    itens.push({ categoria: "Não informado", quantidade: semResposta, percentual: total > 0 ? semResposta / total : 0 });
  }
  return itens.sort((a, b) => b.quantidade - a.quantidade);
}

export interface EstatisticaNumerica {
  comResposta: number;
  media: number | null;
  mediana: number | null;
  minimo: number | null;
  maximo: number | null;
}

export function estatisticaNumerica(registros: RegistroUnidade[], campoKey: string): EstatisticaNumerica {
  const valores: number[] = [];
  for (const r of registros) {
    const n = numeroDe(r.campos[campoKey]);
    if (n !== null) valores.push(n);
  }
  if (valores.length === 0) return { comResposta: 0, media: null, mediana: null, minimo: null, maximo: null };
  const ordenados = [...valores].sort((a, b) => a - b);
  const meio = Math.floor(ordenados.length / 2);
  const mediana = ordenados.length % 2 === 0 ? (ordenados[meio - 1] + ordenados[meio]) / 2 : ordenados[meio];
  return {
    comResposta: valores.length,
    media: valores.reduce((a, b) => a + b, 0) / valores.length,
    mediana,
    minimo: ordenados[0],
    maximo: ordenados[ordenados.length - 1],
  };
}

/** Para campos mistos (ex.: plantão 24h por especialidade): separa a
 * distribuição numérica da parcela textual ("Não dispõe da especialidade"),
 * sem descartar nenhuma resposta (regra 2.4). */
export function resumoMisto(
  registros: RegistroUnidade[],
  campoKey: string
): { estatistica: EstatisticaNumerica; naoDispoe: number; outroTexto: DistribuicaoItem[] } {
  const numericos: RegistroUnidade[] = [];
  let naoDispoe = 0;
  const textoMapa = new Map<string, number>();
  for (const r of registros) {
    const v = r.campos[campoKey];
    if (v && typeof v === "object") {
      if (v.numero !== null) numericos.push(r);
      else if (v.texto) {
        if (/não dispõe/i.test(v.texto)) naoDispoe += 1;
        else textoMapa.set(v.texto, (textoMapa.get(v.texto) ?? 0) + 1);
      }
    }
  }
  const total = registros.length;
  const outroTexto = [...textoMapa.entries()].map(([categoria, quantidade]) => ({
    categoria,
    quantidade,
    percentual: total > 0 ? quantidade / total : 0,
  }));
  return { estatistica: estatisticaNumerica(numericos, campoKey), naoDispoe, outroTexto };
}

function numeroDe(valor: string | number | ValorMisto | null | undefined): number | null {
  if (valor === null || valor === undefined) return null;
  if (typeof valor === "number") return valor;
  if (typeof valor === "object") return valor.numero;
  return null;
}

/** Soma valores numéricos válidos de um campo (leitos, equipamentos). Zero
 * conta normalmente; respostas sem o campo não entram na soma. */
export function somarCampoNumerico(registros: RegistroUnidade[], campoKey: string): number {
  let soma = 0;
  for (const r of registros) {
    const n = numeroDe(r.campos[campoKey]);
    if (n !== null) soma += n;
  }
  return soma;
}

export interface DivergenciaLeitos {
  tipo: string;
  operacionalSus: number;
  cadastradoCnes: number;
  diferenca: number;
}

const TIPOS_LEITO: { tipo: string; sus: string; cnes: string }[] = [
  { tipo: "Cirúrgico", sus: "leitos_sus_cirurgico", cnes: "leitos_cnes_cirurgico" },
  { tipo: "Clínico", sus: "leitos_sus_clinico", cnes: "leitos_cnes_clinico" },
  { tipo: "Obstétrico", sus: "leitos_sus_obstetrico", cnes: "leitos_cnes_obstetrico" },
  { tipo: "Pediátrico", sus: "leitos_sus_pediatrico", cnes: "leitos_cnes_pediatrico" },
];

export function divergenciaLeitosPorTipo(registros: RegistroUnidade[]): DivergenciaLeitos[] {
  return TIPOS_LEITO.map(({ tipo, sus, cnes }) => {
    const operacionalSus = somarCampoNumerico(registros, sus);
    const cadastradoCnes = somarCampoNumerico(registros, cnes);
    return { tipo, operacionalSus, cadastradoCnes, diferenca: operacionalSus - cadastradoCnes };
  });
}

export interface DisponibilidadeItem {
  campoKey: string;
  rotulo: string;
  comResposta: number;
  disponiveis: number;
  percentual: number;
}

/** % de unidades com valor > 0 para um item de equipamento/serviço numérico,
 * usando como denominador apenas quem respondeu o campo (regra 2.8). */
export function disponibilidadeNumerica(
  registros: RegistroUnidade[],
  campoKey: string,
  rotulo: string
): DisponibilidadeItem {
  let comResposta = 0;
  let disponiveis = 0;
  for (const r of registros) {
    const n = numeroDe(r.campos[campoKey]);
    if (n === null) continue;
    comResposta += 1;
    if (n > 0) disponiveis += 1;
  }
  return { campoKey, rotulo, comResposta, disponiveis, percentual: comResposta > 0 ? disponiveis / comResposta : 0 };
}

export function completudeMedia(registros: RegistroUnidade[]): number {
  if (registros.length === 0) return 0;
  return registros.reduce((acc, r) => acc + r.completude, 0) / registros.length;
}

export interface SemaforoContagem {
  verde: number;
  amarelo: number;
  vermelho: number;
  cinza: number;
}

export function contarSemaforo(registros: RegistroUnidade[], campoKey: string): SemaforoContagem {
  const c: SemaforoContagem = { verde: 0, amarelo: 0, vermelho: 0, cinza: 0 };
  for (const r of registros) {
    const estado = classificarDisponibilidade(r.campos[campoKey]);
    c[estado] += 1;
  }
  return c;
}

export interface FiltroPainel {
  municipio?: string;
  unidade?: string;
  cnes?: string;
  classificacao?: string;
  periodoInicio?: string; // ISO
  periodoFim?: string; // ISO
  buscaTexto?: string;
  buscaCampo?: string; // "todos" ou campoKey/eixo
}

export function aplicarFiltros(registros: RegistroUnidade[], filtro: FiltroPainel): RegistroUnidade[] {
  return registros.filter((r) => {
    if (filtro.municipio && r.municipioNormalizado !== filtro.municipio) return false;
    if (filtro.unidade && r.unidade !== filtro.unidade) return false;
    if (filtro.cnes && r.cnes !== filtro.cnes) return false;
    if (filtro.classificacao && r.classificacao !== filtro.classificacao) return false;
    if (filtro.periodoInicio && r.carimbo < filtro.periodoInicio) return false;
    if (filtro.periodoFim && r.carimbo > filtro.periodoFim) return false;
    if (filtro.buscaTexto) {
      const termo = filtro.buscaTexto.toLocaleLowerCase("pt-BR");
      const campo = filtro.buscaCampo ?? "todos";
      const alvo =
        campo === "municipio"
          ? r.municipio
          : campo === "unidade"
            ? r.unidade
            : campo === "cnes"
              ? r.cnes
              : campo === "classificacao"
                ? r.classificacao
                : [r.municipio, r.unidade, r.cnes, r.classificacao].join(" ");
      if (!alvo.toLocaleLowerCase("pt-BR").includes(termo)) return false;
    }
    return true;
  });
}
