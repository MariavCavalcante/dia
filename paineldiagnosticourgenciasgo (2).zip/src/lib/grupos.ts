// Listas de apoio para montar as páginas temáticas a partir das chaves do
// dicionário de dados (src/lib/dictionary.generated.ts), evitando repetir
// nomes de colunas na camada de interface.

export const TIPOS_LEITO = [
  { rotulo: "Cirúrgico", chaveSus: "leitos_sus_cirurgico", chaveCnes: "leitos_cnes_cirurgico" },
  { rotulo: "Clínico", chaveSus: "leitos_sus_clinico", chaveCnes: "leitos_cnes_clinico" },
  { rotulo: "Obstétrico", chaveSus: "leitos_sus_obstetrico", chaveCnes: "leitos_cnes_obstetrico" },
  { rotulo: "Pediátrico", chaveSus: "leitos_sus_pediatrico", chaveCnes: "leitos_cnes_pediatrico" },
];

export const ITENS_EQUIPAMENTO = [
  { rotulo: "Leitos (sala de emergência)", chave: "equip_leitos_sala_emergencia" },
  { rotulo: "Pontos de Oxigênio", chave: "equip_pontos_oxigenio" },
  { rotulo: "Pontos de Vácuo", chave: "equip_pontos_vacuo" },
  { rotulo: "Pontos de Ar Comprimido Medicinal", chave: "equip_pontos_ar_comprimido" },
  { rotulo: "Cilindros de O2 de Transporte", chave: "equip_cilindros_o2_transporte" },
  { rotulo: "Cilindros de Reserva", chave: "equip_cilindros_reserva" },
  { rotulo: "Tomadas de Emergência", chave: "equip_tomadas_emergencia" },
  { rotulo: "Monitor Multiparamétrico", chave: "equip_monitor_multiparametrico" },
  { rotulo: "Ventilador Mecânico Pulmonar", chave: "equip_ventilador_mecanico" },
  { rotulo: "Desfibrilador/Cardioversor", chave: "equip_desfibrilador" },
  { rotulo: "Bomba de Infusão", chave: "equip_bomba_infusao" },
  { rotulo: "Carro de Emergência", chave: "equip_carro_emergencia" },
  { rotulo: "Aspirador de Secreções", chave: "equip_aspirador_secrecoes" },
  { rotulo: "Kit Laringoscópio", chave: "equip_kit_laringoscopio" },
  { rotulo: "Ambu", chave: "equip_ambu" },
  { rotulo: "Estetoscópio e Esfigmomanômetro", chave: "equip_estetoscopio_esfigmomanometro" },
];

export const APARELHOS_IMAGEM = [
  { rotulo: "Tomografia", prefixo: "img_tomografia" },
  { rotulo: "Ressonância", prefixo: "img_ressonancia" },
  { rotulo: "Angiógrafo", prefixo: "img_angiografo" },
  { rotulo: "USG com Doppler", prefixo: "img_usg_doppler" },
  { rotulo: "Aparelho de RX", prefixo: "img_raio_x" },
];

export const ESPECIALIDADES = [
  { rotulo: "Clínica Médica", prefixo: "esp_clinica_medica" },
  { rotulo: "Pediatria", prefixo: "esp_pediatria" },
  { rotulo: "Cirurgia Geral", prefixo: "esp_cirurgia_geral" },
  { rotulo: "Ginecologia/Obstetrícia", prefixo: "esp_ginecologia_obstetricia" },
  { rotulo: "Neurocirurgia", prefixo: "esp_neurocirurgia" },
  { rotulo: "Cardiologia", prefixo: "esp_cardiologia" },
  { rotulo: "Cirurgia Vascular", prefixo: "esp_cirurgia_vascular" },
  { rotulo: "Ortopedia", prefixo: "esp_ortopedia" },
  { rotulo: "Urologia", prefixo: "esp_urologia" },
];

export const EQUIPE_TRAUMA = [
  { rotulo: "Centro Cirúrgico Equipado", chave: "trauma_centro_cirurgico" },
  { rotulo: "Cirurgião Geral", chave: "trauma_cirurgiao_geral" },
  { rotulo: "Ortopedista", chave: "trauma_ortopedista" },
  { rotulo: "Neurocirurgião", chave: "trauma_neurocirurgiao" },
  { rotulo: "Anestesiologista", chave: "trauma_anestesiologista" },
];
