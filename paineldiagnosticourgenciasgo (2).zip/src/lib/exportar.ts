import type { RegistroUnidade } from "../types";

/** Exporta apenas o recorte filtrado, já anonimizado (sem o responsável pelo
 * preenchimento, que nunca chega a este objeto — ver src/lib/transform.ts). */
export function exportarRegistrosCsv(registros: RegistroUnidade[]): void {
  const cabecalho = [
    "municipio",
    "unidade",
    "cnes",
    "classificacao",
    "data_resposta",
    "completude_percentual",
    "cnes_duplicado",
    "cnes_atipico",
    "classificacao_residual",
    "quantidade_alertas",
  ];
  const linhas = registros.map((r) =>
    [
      r.municipio,
      r.unidade,
      r.cnes,
      r.classificacao,
      new Date(r.carimbo).toLocaleDateString("pt-BR"),
      Math.round(r.completude * 100),
      r.duplicadoCnes ? "sim" : "não",
      r.cnesAtipico ? "sim" : "não",
      r.classificacaoResidual ? "sim" : "não",
      r.alertas.length,
    ]
      .map((v) => `"${String(v).replace(/"/g, '""')}"`)
      .join(",")
  );
  const csv = [cabecalho.join(","), ...linhas].join("\n");
  const blob = new Blob([`﻿${csv}`], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `painel-urgencias-go-recorte-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
