// Funções puras de limpeza e normalização. Cada função documenta a regra
// aplicada (ver também docs/dicionario-de-dados.md e src/lib/dictionary.generated.ts).
import type { ValorMisto } from "../types";

/** Remove espaços excedentes nas pontas e colapsa espaços internos múltiplos.
 * Usado apenas na camada de apresentação — o valor original é sempre preservado
 * em paralelo para fins de auditoria (regra 2.3, item "Normalizar espaços..."). */
export function normalizarEspacos(valor: string): string {
  return valor.replace(/\s+/g, " ").trim();
}

/** Capitaliza cada palavra de um nome próprio (município, unidade) apenas para
 * exibição. Preserva conectores comuns em minúsculas. */
const CONECTORES = new Set(["de", "da", "do", "das", "dos", "e"]);
export function capitalizarNomeProprio(valor: string): string {
  const limpo = normalizarEspacos(valor);
  return limpo
    .toLowerCase()
    .split(" ")
    .map((palavra, i) => {
      if (i > 0 && CONECTORES.has(palavra)) return palavra;
      return palavra.charAt(0).toUpperCase() + palavra.slice(1);
    })
    .join(" ");
}

/** Chave de comparação (para agrupar município/unidade robustamente a acentos,
 * caixa e espaços) usada pela busca e por agregações — nunca exibida ao usuário. */
export function chaveNormalizada(valor: string): string {
  return normalizarEspacos(valor)
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase();
}

/** Converte o carimbo de data/hora do Google Forms (dd/mm/aaaa HH:MM:SS) para
 * ISO 8601. Retorna null se o valor não puder ser interpretado — nesse caso a
 * linha deve ser descartada (regra: "linhas sem carimbo de data/hora" são
 * desconsideradas). */
export function parseCarimbo(valor: string | undefined | null): string | null {
  if (!valor) return null;
  const m = valor.trim().match(/^(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}):(\d{2}):(\d{2})$/);
  if (!m) return null;
  const [, dd, mm, yyyy, hh, mi, ss] = m;
  const iso = `${yyyy}-${mm}-${dd}T${hh}:${mi}:${ss}`;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  return iso;
}

/** Converte o CNES para texto padronizado: remove sufixo decimal produzido
 * pelo Excel (ex.: "23394663" já é texto aqui, mas ".0" de exportações XLSX
 * é removido quando presente) e preserva zeros à esquerda. Não descarta
 * dígitos — apenas sinaliza quando o comprimento é atípico (CNES padrão tem
 * 7 dígitos) ou o valor não é numérico. */
export function limparCnes(valor: string | undefined | null): { cnes: string; atipico: boolean } {
  const bruto = (valor ?? "").trim();
  const semDecimal = bruto.replace(/\.0+$/, "");
  const somenteDigitos = /^\d+$/.test(semDecimal);
  const atipico = !somenteDigitos || semDecimal.length !== 7;
  return { cnes: semDecimal, atipico };
}

/** Interpreta um campo puramente numérico (leitos, equipamentos, especialistas
 * em regime presencial/sobreaviso/telemedicina, Vaga Zero). Remove zeros à
 * esquerda ("00" -> 0) sem tratá-los como ausência — zero é dado válido. */
export function parseNumero(valor: string | undefined | null): number | null {
  if (valor === undefined || valor === null) return null;
  const limpo = valor.trim();
  if (limpo === "") return null;
  if (!/^-?\d+(\.\d+)?$/.test(limpo)) return null;
  const n = Number(limpo);
  return Number.isFinite(n) ? n : null;
}

/** Interpreta um campo misto: valor numérico OU expressão textual de ausência
 * (ex.: "Não dispõe da especialidade"). Nunca descarta a resposta original. */
export function parseMisto(valor: string | undefined | null): ValorMisto {
  const original = valor ?? null;
  if (valor === undefined || valor === null || valor.trim() === "") {
    return { numero: null, texto: null, original };
  }
  const limpo = valor.trim();
  const numero = parseNumero(limpo);
  if (numero !== null) return { numero, texto: null, original };
  return { numero: null, texto: normalizarEspacos(limpo), original };
}

/** Interpreta um campo de carga horária em formato "Xh" (ex.: "12h") ou a
 * expressão de ausência "Não dispõe da especialidade". */
export function parseDuracaoTexto(valor: string | undefined | null): ValorMisto {
  const original = valor ?? null;
  if (valor === undefined || valor === null || valor.trim() === "") {
    return { numero: null, texto: null, original };
  }
  const limpo = valor.trim();
  const m = limpo.match(/^(\d+)\s*h$/i);
  if (m) return { numero: Number(m[1]), texto: null, original };
  return { numero: null, texto: normalizarEspacos(limpo), original };
}

/** Expressões textuais tratadas como "ausência de serviço" para fins de
 * indicadores de disponibilidade (nunca substituem o texto original). As
 * chaves já estão sem acento porque são comparadas contra chaveNormalizada(),
 * que remove diacríticos — mantê-las acentuadas aqui faria a comparação
 * falhar silenciosamente para todo valor com "não" (bug corrigido: todas as
 * respostas de ausência caíam em "cinza" em vez de "vermelho" no semáforo). */
const EXPRESSOES_AUSENCIA = new Set([
  "nao possui",
  "nao oferta o servico",
  "nao dispoe da especialidade",
  "nao disponivel",
  "nao",
]);
export function indicaAusencia(valorTexto: string | null | undefined): boolean {
  if (!valorTexto) return false;
  return EXPRESSOES_AUSENCIA.has(chaveNormalizada(valorTexto));
}

/** Heurística simples e documentada para sinalizar valores extremos em campos
 * numéricos de baixa magnitude esperada (ex.: Vaga Zero por dia). Não remove
 * o valor — apenas marca para revisão, conforme regra 2.4. */
export function ehValorExtremo(valor: number, limiteSuperior: number): boolean {
  return valor > limiteSuperior;
}
