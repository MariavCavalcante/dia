export interface ItemNavegacao {
  rota: string;
  rotulo: string;
  icone: string; // emoji simples — mantém o bundle leve, sem depender de biblioteca de ícones
}

export const NAVEGACAO: ItemNavegacao[] = [
  { rota: "/", rotulo: "Visão geral", icone: "📊" },
  { rota: "/leitos", rotulo: "Leitos e capacidade instalada", icone: "🛏️" },
  { rota: "/equipamentos", rotulo: "Sala de emergência e equipamentos", icone: "🧰" },
  { rota: "/imagem", rotulo: "Diagnóstico por imagem", icone: "🩻" },
  { rota: "/especialidades", rotulo: "Especialidades médicas", icone: "🩺" },
  { rota: "/capacidade-resposta", rotulo: "Capacidade de resposta clínica", icone: "❤️" },
  { rota: "/regulacao", rotulo: "Regulação, superlotação e transferências", icone: "🔄" },
  { rota: "/trauma", rotulo: "Trauma e suportes estratégicos", icone: "🚑" },
  { rota: "/qualidade", rotulo: "Qualidade dos dados", icone: "✅" },
  { rota: "/metodologia", rotulo: "Metodologia e dicionário de dados", icone: "📖" },
];
