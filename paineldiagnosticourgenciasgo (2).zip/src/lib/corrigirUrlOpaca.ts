/**
 * Corrige um problema de compatibilidade do React Router em contextos de
 * origem opaca (ex.: iframe `srcdoc`/sandboxed, como em pré-visualizações
 * embutidas de HTML — é o caso do preview inline usado para abrir este
 * painel sem precisar baixar o arquivo).
 *
 * Nesses contextos, `window.location.origin` é a string literal "null" e
 * `window.location.href` costuma ser algo como "about:srcdoc" — um esquema
 * não hierárquico. O React Router usa internamente
 * `new URL(caminhoRelativo, baseDeOrigem)` (em `history.encodeLocation`,
 * chamado a cada renderização de `<Routes>`/`<NavLink>`) para recodificar
 * caminhos. Resolver uma referência relativa contra uma base "about:" não é
 * suportado pelo parser de URL do navegador, e isso lança
 * `TypeError: Failed to construct 'URL': Invalid URL` — foi exatamente o
 * erro relatado ao abrir a pré-visualização.
 *
 * A correção interceptamos o construtor global `URL`: se a chamada original
 * falhar por causa de uma base inválida, tentamos novamente com uma base
 * fictícia válida (apenas para permitir a resolução do caminho relativo — o
 * resultado nunca é usado como uma URL real de rede, só para o React Router
 * calcular o "pathname" de volta). Em qualquer contexto normal (produção no
 * Netlify, `npm run dev`, `file://`), a chamada original nunca falha, então
 * este módulo não tem nenhum efeito observável.
 */
export function corrigirConstrutorDeUrlEmOrigemOpaca(): void {
  if (typeof window === "undefined" || typeof window.URL !== "function") return;

  const ConstrutorOriginal = window.URL;

  function URLComRespaldo(url: string | URL, base?: string | URL) {
    try {
      return new ConstrutorOriginal(url, base as string | URL | undefined);
    } catch (erroOriginal) {
      if (base !== undefined) {
        try {
          return new ConstrutorOriginal(url, "http://localhost");
        } catch {
          // Nem a base fictícia resolveu (ex.: o próprio "url" é inválido) —
          // nesse caso o problema não é o que estamos corrigindo aqui.
        }
      }
      throw erroOriginal;
    }
  }

  URLComRespaldo.prototype = ConstrutorOriginal.prototype;
  URLComRespaldo.createObjectURL = ConstrutorOriginal.createObjectURL?.bind(ConstrutorOriginal);
  URLComRespaldo.revokeObjectURL = ConstrutorOriginal.revokeObjectURL?.bind(ConstrutorOriginal);
  URLComRespaldo.canParse = ConstrutorOriginal.canParse?.bind(ConstrutorOriginal);

  window.URL = URLComRespaldo as unknown as typeof URL;
}
