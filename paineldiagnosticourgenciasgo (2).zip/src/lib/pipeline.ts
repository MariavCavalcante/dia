// Camada de integração desacoplada da interface (regra 2.3.1). Usada tanto
// pela Netlify Function de produção (netlify/functions/dados.ts) quanto pelo
// middleware de desenvolvimento local (vite.config.ts), garantindo que as
// mesmas regras de busca, limpeza e anonimização valham nos dois ambientes.
import Papa from "papaparse";
import { readFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import { transformarLinhas, type LinhaBruta } from "./transform";
import type { DatasetPainel, StatusSincronizacao } from "../types";
import {
  contarCnesDistintos,
  contarMunicipiosDistintos,
  contarUnidadesDistintas,
  completudeMedia,
} from "./indicadores";

// A planilha em uso ("DIAGNÓSTICO SITUACIONAL (respostas)") é publicada via
// Arquivo → Compartilhar → Publicar na web, aba de respostas, gid=119176214
// (ver docs/integracao-google-forms.md, "Planilha em uso"). Este texto é
// só informativo (exibido na página de Metodologia) — a URL em si já contém
// o gid, então não precisa ser recalculado aqui.
const ABA_DESCRICAO = "Respostas ao formulário 1 (gid 119176214)";
const FIXTURE_PATH = path.join(process.cwd(), "scripts/fixtures/planilha-referencia.csv");

// Cache em memória de curta duração + revalidação (regra 2.3.2). Em ambiente
// serverless (Netlify Functions) o módulo pode ser reciclado a qualquer
// momento — o cache aqui é um otimizador de custo/latência, não a fonte da
// verdade; a fonte da verdade é sempre a Planilha Google.
const TTL_MS = 60_000; // 1 minuto — dentro da janela de 1 a 5 min pedida na regra 2.3
let cache: { dataset: DatasetPainel; buscadoEm: number } | null = null;
let ultimoSucesso: string | null = null;
let ultimaFalha: string | null = null;

function montarUrlCsv(): string | null {
  const url = process.env.GOOGLE_SHEETS_CSV_URL;
  if (url && url.trim() !== "") return url.trim();
  return null;
}

async function obterLinhasBrutas(): Promise<{ linhas: LinhaBruta[]; origem: "csv_remoto" | "planilha_referencia" }> {
  const url = montarUrlCsv();
  if (url) {
    const resposta = await fetch(url, { headers: { Accept: "text/csv" } });
    if (!resposta.ok) {
      throw new Error(`Falha ao buscar a Planilha Google (HTTP ${resposta.status}).`);
    }
    const texto = await resposta.text();
    const parse = Papa.parse<LinhaBruta>(texto, { header: true, skipEmptyLines: false });
    return { linhas: parse.data, origem: "csv_remoto" };
  }
  // Sem GOOGLE_SHEETS_CSV_URL configurada: usa a planilha de referência local
  // para permitir `npm run dev` sem segredos. Nunca usado em produção (ver README).
  if (!existsSync(FIXTURE_PATH)) {
    throw new Error(
      "GOOGLE_SHEETS_CSV_URL não configurada e planilha de referência local não encontrada."
    );
  }
  const texto = await readFile(FIXTURE_PATH, "utf-8");
  const parse = Papa.parse<LinhaBruta>(texto, { header: true, skipEmptyLines: false });
  return { linhas: parse.data, origem: "planilha_referencia" };
}

async function construirDataset(): Promise<DatasetPainel> {
  const agora = new Date().toISOString();
  const { linhas, origem } = await obterLinhasBrutas();
  const { registros, linhasRecebidas, registrosValidos, registrosExcluidos } = transformarLinhas(linhas);

  const status: StatusSincronizacao = {
    estado: "atualizado",
    ultimaTentativa: agora,
    ultimoSucesso: agora,
    linhasRecebidas,
    registrosValidos,
    registrosExcluidos,
    erro: origem === "planilha_referencia" ? "AVISO_DEV: usando planilha de referência local (GOOGLE_SHEETS_CSV_URL não definida)" : null,
  };

  return {
    geradoEm: agora,
    fonte: { tipo: "csv_publico", aba: ABA_DESCRICAO, urlVariavelAmbiente: "GOOGLE_SHEETS_CSV_URL" },
    status,
    registros,
    municipiosRespondentes: contarMunicipiosDistintos(registros),
    totalRespostasValidas: registrosValidos,
    unidadesDistintas: contarUnidadesDistintas(registros),
    cnesDistintos: contarCnesDistintos(registros),
    completudeGeral: completudeMedia(registros),
  };
}

export interface HandlerResultado {
  status: number;
  body: DatasetPainel | { erro: string; status: StatusSincronizacao | null };
}

/** Ponto de entrada único usado pela Netlify Function e pelo middleware de
 * dev. Aplica cache de curta duração; em caso de falha, mantém em memória a
 * última versão válida e retorna aviso, sem apagar indicadores (regra 2.3). */
export async function handleDadosRequest(opts: { forceRefresh?: boolean } = {}): Promise<HandlerResultado> {
  const agora = Date.now();
  const cacheValido = cache && !opts.forceRefresh && agora - cache.buscadoEm < TTL_MS;
  if (cacheValido && cache) {
    return { status: 200, body: cache.dataset };
  }

  try {
    const dataset = await construirDataset();
    cache = { dataset, buscadoEm: agora };
    ultimoSucesso = dataset.geradoEm;
    return { status: 200, body: dataset };
  } catch (err) {
    ultimaFalha = new Date().toISOString();
    if (cache) {
      // Mantém a última versão válida em tela, com aviso de falha de sincronização.
      const datasetComAviso: DatasetPainel = {
        ...cache.dataset,
        status: {
          ...cache.dataset.status,
          estado: "falha",
          ultimaTentativa: ultimaFalha,
          erro: err instanceof Error ? err.message : String(err),
        },
      };
      return { status: 200, body: datasetComAviso };
    }
    return {
      status: 502,
      body: {
        erro: err instanceof Error ? err.message : String(err),
        status: {
          estado: "falha",
          ultimaTentativa: ultimaFalha,
          ultimoSucesso,
          linhasRecebidas: 0,
          registrosValidos: 0,
          registrosExcluidos: 0,
          erro: err instanceof Error ? err.message : String(err),
        },
      },
    };
  }
}
