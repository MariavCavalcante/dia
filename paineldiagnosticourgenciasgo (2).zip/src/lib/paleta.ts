// Paleta de cores do painel.
//
// Duas famílias, propositalmente separadas (ver docs/identidade-visual.md):
//  1) IDENTIDADE INSTITUCIONAL — hex oficiais informados pelo Estado de Goiás
//     (seção 2.5 do prompt mestre), usados em cabeçalho, botões e elementos de
//     marca. Amarelo é usado apenas com parcimônia, nunca em grandes áreas.
//  2) PALETA DE VISUALIZAÇÃO — conjunto categórico/sequencial/status validado
//     com o script de acessibilidade cromática da skill de dataviz
//     (contraste, separação para daltonismo e piso de visão normal). O
//     amarelo institucional foi propositalmente excluído das marcas de dados
//     porque falha o piso de contraste (WCAG) sobre fundo claro — mantê-lo
//     fora dos gráficos é also o que o próprio prompt mestre pede.

export const MARCA = {
  verde: "#19A32A",
  amarelo: "#FFDE00",
  azul: "#00509F",
  azulEscuro: "#003B75",
  branco: "#FFFFFF",
};

/** Paleta categórica — ordem fixa, nunca ciclada aleatoriamente.
 * Validada: node scripts/validate_palette.js "#00509F,#19A32A,#7C4A02,#6B4C9A" --mode light → PASS
 * Validada (dark): "#3987e5,#199e70,#d95926,#9085e9" --mode dark → PASS */
export const CATEGORICA_LIGHT = ["#00509F", "#19A32A", "#7C4A02", "#6B4C9A"];
export const CATEGORICA_DARK = ["#3987e5", "#199e70", "#d95926", "#9085e9"];

/** Rampa sequencial (magnitude única) — azul institucional, claro→escuro. */
export const SEQUENCIAL_AZUL = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"];

/** Par divergente para gráficos de diferença (ex.: leitos operacionais vs.
 * cadastrados no CNES): azul (mais operacional) ↔ terracota (mais cadastrado),
 * com cinza neutro no ponto central de equilíbrio. */
export const DIVERGENTE = { positivo: "#00509F", negativo: "#B45309", neutro: "#9CA3AF" };

/** Cores de status fixas (regra 2.10 — semáforos). Nunca reaproveitadas para
 * identidade de série; sempre acompanhadas de ícone + rótulo textual. */
export const STATUS = {
  verde: "#19A32A",
  amarelo: "#B98A00", // passo mais escuro do amarelo institucional, para atingir contraste mínimo em texto/ícone
  vermelho: "#C22B2B",
  cinza: "#6B7280",
};

export const TINTA = {
  primaria: "#0b0b0b",
  secundaria: "#52514e",
  muted: "#898781",
  grade: "#e1e0d9",
};
