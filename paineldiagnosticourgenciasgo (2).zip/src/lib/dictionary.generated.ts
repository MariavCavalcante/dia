// GERADO AUTOMATICAMENTE por scripts/gerar-dicionario.py a partir de
// scripts/fixtures/planilha-referencia.csv. Não editar manualmente:
// para alterar, ajuste o gerador e rode `python3 scripts/gerar-dicionario.py`.
import type { CampoDicionario } from "../types";

export const DICIONARIO: CampoDicionario[] = 
[
  {
    "key": "carimbo",
    "header": "Carimbo de data/hora",
    "eixo": "identificacao",
    "indicador": "Carimbo de data/hora",
    "grupo": null,
    "tipo": "data",
    "unidade": null,
    "categorias": null,
    "regra": "Referência de inclusão e ordenação; linhas sem carimbo são descartadas.",
    "viz": "—"
  },
  {
    "key": "municipio",
    "header": "Município",
    "eixo": "identificacao",
    "indicador": "Município",
    "grupo": null,
    "tipo": "texto",
    "unidade": null,
    "categorias": null,
    "regra": "Normalizar espaços/capitalização apenas na apresentação; manter original para auditoria.",
    "viz": "Ranking, busca"
  },
  {
    "key": "responsavel_preenchimento",
    "header": "Responsável pelo preenchimento",
    "eixo": "identificacao",
    "indicador": "Responsável pelo preenchimento",
    "grupo": null,
    "tipo": "texto_pessoal",
    "unidade": null,
    "categorias": null,
    "regra": "Dado pessoal. Nunca exposto no painel público, em exportações, tooltips ou URLs.",
    "viz": "—"
  },
  {
    "key": "unidade",
    "header": "Nome da Unidade de Saúde",
    "eixo": "identificacao",
    "indicador": "Nome da Unidade de Saúde",
    "grupo": null,
    "tipo": "texto",
    "unidade": null,
    "categorias": null,
    "regra": "Normalizar espaços/capitalização na apresentação; validar preferencialmente pelo CNES.",
    "viz": "Busca, tabela"
  },
  {
    "key": "cnes",
    "header": "Número do CNES",
    "eixo": "identificacao",
    "indicador": "Número do CNES",
    "grupo": null,
    "tipo": "texto",
    "unidade": null,
    "categorias": null,
    "regra": "Tratado como texto; remove sufixo decimal do Excel sem eliminar zeros à esquerda; sinaliza dígitos atípicos.",
    "viz": "Busca, tabela"
  },
  {
    "key": "classificacao",
    "header": "Classificação do Estabelecimento",
    "eixo": "identificacao",
    "indicador": "Classificação do Estabelecimento",
    "grupo": null,
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Hospital Geral",
      "Pronto Atendimento-UPA 24h",
      "Unidade Mista",
      "Pronto Socorro Geral",
      "Pronto Socorro Especializado",
      "Hospital Especializado",
      "Opção 8"
    ],
    "regra": "'Opção 8' é categoria residual sinalizada para revisão institucional.",
    "viz": "Distribuição (barras/rosca)"
  },
  {
    "key": "leitos_sus_cirurgico",
    "header": "Informe o número de leitos operacionais disponíveis para o SUS. [Cirúrgico]",
    "eixo": "leitos",
    "indicador": "Leitos operacionais SUS — Cirúrgico",
    "grupo": "Cirúrgico",
    "tipo": "numero",
    "unidade": "leitos",
    "categorias": null,
    "regra": "Soma de valores numéricos válidos; zero é valor válido.",
    "viz": "Ranking, divergência"
  },
  {
    "key": "leitos_sus_clinico",
    "header": "Informe o número de leitos operacionais disponíveis para o SUS. [Clinico]",
    "eixo": "leitos",
    "indicador": "Leitos operacionais SUS — Clinico",
    "grupo": "Clinico",
    "tipo": "numero",
    "unidade": "leitos",
    "categorias": null,
    "regra": "Soma de valores numéricos válidos; zero é valor válido.",
    "viz": "Ranking, divergência"
  },
  {
    "key": "leitos_sus_obstetrico",
    "header": "Informe o número de leitos operacionais disponíveis para o SUS. [Obstétrico]",
    "eixo": "leitos",
    "indicador": "Leitos operacionais SUS — Obstétrico",
    "grupo": "Obstétrico",
    "tipo": "numero",
    "unidade": "leitos",
    "categorias": null,
    "regra": "Soma de valores numéricos válidos; zero é valor válido.",
    "viz": "Ranking, divergência"
  },
  {
    "key": "leitos_sus_pediatrico",
    "header": "Informe o número de leitos operacionais disponíveis para o SUS. [Pediátrico]",
    "eixo": "leitos",
    "indicador": "Leitos operacionais SUS — Pediátrico",
    "grupo": "Pediátrico",
    "tipo": "numero",
    "unidade": "leitos",
    "categorias": null,
    "regra": "Soma de valores numéricos válidos; zero é valor válido.",
    "viz": "Ranking, divergência"
  },
  {
    "key": "leitos_cnes_cirurgico",
    "header": "Informe o número de leitos Cadastrados no CNES. [Cirúrgico]",
    "eixo": "leitos",
    "indicador": "Leitos cadastrados no CNES — Cirúrgico",
    "grupo": "Cirúrgico",
    "tipo": "numero",
    "unidade": "leitos",
    "categorias": null,
    "regra": "Soma de valores numéricos válidos; zero é valor válido.",
    "viz": "Ranking, divergência"
  },
  {
    "key": "leitos_cnes_clinico",
    "header": "Informe o número de leitos Cadastrados no CNES. [Clinico]",
    "eixo": "leitos",
    "indicador": "Leitos cadastrados no CNES — Clinico",
    "grupo": "Clinico",
    "tipo": "numero",
    "unidade": "leitos",
    "categorias": null,
    "regra": "Soma de valores numéricos válidos; zero é valor válido.",
    "viz": "Ranking, divergência"
  },
  {
    "key": "leitos_cnes_obstetrico",
    "header": "Informe o número de leitos Cadastrados no CNES. [Obstétrico]",
    "eixo": "leitos",
    "indicador": "Leitos cadastrados no CNES — Obstétrico",
    "grupo": "Obstétrico",
    "tipo": "numero",
    "unidade": "leitos",
    "categorias": null,
    "regra": "Soma de valores numéricos válidos; zero é valor válido.",
    "viz": "Ranking, divergência"
  },
  {
    "key": "leitos_cnes_pediatrico",
    "header": "Informe o número de leitos Cadastrados no CNES. [Pediátrico]",
    "eixo": "leitos",
    "indicador": "Leitos cadastrados no CNES — Pediátrico",
    "grupo": "Pediátrico",
    "tipo": "numero",
    "unidade": "leitos",
    "categorias": null,
    "regra": "Soma de valores numéricos válidos; zero é valor válido.",
    "viz": "Ranking, divergência"
  },
  {
    "key": "equip_leitos_sala_emergencia",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Leitos]",
    "eixo": "equipamentos",
    "indicador": "Leitos",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_pontos_oxigenio",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Pontos de Oxigênio (Rede/Fluxômetro)]",
    "eixo": "equipamentos",
    "indicador": "Pontos de Oxigênio (Rede/Fluxômetro)",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_pontos_vacuo",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Pontos de Vácuo (Rede/Vacuômetro)]",
    "eixo": "equipamentos",
    "indicador": "Pontos de Vácuo (Rede/Vacuômetro)",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_pontos_ar_comprimido",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Pontos de Ar Comprimido Medicinal]",
    "eixo": "equipamentos",
    "indicador": "Pontos de Ar Comprimido Medicinal",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_cilindros_o2_transporte",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Cilindros de O2 de Transporte (Carga Cheia)]",
    "eixo": "equipamentos",
    "indicador": "Cilindros de O2 de Transporte (Carga Cheia)",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_cilindros_reserva",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Cilindros de Reserva]",
    "eixo": "equipamentos",
    "indicador": "Cilindros de Reserva",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_tomadas_emergencia",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Tomadas de Emergência (mín. 4 por leito)]",
    "eixo": "equipamentos",
    "indicador": "Tomadas de Emergência (mín. 4 por leito)",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_monitor_multiparametrico",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Monitor Multiparamétrico (com ECG, Oximetria, PNI)]",
    "eixo": "equipamentos",
    "indicador": "Monitor Multiparamétrico (com ECG, Oximetria, PNI)",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_ventilador_mecanico",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Ventilador Mecânico Pulmonar (VMP)]",
    "eixo": "equipamentos",
    "indicador": "Ventilador Mecânico Pulmonar (VMP)",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_desfibrilador",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Desfibrilador / Cardioversor com Bateria e Pás]",
    "eixo": "equipamentos",
    "indicador": "Desfibrilador / Cardioversor com Bateria e Pás",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_bomba_infusao",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Bomba de Infusão (mínimo 02 por leito)]",
    "eixo": "equipamentos",
    "indicador": "Bomba de Infusão (mínimo 02 por leito)",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_carro_emergencia",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Carro de Emergência (Lacrado e Conferido)]",
    "eixo": "equipamentos",
    "indicador": "Carro de Emergência (Lacrado e Conferido)",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_aspirador_secrecoes",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Aspirador de Secreções (Portátil ou de Parede)]",
    "eixo": "equipamentos",
    "indicador": "Aspirador de Secreções (Portátil ou de Parede)",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_kit_laringoscopio",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Kit Laringoscópio Completo (Cabos e Lâminas)]",
    "eixo": "equipamentos",
    "indicador": "Kit Laringoscópio Completo (Cabos e Lâminas)",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_ambu",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Ambu (Bolsa-Válvula-Máscara) com reservatório]",
    "eixo": "equipamentos",
    "indicador": "Ambu (Bolsa-Válvula-Máscara) com reservatório",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "equip_estetoscopio_esfigmomanometro",
    "header": "Item de Infraestrutura / Equipamento -  Quantidade de itens ativos e funcionais [Estetoscópio e Esfigmomanômetro]",
    "eixo": "equipamentos",
    "indicador": "Estetoscópio e Esfigmomanômetro",
    "grupo": null,
    "tipo": "numero",
    "unidade": "unidades",
    "categorias": null,
    "regra": "Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida.",
    "viz": "Matriz de disponibilidade, barras"
  },
  {
    "key": "img_tomografia_quantidade",
    "header": "Quantidade de Aparelhos [Tomografia]",
    "eixo": "imagem",
    "indicador": "Tomografia",
    "grupo": "Quantidade",
    "tipo": "numero",
    "unidade": "aparelhos",
    "categorias": null,
    "regra": "Zero é valor válido (unidade sem aparelho).",
    "viz": "Barras"
  },
  {
    "key": "img_tomografia_funcionamento",
    "header": "Funcionamento do serviço (8/12/24h) [Tomografia]",
    "eixo": "imagem",
    "indicador": "Tomografia",
    "grupo": "Funcionamento",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não possui",
      "08 horas/dia",
      "12 horas/dia",
      "24 horas/dia"
    ],
    "regra": "Categórico; 'Não possui' tratado como ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "img_tomografia_laudos",
    "header": "Emissão de Laudos (Presencial/Telemedicina) [Tomografia]",
    "eixo": "imagem",
    "indicador": "Tomografia",
    "grupo": "Emissão de laudos",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não Oferta o Serviço",
      "Presencial",
      "Telemedicina"
    ],
    "regra": "Categórico; usado para calcular ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "img_tomografia_local",
    "header": "Local de Instalação do equipamento [Tomografia]",
    "eixo": "imagem",
    "indicador": "Tomografia",
    "grupo": "Local de instalação",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não Oferta o Serviço",
      "Na Unidade",
      "Outra unidade"
    ],
    "regra": "Separa oferta própria, oferta em outra unidade e ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "img_ressonancia_quantidade",
    "header": "Quantidade de Aparelhos [Ressonância]",
    "eixo": "imagem",
    "indicador": "Ressonância",
    "grupo": "Quantidade",
    "tipo": "numero",
    "unidade": "aparelhos",
    "categorias": null,
    "regra": "Zero é valor válido (unidade sem aparelho).",
    "viz": "Barras"
  },
  {
    "key": "img_ressonancia_funcionamento",
    "header": "Funcionamento do serviço (8/12/24h) [Ressonância]",
    "eixo": "imagem",
    "indicador": "Ressonância",
    "grupo": "Funcionamento",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não possui",
      "08 horas/dia",
      "12 horas/dia",
      "24 horas/dia"
    ],
    "regra": "Categórico; 'Não possui' tratado como ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "img_ressonancia_laudos",
    "header": "Emissão de Laudos (Presencial/Telemedicina) [Ressonância]",
    "eixo": "imagem",
    "indicador": "Ressonância",
    "grupo": "Emissão de laudos",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não Oferta o Serviço",
      "Presencial",
      "Telemedicina"
    ],
    "regra": "Categórico; usado para calcular ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "img_ressonancia_local",
    "header": "Local de Instalação do equipamento [Ressonância]",
    "eixo": "imagem",
    "indicador": "Ressonância",
    "grupo": "Local de instalação",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não Oferta o Serviço",
      "Na Unidade",
      "Outra unidade"
    ],
    "regra": "Separa oferta própria, oferta em outra unidade e ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "img_angiografo_quantidade",
    "header": "Quantidade de Aparelhos [Angiógrafo]",
    "eixo": "imagem",
    "indicador": "Angiógrafo",
    "grupo": "Quantidade",
    "tipo": "numero",
    "unidade": "aparelhos",
    "categorias": null,
    "regra": "Zero é valor válido (unidade sem aparelho).",
    "viz": "Barras"
  },
  {
    "key": "img_angiografo_funcionamento",
    "header": "Funcionamento do serviço (8/12/24h) [Angiógrafo]",
    "eixo": "imagem",
    "indicador": "Angiógrafo",
    "grupo": "Funcionamento",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não possui",
      "08 horas/dia",
      "12 horas/dia",
      "24 horas/dia"
    ],
    "regra": "Categórico; 'Não possui' tratado como ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "img_angiografo_laudos",
    "header": "Emissão de Laudos (Presencial/Telemedicina) [Angiógrafo]",
    "eixo": "imagem",
    "indicador": "Angiógrafo",
    "grupo": "Emissão de laudos",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não Oferta o Serviço",
      "Presencial",
      "Telemedicina"
    ],
    "regra": "Categórico; usado para calcular ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "img_angiografo_local",
    "header": "Local de Instalação do equipamento [Angiógrafo]",
    "eixo": "imagem",
    "indicador": "Angiógrafo",
    "grupo": "Local de instalação",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não Oferta o Serviço",
      "Na Unidade",
      "Outra unidade"
    ],
    "regra": "Separa oferta própria, oferta em outra unidade e ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "img_usg_doppler_quantidade",
    "header": "Quantidade de Aparelhos [USG com Doppler]",
    "eixo": "imagem",
    "indicador": "USG com Doppler",
    "grupo": "Quantidade",
    "tipo": "numero",
    "unidade": "aparelhos",
    "categorias": null,
    "regra": "Zero é valor válido (unidade sem aparelho).",
    "viz": "Barras"
  },
  {
    "key": "img_usg_doppler_funcionamento",
    "header": "Funcionamento do serviço (8/12/24h) [USG com Doppler]",
    "eixo": "imagem",
    "indicador": "USG com Doppler",
    "grupo": "Funcionamento",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não possui",
      "08 horas/dia",
      "12 horas/dia",
      "24 horas/dia"
    ],
    "regra": "Categórico; 'Não possui' tratado como ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "img_usg_doppler_laudos",
    "header": "Emissão de Laudos (Presencial/Telemedicina) [USG com Doppler]",
    "eixo": "imagem",
    "indicador": "USG com Doppler",
    "grupo": "Emissão de laudos",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não Oferta o Serviço",
      "Presencial",
      "Telemedicina"
    ],
    "regra": "Categórico; usado para calcular ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "img_usg_doppler_local",
    "header": "Local de Instalação do equipamento [USG com Doppler]",
    "eixo": "imagem",
    "indicador": "USG com Doppler",
    "grupo": "Local de instalação",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não Oferta o Serviço",
      "Na Unidade",
      "Outra unidade"
    ],
    "regra": "Separa oferta própria, oferta em outra unidade e ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "img_raio_x_quantidade",
    "header": "Quantidade de Aparelhos [Aparelho de RX]",
    "eixo": "imagem",
    "indicador": "Aparelho de RX",
    "grupo": "Quantidade",
    "tipo": "numero",
    "unidade": "aparelhos",
    "categorias": null,
    "regra": "Zero é valor válido (unidade sem aparelho).",
    "viz": "Barras"
  },
  {
    "key": "img_raio_x_funcionamento",
    "header": "Funcionamento do serviço (8/12/24h) [Aparelho de RX]",
    "eixo": "imagem",
    "indicador": "Aparelho de RX",
    "grupo": "Funcionamento",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não possui",
      "08 horas/dia",
      "12 horas/dia",
      "24 horas/dia"
    ],
    "regra": "Categórico; 'Não possui' tratado como ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "img_raio_x_laudos",
    "header": "Emissão de Laudos (Presencial/Telemedicina) [Aparelho de RX]",
    "eixo": "imagem",
    "indicador": "Aparelho de RX",
    "grupo": "Emissão de laudos",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não Oferta o Serviço",
      "Presencial",
      "Telemedicina"
    ],
    "regra": "Categórico; usado para calcular ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "img_raio_x_local",
    "header": "Local de Instalação do equipamento [Aparelho de RX]",
    "eixo": "imagem",
    "indicador": "Aparelho de RX",
    "grupo": "Local de instalação",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Não Oferta o Serviço",
      "Na Unidade",
      "Outra unidade"
    ],
    "regra": "Separa oferta própria, oferta em outra unidade e ausência de serviço.",
    "viz": "Barras empilhadas"
  },
  {
    "key": "esp_clinica_medica_plantao24h",
    "header": "Informe a quantidade de especialistas na escala por plantão (24h). [Clínica Médica]",
    "eixo": "especialidades",
    "indicador": "Clínica Médica",
    "grupo": "Plantão 24h",
    "tipo": "misto_numero_texto",
    "unidade": null,
    "categorias": null,
    "regra": "Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza.",
    "viz": "Barras, lacunas"
  },
  {
    "key": "esp_clinica_medica_presencial",
    "header": "Quantidade de especialistas em regime presencial [Clínica Médica]",
    "eixo": "especialidades",
    "indicador": "Clínica Médica",
    "grupo": "Presencial",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_clinica_medica_sobreaviso",
    "header": "Quantidade de especialistas em regime de Sobreaviso [Clínica Médica]",
    "eixo": "especialidades",
    "indicador": "Clínica Médica",
    "grupo": "Sobreaviso",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_clinica_medica_telemedicina",
    "header": "Quantidade de especialistas em regime de Telemedicina [Clínica Médica]",
    "eixo": "especialidades",
    "indicador": "Clínica Médica",
    "grupo": "Telemedicina",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_clinica_medica_carga_horaria",
    "header": "Carga Horária dos profissionais especialistas [Clínica Médica]",
    "eixo": "especialidades",
    "indicador": "Clínica Médica",
    "grupo": "Carga horária",
    "tipo": "duracao_texto",
    "unidade": null,
    "categorias": [
      "4h",
      "6h",
      "8h",
      "12h",
      "24h",
      "Não dispõe da especialidade"
    ],
    "regra": "Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência.",
    "viz": "Tabela, carga horária por especialidade"
  },
  {
    "key": "esp_pediatria_plantao24h",
    "header": "Informe a quantidade de especialistas na escala por plantão (24h). [Pediatria]",
    "eixo": "especialidades",
    "indicador": "Pediatria",
    "grupo": "Plantão 24h",
    "tipo": "misto_numero_texto",
    "unidade": null,
    "categorias": null,
    "regra": "Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza.",
    "viz": "Barras, lacunas"
  },
  {
    "key": "esp_pediatria_presencial",
    "header": "Quantidade de especialistas em regime presencial [Pediatria]",
    "eixo": "especialidades",
    "indicador": "Pediatria",
    "grupo": "Presencial",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_pediatria_sobreaviso",
    "header": "Quantidade de especialistas em regime de Sobreaviso [Pediatria]",
    "eixo": "especialidades",
    "indicador": "Pediatria",
    "grupo": "Sobreaviso",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_pediatria_telemedicina",
    "header": "Quantidade de especialistas em regime de Telemedicina [Pediatria]",
    "eixo": "especialidades",
    "indicador": "Pediatria",
    "grupo": "Telemedicina",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_pediatria_carga_horaria",
    "header": "Carga Horária dos profissionais especialistas [Pediatria]",
    "eixo": "especialidades",
    "indicador": "Pediatria",
    "grupo": "Carga horária",
    "tipo": "duracao_texto",
    "unidade": null,
    "categorias": [
      "4h",
      "6h",
      "8h",
      "12h",
      "24h",
      "Não dispõe da especialidade"
    ],
    "regra": "Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência.",
    "viz": "Tabela, carga horária por especialidade"
  },
  {
    "key": "esp_cirurgia_geral_plantao24h",
    "header": "Informe a quantidade de especialistas na escala por plantão (24h). [Cirurgia Geral]",
    "eixo": "especialidades",
    "indicador": "Cirurgia Geral",
    "grupo": "Plantão 24h",
    "tipo": "misto_numero_texto",
    "unidade": null,
    "categorias": null,
    "regra": "Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza.",
    "viz": "Barras, lacunas"
  },
  {
    "key": "esp_cirurgia_geral_presencial",
    "header": "Quantidade de especialistas em regime presencial [Cirurgia Geral]",
    "eixo": "especialidades",
    "indicador": "Cirurgia Geral",
    "grupo": "Presencial",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_cirurgia_geral_sobreaviso",
    "header": "Quantidade de especialistas em regime de Sobreaviso [Cirurgia Geral]",
    "eixo": "especialidades",
    "indicador": "Cirurgia Geral",
    "grupo": "Sobreaviso",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_cirurgia_geral_telemedicina",
    "header": "Quantidade de especialistas em regime de Telemedicina [Cirurgia Geral]",
    "eixo": "especialidades",
    "indicador": "Cirurgia Geral",
    "grupo": "Telemedicina",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_cirurgia_geral_carga_horaria",
    "header": "Carga Horária dos profissionais especialistas [Cirurgia Geral]",
    "eixo": "especialidades",
    "indicador": "Cirurgia Geral",
    "grupo": "Carga horária",
    "tipo": "duracao_texto",
    "unidade": null,
    "categorias": [
      "4h",
      "6h",
      "8h",
      "12h",
      "24h",
      "Não dispõe da especialidade"
    ],
    "regra": "Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência.",
    "viz": "Tabela, carga horária por especialidade"
  },
  {
    "key": "esp_ginecologia_obstetricia_plantao24h",
    "header": "Informe a quantidade de especialistas na escala por plantão (24h). [Ginecologia/Obstetrícia]",
    "eixo": "especialidades",
    "indicador": "Ginecologia/Obstetrícia",
    "grupo": "Plantão 24h",
    "tipo": "misto_numero_texto",
    "unidade": null,
    "categorias": null,
    "regra": "Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza.",
    "viz": "Barras, lacunas"
  },
  {
    "key": "esp_ginecologia_obstetricia_presencial",
    "header": "Quantidade de especialistas em regime presencial [Ginecologia/Obstetrícia]",
    "eixo": "especialidades",
    "indicador": "Ginecologia/Obstetrícia",
    "grupo": "Presencial",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_ginecologia_obstetricia_sobreaviso",
    "header": "Quantidade de especialistas em regime de Sobreaviso [Ginecologia/Obstetrícia]",
    "eixo": "especialidades",
    "indicador": "Ginecologia/Obstetrícia",
    "grupo": "Sobreaviso",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_ginecologia_obstetricia_telemedicina",
    "header": "Quantidade de especialistas em regime de Telemedicina [Ginecologia/Obstetrícia]",
    "eixo": "especialidades",
    "indicador": "Ginecologia/Obstetrícia",
    "grupo": "Telemedicina",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_ginecologia_obstetricia_carga_horaria",
    "header": "Carga Horária dos profissionais especialistas [Ginecologia/Obstetrícia]",
    "eixo": "especialidades",
    "indicador": "Ginecologia/Obstetrícia",
    "grupo": "Carga horária",
    "tipo": "duracao_texto",
    "unidade": null,
    "categorias": [
      "4h",
      "6h",
      "8h",
      "12h",
      "24h",
      "Não dispõe da especialidade"
    ],
    "regra": "Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência.",
    "viz": "Tabela, carga horária por especialidade"
  },
  {
    "key": "esp_neurocirurgia_plantao24h",
    "header": "Informe a quantidade de especialistas na escala por plantão (24h). [Neurocirurgia]",
    "eixo": "especialidades",
    "indicador": "Neurocirurgia",
    "grupo": "Plantão 24h",
    "tipo": "misto_numero_texto",
    "unidade": null,
    "categorias": null,
    "regra": "Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza.",
    "viz": "Barras, lacunas"
  },
  {
    "key": "esp_neurocirurgia_presencial",
    "header": "Quantidade de especialistas em regime presencial [Neurocirurgia]",
    "eixo": "especialidades",
    "indicador": "Neurocirurgia",
    "grupo": "Presencial",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_neurocirurgia_sobreaviso",
    "header": "Quantidade de especialistas em regime de Sobreaviso [Neurocirurgia]",
    "eixo": "especialidades",
    "indicador": "Neurocirurgia",
    "grupo": "Sobreaviso",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_neurocirurgia_telemedicina",
    "header": "Quantidade de especialistas em regime de Telemedicina [Neurocirurgia]",
    "eixo": "especialidades",
    "indicador": "Neurocirurgia",
    "grupo": "Telemedicina",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_neurocirurgia_carga_horaria",
    "header": "Carga Horária dos profissionais especialistas [Neurocirurgia]",
    "eixo": "especialidades",
    "indicador": "Neurocirurgia",
    "grupo": "Carga horária",
    "tipo": "duracao_texto",
    "unidade": null,
    "categorias": [
      "4h",
      "6h",
      "8h",
      "12h",
      "24h",
      "Não dispõe da especialidade"
    ],
    "regra": "Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência.",
    "viz": "Tabela, carga horária por especialidade"
  },
  {
    "key": "esp_cardiologia_plantao24h",
    "header": "Informe a quantidade de especialistas na escala por plantão (24h). [Cardiologia]",
    "eixo": "especialidades",
    "indicador": "Cardiologia",
    "grupo": "Plantão 24h",
    "tipo": "misto_numero_texto",
    "unidade": null,
    "categorias": null,
    "regra": "Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza.",
    "viz": "Barras, lacunas"
  },
  {
    "key": "esp_cardiologia_presencial",
    "header": "Quantidade de especialistas em regime presencial [Cardiologia]",
    "eixo": "especialidades",
    "indicador": "Cardiologia",
    "grupo": "Presencial",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_cardiologia_sobreaviso",
    "header": "Quantidade de especialistas em regime de Sobreaviso [Cardiologia]",
    "eixo": "especialidades",
    "indicador": "Cardiologia",
    "grupo": "Sobreaviso",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_cardiologia_telemedicina",
    "header": "Quantidade de especialistas em regime de Telemedicina [Cardiologia]",
    "eixo": "especialidades",
    "indicador": "Cardiologia",
    "grupo": "Telemedicina",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_cardiologia_carga_horaria",
    "header": "Carga Horária dos profissionais especialistas [Cardiologia]",
    "eixo": "especialidades",
    "indicador": "Cardiologia",
    "grupo": "Carga horária",
    "tipo": "duracao_texto",
    "unidade": null,
    "categorias": [
      "4h",
      "6h",
      "8h",
      "12h",
      "24h",
      "Não dispõe da especialidade"
    ],
    "regra": "Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência.",
    "viz": "Tabela, carga horária por especialidade"
  },
  {
    "key": "esp_cirurgia_vascular_plantao24h",
    "header": "Informe a quantidade de especialistas na escala por plantão (24h). [Cirurgia Vascular]",
    "eixo": "especialidades",
    "indicador": "Cirurgia Vascular",
    "grupo": "Plantão 24h",
    "tipo": "misto_numero_texto",
    "unidade": null,
    "categorias": null,
    "regra": "Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza.",
    "viz": "Barras, lacunas"
  },
  {
    "key": "esp_cirurgia_vascular_presencial",
    "header": "Quantidade de especialistas em regime presencial [Cirurgia Vascular]",
    "eixo": "especialidades",
    "indicador": "Cirurgia Vascular",
    "grupo": "Presencial",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_cirurgia_vascular_sobreaviso",
    "header": "Quantidade de especialistas em regime de Sobreaviso [Cirurgia Vascular]",
    "eixo": "especialidades",
    "indicador": "Cirurgia Vascular",
    "grupo": "Sobreaviso",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_cirurgia_vascular_telemedicina",
    "header": "Quantidade de especialistas em regime de Telemedicina [Cirurgia Vascular]",
    "eixo": "especialidades",
    "indicador": "Cirurgia Vascular",
    "grupo": "Telemedicina",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_cirurgia_vascular_carga_horaria",
    "header": "Carga Horária dos profissionais especialistas [Cirurgia Vascular]",
    "eixo": "especialidades",
    "indicador": "Cirurgia Vascular",
    "grupo": "Carga horária",
    "tipo": "duracao_texto",
    "unidade": null,
    "categorias": [
      "4h",
      "6h",
      "8h",
      "12h",
      "24h",
      "Não dispõe da especialidade"
    ],
    "regra": "Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência.",
    "viz": "Tabela, carga horária por especialidade"
  },
  {
    "key": "esp_ortopedia_plantao24h",
    "header": "Informe a quantidade de especialistas na escala por plantão (24h). [Ortopedia]",
    "eixo": "especialidades",
    "indicador": "Ortopedia",
    "grupo": "Plantão 24h",
    "tipo": "misto_numero_texto",
    "unidade": null,
    "categorias": null,
    "regra": "Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza.",
    "viz": "Barras, lacunas"
  },
  {
    "key": "esp_ortopedia_presencial",
    "header": "Quantidade de especialistas em regime presencial [Ortopedia]",
    "eixo": "especialidades",
    "indicador": "Ortopedia",
    "grupo": "Presencial",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_ortopedia_sobreaviso",
    "header": "Quantidade de especialistas em regime de Sobreaviso [Ortopedia]",
    "eixo": "especialidades",
    "indicador": "Ortopedia",
    "grupo": "Sobreaviso",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_ortopedia_telemedicina",
    "header": "Quantidade de especialistas em regime de Telemedicina [Ortopedia]",
    "eixo": "especialidades",
    "indicador": "Ortopedia",
    "grupo": "Telemedicina",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_ortopedia_carga_horaria",
    "header": "Carga Horária dos profissionais especialistas [Ortopedia]",
    "eixo": "especialidades",
    "indicador": "Ortopedia",
    "grupo": "Carga horária",
    "tipo": "duracao_texto",
    "unidade": null,
    "categorias": [
      "4h",
      "6h",
      "8h",
      "12h",
      "24h",
      "Não dispõe da especialidade"
    ],
    "regra": "Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência.",
    "viz": "Tabela, carga horária por especialidade"
  },
  {
    "key": "esp_urologia_plantao24h",
    "header": "Informe a quantidade de especialistas na escala por plantão (24h). [Urologia]",
    "eixo": "especialidades",
    "indicador": "Urologia",
    "grupo": "Plantão 24h",
    "tipo": "misto_numero_texto",
    "unidade": null,
    "categorias": null,
    "regra": "Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza.",
    "viz": "Barras, lacunas"
  },
  {
    "key": "esp_urologia_presencial",
    "header": "Quantidade de especialistas em regime presencial [Urologia]",
    "eixo": "especialidades",
    "indicador": "Urologia",
    "grupo": "Presencial",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_urologia_sobreaviso",
    "header": "Quantidade de especialistas em regime de Sobreaviso [Urologia]",
    "eixo": "especialidades",
    "indicador": "Urologia",
    "grupo": "Sobreaviso",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_urologia_telemedicina",
    "header": "Quantidade de especialistas em regime de Telemedicina [Urologia]",
    "eixo": "especialidades",
    "indicador": "Urologia",
    "grupo": "Telemedicina",
    "tipo": "numero",
    "unidade": "profissionais",
    "categorias": null,
    "regra": "Numérico; zero é valor válido.",
    "viz": "Barras empilhadas por regime"
  },
  {
    "key": "esp_urologia_carga_horaria",
    "header": "Carga Horária dos profissionais especialistas [Urologia]",
    "eixo": "especialidades",
    "indicador": "Urologia",
    "grupo": "Carga horária",
    "tipo": "duracao_texto",
    "unidade": null,
    "categorias": [
      "4h",
      "6h",
      "8h",
      "12h",
      "24h",
      "Não dispõe da especialidade"
    ],
    "regra": "Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência.",
    "viz": "Tabela, carga horária por especialidade"
  },
  {
    "key": "cv_trombolise",
    "header": "Capacidade de Resposta Cardiovascular [Realiza Trombólise]",
    "eixo": "capacidade_resposta",
    "indicador": "Realiza Trombólise",
    "grupo": "Cardiovascular",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Própria",
      "Terceirizada",
      "Não possui"
    ],
    "regra": "Categórico institucional.",
    "viz": "Semáforo, barras"
  },
  {
    "key": "cv_hemodinamica",
    "header": "Capacidade de Resposta Cardiovascular [Hemodinâmica (Cineangiocoronariografia)]",
    "eixo": "capacidade_resposta",
    "indicador": "Hemodinâmica (Cineangiocoronariografia)",
    "grupo": "Cardiovascular",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Própria",
      "Terceirizada",
      "Não possui"
    ],
    "regra": "Categórico institucional.",
    "viz": "Semáforo, barras"
  },
  {
    "key": "cv_angioplastia",
    "header": "Capacidade de Resposta Cardiovascular [Realiza Angioplastia Primária (24h)]",
    "eixo": "capacidade_resposta",
    "indicador": "Realiza Angioplastia Primária (24h)",
    "grupo": "Cardiovascular",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Própria",
      "Terceirizada",
      "Não possui"
    ],
    "regra": "Categórico institucional.",
    "viz": "Semáforo, barras"
  },
  {
    "key": "avc_protocolo_trombolise",
    "header": "Capacidade de resposta - Acidente Vascular Cerebral (AVC) e Doença Renal Crônica (DRC) [A unidade possui protocolo institucional de trombólise para AVC Isquêmico (AVCi) com disponibilidade de trombolítico e suporte de neuroimagem 24h?]",
    "eixo": "capacidade_resposta",
    "indicador": "Protocolo de trombólise para AVC isquêmico com neuroimagem 24h",
    "grupo": "AVC / DRC",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Disponibilidade 24h (Presencial)",
      "Disponibilidade (Sobreaviso)",
      "Não disponível"
    ],
    "regra": "Categórico institucional.",
    "viz": "Semáforo"
  },
  {
    "key": "drc_hemodialise_uti",
    "header": "Capacidade de resposta - Acidente Vascular Cerebral (AVC) e Doença Renal Crônica (DRC) [A unidade oferece suporte de Hemodiálise em ambiente de UTI?]",
    "eixo": "capacidade_resposta",
    "indicador": "Hemodiálise em ambiente de UTI",
    "grupo": "AVC / DRC",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Disponibilidade 24h (Presencial)",
      "Disponibilidade (Sobreaviso)",
      "Não disponível"
    ],
    "regra": "Categórico institucional.",
    "viz": "Semáforo"
  },
  {
    "key": "drc_hemodialise_internacao",
    "header": "Capacidade de resposta - Acidente Vascular Cerebral (AVC) e Doença Renal Crônica (DRC) [A unidade possui capacidade para Hemodiálise (máquinas portáteis) em unidades de internação/enfermaria?]",
    "eixo": "capacidade_resposta",
    "indicador": "Hemodiálise em unidades de internação/enfermaria",
    "grupo": "AVC / DRC",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Disponibilidade 24h (Presencial)",
      "Disponibilidade (Sobreaviso)",
      "Não disponível"
    ],
    "regra": "Categórico institucional.",
    "viz": "Semáforo"
  },
  {
    "key": "sm_leitos_especificos",
    "header": "A unidade dispõe de leitos específicos para internação/retaguarda em Saúde Mental?",
    "eixo": "capacidade_resposta",
    "indicador": "Leitos específicos para Saúde Mental",
    "grupo": "Saúde mental",
    "tipo": "sim_nao",
    "unidade": null,
    "categorias": [
      "Sim",
      "Não"
    ],
    "regra": "Sim/Não.",
    "viz": "Semáforo"
  },
  {
    "key": "sm_protocolo_crise",
    "header": "Possui protocolo institucional para atendimento de crises ou surtos psicóticos (incluindo contenção física e química)? ",
    "eixo": "capacidade_resposta",
    "indicador": "Protocolo para crises/surtos psicóticos",
    "grupo": "Saúde mental",
    "tipo": "sim_nao",
    "unidade": null,
    "categorias": [
      "Sim",
      "Não"
    ],
    "regra": "Sim/Não.",
    "viz": "Semáforo"
  },
  {
    "key": "maternidade_perfil",
    "header": "Qual o perfil da maternidade/centro obstétrico da unidade? ",
    "eixo": "capacidade_resposta",
    "indicador": "Perfil da maternidade/centro obstétrico",
    "grupo": "Maternidade",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Alto Risco",
      "Baixo Risco / Risco Habitual",
      "Unidade sem serviço de obstetrícia (Não realiza partos)"
    ],
    "regra": "Categórico institucional.",
    "viz": "Distribuição"
  },
  {
    "key": "incubadora_transporte",
    "header": "A unidade possui Incubadora de Transporte equipada com ventilador mecânico pulmonar em pleno funcionamento? ",
    "eixo": "capacidade_resposta",
    "indicador": "Incubadora de transporte com ventilador mecânico",
    "grupo": "Maternidade",
    "tipo": "sim_nao",
    "unidade": null,
    "categorias": [
      "Sim",
      "Não"
    ],
    "regra": "Sim/Não.",
    "viz": "Semáforo"
  },
  {
    "key": "leite_banco",
    "header": "Estrutura de Apoio Nutricional (Leite Humano) [Banco de Leite Humano (Processamento e Distribuição)]",
    "eixo": "capacidade_resposta",
    "indicador": "Banco de Leite Humano",
    "grupo": "Leite humano",
    "tipo": "sim_nao",
    "unidade": null,
    "categorias": [
      "Sim",
      "Não"
    ],
    "regra": "Sim/Não.",
    "viz": "Semáforo"
  },
  {
    "key": "leite_posto",
    "header": "Estrutura de Apoio Nutricional (Leite Humano) [Posto de Coleta de Leite Humano (Apenas coleta e armazenamento)]",
    "eixo": "capacidade_resposta",
    "indicador": "Posto de Coleta de Leite Humano",
    "grupo": "Leite humano",
    "tipo": "sim_nao",
    "unidade": null,
    "categorias": [
      "Sim",
      "Não"
    ],
    "regra": "Sim/Não.",
    "viz": "Semáforo"
  },
  {
    "key": "leite_nenhum",
    "header": "Estrutura de Apoio Nutricional (Leite Humano) [Não possui estrutura específica]",
    "eixo": "capacidade_resposta",
    "indicador": "Sem estrutura específica de apoio ao leite humano",
    "grupo": "Leite humano",
    "tipo": "sim_nao",
    "unidade": null,
    "categorias": [
      "Sim",
      "Não"
    ],
    "regra": "Sim/Não.",
    "viz": "Semáforo"
  },
  {
    "key": "nir_ativo",
    "header": "A unidade possui Núcleo Interno de Regulação (NIR) ativo para interface com a Central de Regulação? ",
    "eixo": "regulacao",
    "indicador": "Núcleo Interno de Regulação (NIR) ativo",
    "grupo": null,
    "tipo": "sim_nao",
    "unidade": null,
    "categorias": [
      "Sim",
      "Não"
    ],
    "regra": "Sim/Não.",
    "viz": "Semáforo"
  },
  {
    "key": "vaga_zero_frequencia",
    "header": "Qual a frequência média de recebimento de pacientes por dia via \"Vaga Zero\"? ",
    "eixo": "regulacao",
    "indicador": "Frequência média diária de \"Vaga Zero\"",
    "grupo": null,
    "tipo": "numero",
    "unidade": "pacientes/dia",
    "categorias": null,
    "regra": "Numérico (remove zeros à esquerda tipo '00'/'01'); valores extremos (ex.: >100) sinalizados para revisão, não removidos.",
    "viz": "Distribuição, alerta de outlier"
  },
  {
    "key": "vaga_zero_corredor",
    "header": "Qual a média diária de pacientes em \"Vaga Zero\" que permanecem aguardando em corredores?",
    "eixo": "regulacao",
    "indicador": "Pacientes em \"Vaga Zero\" aguardando em corredores",
    "grupo": null,
    "tipo": "numero",
    "unidade": "pacientes/dia",
    "categorias": null,
    "regra": "Numérico (remove zeros à esquerda); valores extremos sinalizados para revisão.",
    "viz": "Distribuição, alerta de outlier"
  },
  {
    "key": "tempo_retencao_maca",
    "header": "Tempo Médio [Qual tempo médio de retenção de maca (SAMU/Bombeiros) na unidade aguardando liberação?]",
    "eixo": "regulacao",
    "indicador": "Tempo médio de retenção de maca (SAMU/Bombeiros)",
    "grupo": null,
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Menos de 10min",
      "Entre 11min e 20min",
      "Entre 21min e 40min",
      "Entre 41min e 59min",
      "Mais de 1h"
    ],
    "regra": "Categórico ordinal por faixa de tempo.",
    "viz": "Barras ordenadas"
  },
  {
    "key": "tempo_espera_uti",
    "header": "Tempo Médio [Qual o tempo médio de espera para transferência de pacientes com indicação de UTI no último mês? (da solicitação à efetiva ocupação do leito).]",
    "eixo": "regulacao",
    "indicador": "Tempo médio de espera por leito de UTI",
    "grupo": null,
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Menos de 10min",
      "Entre 11min e 20min",
      "Entre 21min e 40min",
      "Entre 41min e 59min",
      "Mais de 1h"
    ],
    "regra": "Categórico ordinal por faixa de tempo.",
    "viz": "Barras ordenadas"
  },
  {
    "key": "tempo_espera_retaguarda",
    "header": "Tempo Médio [Após a estabilização do paciente na Sala Vermelha, qual o tempo médio de espera para transferência a um leito de retaguarda? Considerar o último mês e informar em horas. (Numérico) no ultimo mês]",
    "eixo": "regulacao",
    "indicador": "Tempo médio de espera por leito de retaguarda (pós Sala Vermelha)",
    "grupo": null,
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Menos de 10min",
      "Entre 11min e 20min",
      "Entre 21min e 40min",
      "Entre 41min e 59min",
      "Mais de 1h"
    ],
    "regra": "Categórico ordinal por faixa de tempo.",
    "viz": "Barras ordenadas"
  },
  {
    "key": "plano_contingencia",
    "header": "A unidade possui Plano de Contingência para Superlotação formalizado e atualizado?",
    "eixo": "regulacao",
    "indicador": "Plano de Contingência para Superlotação",
    "grupo": null,
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Sim",
      "Não",
      "Em elaboração"
    ],
    "regra": "Categórico (inclui estado intermediário 'Em elaboração').",
    "viz": "Semáforo (3 estados)"
  },
  {
    "key": "disponibilidade_ambulancia",
    "header": "Qual a disponibilidade de ambulância da unidade para transferência de pacientes?",
    "eixo": "regulacao",
    "indicador": "Disponibilidade de ambulância para transferência",
    "grupo": null,
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Possui Ambulância Tipo D (UTI Móvel)",
      "Possui Ambulância Tipo B (Suporte Básico)",
      "Não possui"
    ],
    "regra": "Categórico institucional.",
    "viz": "Distribuição"
  },
  {
    "key": "trauma_centro_cirurgico",
    "header": "Capacidade de resposta - Trauma [Centro Cirúrgico Equipado]",
    "eixo": "trauma",
    "indicador": "Centro Cirúrgico Equipado",
    "grupo": "Trauma",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Disponibilidade 24h (Presencial)",
      "Disponibilidade (Sobreaviso)",
      "Não disponível"
    ],
    "regra": "Categórico institucional.",
    "viz": "Semáforo"
  },
  {
    "key": "trauma_cirurgiao_geral",
    "header": "Capacidade de resposta - Trauma [Cirurgião Geral]",
    "eixo": "trauma",
    "indicador": "Cirurgião Geral",
    "grupo": "Trauma",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Disponibilidade 24h (Presencial)",
      "Disponibilidade (Sobreaviso)",
      "Não disponível"
    ],
    "regra": "Categórico institucional.",
    "viz": "Semáforo"
  },
  {
    "key": "trauma_ortopedista",
    "header": "Capacidade de resposta - Trauma [Ortopedista]",
    "eixo": "trauma",
    "indicador": "Ortopedista",
    "grupo": "Trauma",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Disponibilidade 24h (Presencial)",
      "Disponibilidade (Sobreaviso)",
      "Não disponível"
    ],
    "regra": "Categórico institucional.",
    "viz": "Semáforo"
  },
  {
    "key": "trauma_neurocirurgiao",
    "header": "Capacidade de resposta - Trauma [Neurocirurgião]",
    "eixo": "trauma",
    "indicador": "Neurocirurgião",
    "grupo": "Trauma",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Disponibilidade 24h (Presencial)",
      "Disponibilidade (Sobreaviso)",
      "Não disponível"
    ],
    "regra": "Categórico institucional.",
    "viz": "Semáforo"
  },
  {
    "key": "trauma_anestesiologista",
    "header": "Capacidade de resposta - Trauma [Anestesiologista]",
    "eixo": "trauma",
    "indicador": "Anestesiologista",
    "grupo": "Trauma",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Disponibilidade 24h (Presencial)",
      "Disponibilidade (Sobreaviso)",
      "Não disponível"
    ],
    "regra": "Categórico institucional.",
    "viz": "Semáforo"
  },
  {
    "key": "suporte_hemoterapico",
    "header": "Qual é a estrutura de suporte hemoterápico disponível para atendimento 24h?",
    "eixo": "trauma",
    "indicador": "Estrutura de suporte hemoterápico 24h",
    "grupo": "Suporte estratégico",
    "tipo": "categoria",
    "unidade": null,
    "categorias": [
      "Agência Transfusional Própria (Estrutura interna completa para armazenamento e testes pré-transfusionais).",
      "Reserva Técnica (Estoque local vinculado a uma Agência externa/Hemocentro).",
      "Não possui no local (Dependência de envio externo sob demanda)."
    ],
    "regra": "Categórico institucional.",
    "viz": "Distribuição"
  },
  {
    "key": "heliporto_ativo",
    "header": "A unidade possui Ponto de Pouso ou Heliporto homologado pela ANAC e em condições de operação (ativo)? ",
    "eixo": "trauma",
    "indicador": "Ponto de Pouso/Heliporto homologado ANAC (ativo)",
    "grupo": "Suporte estratégico",
    "tipo": "sim_nao",
    "unidade": null,
    "categorias": [
      "Sim",
      "Não"
    ],
    "regra": "Sim/Não.",
    "viz": "Semáforo"
  }
]
;
