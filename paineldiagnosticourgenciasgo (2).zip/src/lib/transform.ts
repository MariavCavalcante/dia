// Pipeline de transformação: linhas brutas da planilha (CSV já parseado em
// objetos chave/valor pelo cabeçalho original) -> registros limpos,
// anonimizados e prontos para os cálculos de indicadores.
//
// Regras aplicadas aqui (ver docs/dicionario-de-dados.md e docs/metodologia.md):
//  - Linhas totalmente vazias ou sem carimbo de data/hora são descartadas.
//  - Colunas integralmente vazias já foram excluídas do dicionário (gerar-dicionario.py).
//  - Zero é sempre um valor válido; nunca é convertido em "ausente".
//  - Duplicidade de CNES é sinalizada, nunca somada automaticamente.
//  - O campo "Responsável pelo preenchimento" nunca é incluído no registro anonimizado.
import { DICIONARIO } from "./dictionary.generated";
import type { AlertaQualidade, CampoDicionario, RegistroUnidade, ValorMisto } from "../types";
import {
  capitalizarNomeProprio,
  chaveNormalizada,
  ehValorExtremo,
  indicaAusencia,
  limparCnes,
  normalizarEspacos,
  parseCarimbo,
  parseDuracaoTexto,
  parseMisto,
  parseNumero,
} from "./clean";

export type LinhaBruta = Record<string, string | undefined>;

const CAMPO_CARIMBO = "Carimbo de data/hora";
const CAMPO_MUNICIPIO = "Município";
const CAMPO_UNIDADE = "Nome da Unidade de Saúde";
const CAMPO_CNES = "Número do CNES";
const CAMPO_CLASSIFICACAO = "Classificação do Estabelecimento";
const CAMPO_RESPONSAVEL = "Responsável pelo preenchimento";

const CLASSIFICACOES_VALIDAS = new Set([
  "Hospital Geral",
  "Pronto Atendimento-UPA 24h",
  "Unidade Mista",
  "Pronto Socorro Geral",
  "Pronto Socorro Especializado",
  "Hospital Especializado",
]);

// Campos numéricos de baixo volume esperado onde valores muito altos merecem
// sinalização de revisão (não remoção). Limite documentado em docs/metodologia.md.
const CAMPOS_COM_LIMITE_OUTLIER: Record<string, number> = {
  vaga_zero_frequencia: 30,
  vaga_zero_corredor: 30,
};

function linhaTotalmenteVazia(linha: LinhaBruta): boolean {
  return Object.values(linha).every((v) => v === undefined || v === null || String(v).trim() === "");
}

export interface ResultadoTransformacao {
  registros: RegistroUnidade[];
  linhasRecebidas: number;
  registrosValidos: number;
  registrosExcluidos: number;
}

export function transformarLinhas(linhasBrutas: LinhaBruta[]): ResultadoTransformacao {
  const linhasRecebidas = linhasBrutas.length;

  // Passo 1: filtrar linhas vazias / sem carimbo, calcular ISO.
  const candidatos: { linha: LinhaBruta; indice: number; carimboIso: string }[] = [];
  linhasBrutas.forEach((linha, indice) => {
    if (linhaTotalmenteVazia(linha)) return;
    const carimboIso = parseCarimbo(linha[CAMPO_CARIMBO]);
    if (!carimboIso) return; // regra: descartar linhas sem carimbo de data/hora válido
    candidatos.push({ linha, indice, carimboIso });
  });

  // Passo 2: detectar duplicidade de CNES (para sinalização e escolha do
  // "mais recente" na visão consolidada — nunca somando automaticamente).
  const porCnes = new Map<string, typeof candidatos>();
  const cnesLimpoPorIndice = new Map<number, { cnes: string; atipico: boolean }>();
  for (const c of candidatos) {
    const limpo = limparCnes(c.linha[CAMPO_CNES]);
    cnesLimpoPorIndice.set(c.indice, limpo);
    const grupo = porCnes.get(limpo.cnes) ?? [];
    grupo.push(c);
    porCnes.set(limpo.cnes, grupo);
  }
  const maisRecentePorCnes = new Map<string, number>(); // cnes -> indice do candidato mais recente
  for (const [cnes, grupo] of porCnes) {
    if (grupo.length <= 1) continue;
    const maisRecente = grupo.reduce((a, b) => (a.carimboIso > b.carimboIso ? a : b));
    maisRecentePorCnes.set(cnes, maisRecente.indice);
  }

  const registros: RegistroUnidade[] = candidatos.map(({ linha, indice, carimboIso }) => {
    const alertas: AlertaQualidade[] = [];

    const municipioOriginal = normalizarEspacos(linha[CAMPO_MUNICIPIO] ?? "");
    const unidadeOriginal = normalizarEspacos(linha[CAMPO_UNIDADE] ?? "");
    const { cnes, atipico: cnesAtipico } = cnesLimpoPorIndice.get(indice)!;
    const classificacaoOriginal = normalizarEspacos(linha[CAMPO_CLASSIFICACAO] ?? "");
    const classificacaoResidual = classificacaoOriginal !== "" && !CLASSIFICACOES_VALIDAS.has(classificacaoOriginal);

    if (cnesAtipico) {
      alertas.push({
        tipo: "cnes_atipico",
        campo: "cnes",
        mensagem: `CNES com formato atípico ("${cnes}"): revisar número de dígitos.`,
      });
    }
    if (classificacaoResidual) {
      alertas.push({
        tipo: "categoria_residual",
        campo: "classificacao",
        mensagem: `Classificação do estabelecimento fora do conjunto padrão ("${classificacaoOriginal}"): requer validação institucional.`,
      });
    }

    const grupoDuplicado = porCnes.get(cnes) ?? [];
    const duplicadoCnes = grupoDuplicado.length > 1;
    const maisRecenteEntreDuplicados = duplicadoCnes ? maisRecentePorCnes.get(cnes) === indice : true;
    if (duplicadoCnes) {
      alertas.push({
        tipo: "cnes_duplicado",
        campo: "cnes",
        mensagem: `CNES "${cnes}" possui ${grupoDuplicado.length} respostas. Resposta mais recente usada na visão consolidada; nenhum valor foi somado automaticamente.`,
      });
    }

    // Monta o mapa de campos analíticos segundo o dicionário de dados.
    const campos: Record<string, string | number | ValorMisto | null> = {};
    let camposAplicaveis = 0;
    let camposPreenchidos = 0;

    for (const def of DICIONARIO as CampoDicionario[]) {
      if (
        def.header === CAMPO_CARIMBO ||
        def.header === CAMPO_MUNICIPIO ||
        def.header === CAMPO_UNIDADE ||
        def.header === CAMPO_CNES ||
        def.header === CAMPO_CLASSIFICACAO ||
        def.header === CAMPO_RESPONSAVEL // nunca incluído no registro anonimizado
      ) {
        continue;
      }

      camposAplicaveis += 1;
      const bruto = linha[def.header];
      const valorAusente = bruto === undefined || bruto === null || bruto.trim() === "";

      let valor: string | number | ValorMisto | null = null;
      switch (def.tipo) {
        case "numero": {
          const n = parseNumero(bruto);
          valor = n;
          if (n !== null) {
            camposPreenchidos += 1;
            const limite = CAMPOS_COM_LIMITE_OUTLIER[def.key];
            if (limite !== undefined && ehValorExtremo(n, limite)) {
              alertas.push({
                tipo: "valor_extremo",
                campo: def.key,
                mensagem: `${def.indicador}: valor ${n} está acima do esperado (limite de referência: ${limite}). Sinalizado para revisão, não removido.`,
              });
            }
          }
          break;
        }
        case "misto_numero_texto": {
          const v = parseMisto(bruto);
          valor = v;
          if (v.numero !== null || v.texto !== null) camposPreenchidos += 1;
          break;
        }
        case "duracao_texto": {
          const v = parseDuracaoTexto(bruto);
          valor = v;
          if (v.numero !== null || v.texto !== null) camposPreenchidos += 1;
          break;
        }
        case "categoria":
        case "sim_nao": {
          if (!valorAusente) {
            valor = normalizarEspacos(bruto as string);
            camposPreenchidos += 1;
          } else {
            valor = null;
          }
          break;
        }
        default: {
          valor = valorAusente ? null : normalizarEspacos(bruto as string);
          if (!valorAusente) camposPreenchidos += 1;
        }
      }
      campos[def.key] = valor;
    }

    if (camposAplicaveis > 0 && camposPreenchidos / camposAplicaveis < 0.4) {
      alertas.push({
        tipo: "campo_ausente",
        mensagem: "Resposta com menos de 40% dos campos analíticos preenchidos.",
      });
    }

    const registro: RegistroUnidade = {
      id: duplicadoCnes ? `${cnes}-l${indice}` : cnes || `sem-cnes-l${indice}`,
      linha: indice + 1,
      carimbo: carimboIso,
      municipio: capitalizarNomeProprio(municipioOriginal),
      municipioNormalizado: chaveNormalizada(municipioOriginal),
      unidade: capitalizarNomeProprio(unidadeOriginal),
      cnes,
      cnesAtipico,
      classificacao: classificacaoOriginal || "Não informado",
      classificacaoResidual,
      duplicadoCnes,
      maisRecenteEntreDuplicados,
      completude: camposAplicaveis > 0 ? camposPreenchidos / camposAplicaveis : 0,
      alertas,
      campos,
    };
    return registro;
  });

  return {
    registros,
    linhasRecebidas,
    registrosValidos: registros.length,
    registrosExcluidos: linhasRecebidas - registros.length,
  };
}

/** Indica se um valor de campo (qualquer tipo) deve contar como "disponível"
 * para os semáforos/indicadores binários (regra 2.10: verde/amarelo/vermelho/cinza). */
export function classificarDisponibilidade(
  valor: string | number | ValorMisto | null
): "verde" | "amarelo" | "vermelho" | "cinza" {
  if (valor === null || valor === undefined) return "cinza";
  if (typeof valor === "number") return valor > 0 ? "verde" : "vermelho";
  if (typeof valor === "string") {
    const chave = chaveNormalizada(valor);
    if (chave === "sim") return "verde";
    if (chave === "não" || chave === "nao") return "vermelho";
    if (chave.includes("24h") && chave.includes("presencial")) return "verde";
    if (chave.includes("sobreaviso")) return "amarelo";
    if (indicaAusencia(valor)) return "vermelho";
    if (chave === "própria" || chave === "propria") return "verde";
    if (chave === "terceirizada") return "amarelo";
    if (chave === "em elaboração" || chave === "em elaboracao") return "amarelo";
    return "cinza";
  }
  // ValorMisto
  if (valor.numero !== null) return valor.numero > 0 ? "verde" : "vermelho";
  if (valor.texto !== null) return indicaAusencia(valor.texto) ? "vermelho" : "cinza";
  return "cinza";
}
