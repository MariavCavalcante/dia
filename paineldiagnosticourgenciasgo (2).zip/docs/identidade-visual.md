# Identidade visual — Estado de Goiás

## Brasão Oficial: removido a pedido

Uma versão inicial deste projeto reservava um espaço no cabeçalho para o
Brasão Oficial do Estado de Goiás, usando um placeholder neutro
(`brasao-goias-placeholder.svg`) até a substituição pelo arquivo institucional
oficial — a IA que gerou o código nunca teve acesso a um arquivo autorizado e
não deveria desenhar um brasão do zero (regra 2.5 do prompt mestre: "não
redesenhar, recortar, inclinar, esticar, aplicar sombra, alterar cores ou
inserir o brasão dentro de formas não previstas").

**A pedido da responsável pelo projeto, o Brasão (e o placeholder) foi
removido do cabeçalho.** Em seu lugar, `src/components/Header.tsx` usa uma
barra decorativa discreta nas cores oficiais do Estado (azul e verde
institucionais, com um traço fino de amarelo — ver paleta abaixo), apenas
para manter a identidade visual sem depender de um símbolo oficial.

Se a Secretaria decidir reintroduzir o Brasão Oficial no futuro, o arquivo
vetorial pode ser obtido em uma das fontes institucionais abaixo e adicionado
de volta ao cabeçalho:

- Casa Civil do Estado de Goiás — Legislação histórica, bandeira e armas:
  <https://goias.gov.br/casacivil/legislacao-historica/>
- Portal Goiás — Símbolos estaduais: <https://goias.gov.br/simbolos-estaduais/>
- Secretaria de Estado da Cultura — Logotipos e mídias:
  <https://goias.gov.br/cultura/logotipos-e-midias/>

## Paleta institucional (oficial)

| Cor | HEX | RGB | Uso recomendado |
|---|---|---|---|
| Verde | `#19A32A` | 25, 163, 42 | Destaques positivos, botões e elementos de Goiás |
| Amarelo | `#FFDE00` | 255, 222, 0 | Ênfase pontual, alertas leves e realces — nunca em grandes áreas |
| Azul | `#00509F` | 0, 80, 159 | Cabeçalhos, navegação, títulos e séries principais |
| Branco | `#FFFFFF` | 255, 255, 255 | Planos de fundo, respiro e contraste |

Definida em `src/lib/paleta.ts` (`MARCA`) e em `tailwind.config.js` (`colors.go`).

## Paleta de visualização de dados

As cores usadas em gráficos (barras, rosquinhas) **não são as mesmas**
usadas na marca institucional. O amarelo oficial (`#FFDE00`) falha o piso de
contraste WCAG sobre fundo claro quando usado como marca de dado — o que é
consistente com a própria regra do prompt mestre ("usar amarelo com parcimônia
e nunca como cor predominante em grandes áreas de leitura"). Por isso:

- A paleta categórica de gráficos (`CATEGORICA_LIGHT`/`CATEGORICA_DARK` em
  `src/lib/paleta.ts`) usa azul e verde institucionais como as duas primeiras
  cores, estendida com tons adicionais validados para leitura por pessoas com
  daltonismo.
- Validação executada com o validador de acessibilidade cromática (contraste,
  separação de matiz simulando daltonismo e piso de visão normal):
  - Claro: `node scripts/validate_palette.js "#00509F,#19A32A,#7C4A02,#6B4C9A" --mode light` → todos os testes passam.
  - Escuro: `node scripts/validate_palette.js "#3987e5,#199e70,#d95926,#9085e9" --mode dark` → todos os testes passam.
- As cores de status (verde/amarelo/âmbar escuro/vermelho/cinza) usadas nos
  semáforos (regra 2.10) são fixas e sempre acompanhadas de ícone + rótulo
  textual — nunca dependem apenas da cor (regra 2.11).

## Cabeçalho institucional

Implementado em `src/components/Header.tsx`:

- Barra decorativa nas cores oficiais, sem o Brasão (ver acima).
- "Governo do Estado de Goiás" / "Secretaria de Estado da Saúde".
- Título "Painel do Diagnóstico Situacional da Rede de Atenção às Urgências".
- Identificação territorial "Estado de Goiás".
- Data/hora da última sincronização (fuso `America/Sao_Paulo`).
- Indicador de estado de sincronização (atualizado / atualizando / atrasado / falha).
- Controle de alto contraste (acessibilidade).
- Nenhum slogan ou elemento promocional de gestão — compatível com período de
  vedação eleitoral.
