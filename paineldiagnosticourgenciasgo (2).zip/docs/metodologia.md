# Metodologia

Este documento descreve as regras de limpeza, tratamento, cálculo e classificação
usadas pelo Painel do Diagnóstico Situacional da Rede de Atenção às Urgências do
Estado de Goiás. Ele complementa o [dicionário de dados](./dicionario-de-dados.md)
e reflete as regras obrigatórias da seção 2 do prompt mestre que originou este
projeto (`Prompt_Mestre_Diagnostico_Situacional_Goias.docx`).

## 1. Fonte de dados

- **Fonte oficial**: Planilha Google "DIAGNÓSTICO SITUACIONAL (respostas)"
  vinculada ao Google Forms, publicada em CSV (ver
  `docs/integracao-google-forms.md`, seção "Planilha em uso" — inclui a
  verificação de que o conteúdo bate campo a campo com a base usada para
  desenvolver e testar este projeto).
- **Aba publicada**: `gid=119176214`.
- **Variável de ambiente**: `GOOGLE_SHEETS_CSV_URL` (ver `.env.example` — já
  preenchida com a URL real).
- O arquivo Excel original (`DIAGNÓSTICO SITUACIONAL (respostas).xlsx`) e a
  planilha de referência (`scripts/fixtures/planilha-referencia.csv`) permanecem
  apenas para desenvolvimento local sem depender de rede. Em produção, todos os
  indicadores são calculados exclusivamente a partir da URL CSV pública.

## 2. Linhas e colunas descartadas

- Linhas totalmente vazias são descartadas.
- Linhas sem carimbo de data/hora válido (`dd/mm/aaaa HH:MM:SS`) são descartadas.
- Colunas integralmente vazias na base analisada (51 das 174 colunas originais)
  foram excluídas da camada analítica — **sem alterar o arquivo-fonte**. A lista
  completa de colunas mantidas está no [dicionário de dados](./dicionario-de-dados.md).
- A aba auxiliar "Página1" não é usada como fonte analítica.

## 3. Regras de limpeza por tipo de campo

| Tipo | Regra |
|---|---|
| `numero` | Convertido para número; zero é sempre um valor válido, nunca tratado como ausência. Zeros à esquerda (`"00"`) são normalizados sem alterar o valor. |
| `misto_numero_texto` | Tenta interpretar como número; se não for numérico, preserva o texto original (ex.: "Não dispõe da especialidade"). Nunca descarta a resposta. |
| `duracao_texto` | Interpreta o padrão `"Xh"` como número de horas; preserva texto de ausência quando presente. |
| `categoria` / `sim_nao` | Mantido como texto normalizado (espaços/capitalização apenas na apresentação); o valor original é preservado para auditoria. |
| `texto` | Nome de município/unidade: normalizado apenas na apresentação (capitalização), chave de comparação sem acentos para buscas e agregações. |
| `texto_pessoal` | Nunca sai da camada de transformação — descartado antes de qualquer resposta pública. |

CNES é sempre tratado como texto: o sufixo decimal produzido por exportações do
Excel é removido, mas nenhum zero à esquerda é eliminado. CNES com formato
atípico (mais ou menos de 7 dígitos, ou não numérico) é sinalizado para revisão,
nunca excluído automaticamente.

## 4. Duplicidade de CNES

Quando duas ou mais respostas compartilham o mesmo CNES, **nenhum valor é somado
automaticamente**. Todas as respostas duplicadas são sinalizadas com o alerta
`cnes_duplicado`. Na visão consolidada (usada pelos indicadores agregados e
rankings), apenas a resposta com carimbo mais recente é considerada; a tabela de
qualidade e a tabela detalhada continuam mostrando todas as respostas para
auditoria. Na base de referência, 4 CNES têm mais de uma resposta (8 linhas ao
todo).

## 5. Categoria residual

"Opção 8" na Classificação do Estabelecimento é uma categoria residual fora do
conjunto padrão (Hospital Geral, Pronto Atendimento-UPA 24h, Unidade Mista,
Pronto Socorro Geral, Pronto Socorro Especializado, Hospital Especializado). É
sinalizada com o alerta `categoria_residual` e requer validação institucional
antes de ser reclassificada — o painel nunca reclassifica automaticamente.

## 6. Valores extremos

Campos numéricos de baixo volume esperado (frequência diária de "Vaga Zero" e
pacientes aguardando em corredores) são sinalizados quando o valor ultrapassa um
limite de referência documentado no código (`CAMPOS_COM_LIMITE_OUTLIER` em
`src/lib/transform.ts`, atualmente 30). O valor **nunca é removido ou alterado**
— apenas sinalizado com o alerta `valor_extremo` para revisão humana.

## 7. Indicadores e regras de cálculo

| Indicador | Fórmula | Numerador | Denominador | Regra para valores ausentes |
|---|---|---|---|---|
| Total de respostas | Contagem de linhas válidas com carimbo | Linhas com carimbo válido | — | Linhas sem carimbo descartadas antes do cálculo |
| Municípios respondentes | Contagem distinta do município normalizado | Municípios distintos | — | — |
| Respostas por município | Contagem agrupada por município, ordenada decrescente (empate: alfabético) | Respostas do município | — | — |
| Diferença de leitos | Operacional SUS − Cadastrado CNES, por tipo | Soma de leitos operacionais válidos | Soma de leitos cadastrados válidos | Zero é válido; não preenchido não entra na soma |
| Disponibilidade de item | % de unidades com valor > 0 | Unidades com valor > 0 | Unidades com resposta válida para o item | Sem resposta não conta no denominador |
| Completude | Campos preenchidos ÷ campos aplicáveis | Campos preenchidos | Total de campos analíticos do eixo | Colunas vazias já excluídas da base |
| Cobertura territorial | Municípios respondentes ÷ total oficial | Municípios respondentes | 246 municípios (IBGE) — informativo nesta v1 | Não usado como indicador oficial sem validação institucional |

## 8. Semáforos (verde / amarelo / vermelho / cinza)

Implementado em `classificarDisponibilidade()` (`src/lib/transform.ts`):

- **Verde**: valor numérico > 0; "Sim"; "Disponibilidade 24h (Presencial)"; "Própria".
- **Amarelo**: "Disponibilidade (Sobreaviso)"; "Terceirizada"; "Em elaboração".
- **Vermelho**: valor numérico = 0; "Não"; e qualquer expressão de ausência
  ("Não possui", "Não Oferta o Serviço", "Não disponível", "Não dispõe da
  especialidade").
- **Cinza**: campo não respondido (`null`/`undefined`).

Nenhuma meta clínica ou administrativa é inferida sem fonte normativa ou
definição explícita do gestor (regra 2.10) — os semáforos refletem apenas o que
foi respondido.

## 9. Anonimização

O campo "Responsável pelo preenchimento" é lido durante a transformação apenas
para fins de detecção de linhas vazias, e **nunca** é copiado para o objeto de
saída (`RegistroUnidade.campos` não contém esse campo — ver
`src/lib/transform.ts`). A Netlify Function (`netlify/functions/dados.ts`) só
devolve o objeto já transformado; a planilha bruta nunca é exposta ao navegador.

## 10. Escopo da busca avançada (v1)

A busca textual com sugestões automáticas cobre diretamente os quatro campos de
identificação (Município, Unidade, CNES, Classificação). Os demais eixos
(leitos, equipamentos, especialidades, capacidade de resposta, regulação,
trauma) são explorados através dos filtros globais combinados com as páginas
temáticas, que resolvem o mesmo objetivo de leitura cruzada dos 123 campos
analíticos sem exigir um índice de busca textual sobre campos numéricos/mistos.
Uma extensão futura pode indexar esses campos para busca literal, se a
Secretaria priorizar esse caso de uso.
