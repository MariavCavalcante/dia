# Integração com Google Forms / Google Sheets

## Planilha em uso

O painel já está conectado à planilha real do Google Forms, usando a URL
publicada oficialmente informada pela responsável pelo projeto:

- **Planilha**: "DIAGNÓSTICO SITUACIONAL (respostas)"
- **Publicação**: Arquivo → Compartilhar → Publicar na web (aba de respostas,
  formato CSV) — `gid=119176214`.
- **Conteúdo verificado em 18/08/2026**: 172 respostas, cabeçalho e dados
  idênticos, campo a campo, à planilha de referência já usada para construir
  e testar todo o painel (`scripts/fixtures/planilha-referencia.csv`) — ou
  seja, o painel já foi validado contra os dados reais desta planilha
  específica.
- **Testado ponta a ponta**: `npm run dev` com `GOOGLE_SHEETS_CSV_URL`
  apontando para essa URL retornou `/api/dados` com sucesso (172 registros
  válidos, sem cair na planilha de referência local).

A URL já está preenchida em `.env.example` — basta copiar para `.env`
(desenvolvimento local) ou configurar a mesma variável no Netlify (produção):

```
GOOGLE_SHEETS_CSV_URL="https://docs.google.com/spreadsheets/d/e/2PACX-1vQuHw0MOxWL03TS20MzywhAjTtTNTHEE7xWSh_9faIb7fkytQPBSgxtY9ZR32WAnw4biyJGngs09pxv/pub?gid=119176214&single=true&output=csv"
```

> **Atenção — privacidade da planilha bruta em si**: o painel nunca expõe o
> campo "Responsável pelo preenchimento" (ver "Garantias de privacidade"
> abaixo), mas uma planilha publicada na web fica acessível a qualquer pessoa
> que tenha o link, sem exigir login — ou seja, alguém que descubra o link de
> publicação (não o do painel) veria os nomes de quem preencheu cada
> resposta. Isso é inerente ao mecanismo de "Publicar na web" e necessário
> para que a Netlify Function busque os dados sem autenticação; vale
> confirmar com a equipe responsável pela planilha se esse nível de exposição
> é o pretendido antes da publicação definitiva do painel — a alternativa
> mais restrita (conta de serviço, sem publicação pública) está descrita
> abaixo.

## Atualização automática (sem redeploy)

O painel nunca precisa de um novo build/deploy para refletir uma nova resposta
do Google Forms:

1. **Verificação periódica**: o navegador consulta `/api/dados` ao carregar a
   página e novamente a cada 1–5 minutos (`VITE_SYNC_INTERVAL_MS`, ver
   `src/hooks/useDataset.ts`), além de revalidar sempre que a aba volta a ficar
   visível.
2. **Cache curto no servidor**: a Netlify Function mantém um cache em memória
   de 60 segundos (`TTL_MS` em `src/lib/pipeline.ts`) para não sobrecarregar a
   Planilha Google em picos de acesso, sem atrasar a atualização além da janela
   de 1 a 5 minutos pedida no prompt mestre.
3. **Atualização orientada a evento (opcional, recomendada)**: um gatilho
   `onFormSubmit` no Google Apps Script pode chamar
   `/api/revalidar?token=SEU_TOKEN` imediatamente após cada nova resposta,
   forçando a invalidação do cache sem esperar o próximo ciclo periódico.

### Script de Apps Script sugerido (onFormSubmit)

No editor de Apps Script vinculado ao formulário (Extensões → Apps Script):

```javascript
function aoReceberResposta(e) {
  var urlRevalidar = "https://SEU-SITE.netlify.app/api/revalidar?token=SEU_TOKEN";
  UrlFetchApp.fetch(urlRevalidar, { muteHttpExceptions: true });
}
```

Configure o gatilho instalável: **Gatilhos → Adicionar gatilho → Escolher
função `aoReceberResposta` → Evento "Ao enviar formulário"**. Defina
`REVALIDATE_TOKEN` nas variáveis de ambiente do Netlify com o mesmo valor usado
na URL acima — sem essa variável configurada, o endpoint aceita qualquer
chamada (aceitável porque ele não grava nem expõe dados, apenas força nova
leitura da fonte pública).

## Configuração alternativa: planilha restrita (Google Sheets API)

Se a publicação em CSV for desativada no futuro, a camada de integração está
isolada em `src/lib/pipeline.ts` (função `obterLinhasBrutas`), preparada para
ser adaptada para usar a Google Sheets API com uma conta de serviço somente
leitura:

1. Criar uma conta de serviço no Google Cloud, com acesso de leitura à planilha.
2. Armazenar `GOOGLE_SERVICE_ACCOUNT_EMAIL` e `GOOGLE_SERVICE_ACCOUNT_KEY`
   exclusivamente nas variáveis de ambiente do Netlify (nunca no código-fonte
   ou no repositório).
3. Substituir a chamada `fetch(url)` por uma chamada autenticada à Sheets API
   (`spreadsheets.values.get`), mantendo o restante do pipeline (limpeza,
   anonimização, cache) inalterado.

## Garantias de privacidade

- A Netlify Function nunca devolve a planilha bruta — apenas o objeto já
  transformado (`DatasetPainel`).
- O campo "Responsável pelo preenchimento" é descartado na transformação e
  nunca chega ao navegador (ver `docs/metodologia.md`, seção 9).
- Não há cache persistente de dados pessoais: o cache em memória guarda apenas
  o resultado já anonimizado.
