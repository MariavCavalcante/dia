# Dicionário de dados

Gerado automaticamente por `scripts/gerar-dicionario.py` a partir de
`scripts/fixtures/planilha-referencia.csv` (172 respostas, coletadas entre
11/05/2026 e 29/07/2026). Cada linha relaciona a coluna original da planilha a
eixo, indicador, tipo, unidade, regra de limpeza e visualização recomendada —
exigência da seção 2.3 do prompt mestre. Para reexecutar após uma mudança de
estrutura na planilha: `python3 scripts/gerar-dicionario.py`.

**Total de campos analíticos mapeados:** 123 (de 174 colunas originais;
as demais estão integralmente vazias na base analisada e foram excluídas da
camada analítica, sem alteração do arquivo-fonte).

## Identificação (6 campos)

| Chave | Indicador | Grupo | Tipo | Unidade | Regra de limpeza | Visualização |
|---|---|---|---|---|---|---|
| `carimbo` | Carimbo de data/hora | — | data | — | Referência de inclusão e ordenação; linhas sem carimbo são descartadas. | — |
| `municipio` | Município | — | texto | — | Normalizar espaços/capitalização apenas na apresentação; manter original para auditoria. | Ranking, busca |
| `responsavel_preenchimento` | Responsável pelo preenchimento | — | texto_pessoal | — | Dado pessoal. Nunca exposto no painel público, em exportações, tooltips ou URLs. | — |
| `unidade` | Nome da Unidade de Saúde | — | texto | — | Normalizar espaços/capitalização na apresentação; validar preferencialmente pelo CNES. | Busca, tabela |
| `cnes` | Número do CNES | — | texto | — | Tratado como texto; remove sufixo decimal do Excel sem eliminar zeros à esquerda; sinaliza dígitos atípicos. | Busca, tabela |
| `classificacao` | Classificação do Estabelecimento | — | categoria | — | 'Opção 8' é categoria residual sinalizada para revisão institucional. | Distribuição (barras/rosca) |

## Leitos e capacidade instalada (8 campos)

| Chave | Indicador | Grupo | Tipo | Unidade | Regra de limpeza | Visualização |
|---|---|---|---|---|---|---|
| `leitos_sus_cirurgico` | Leitos operacionais SUS — Cirúrgico | Cirúrgico | numero | leitos | Soma de valores numéricos válidos; zero é valor válido. | Ranking, divergência |
| `leitos_sus_clinico` | Leitos operacionais SUS — Clinico | Clinico | numero | leitos | Soma de valores numéricos válidos; zero é valor válido. | Ranking, divergência |
| `leitos_sus_obstetrico` | Leitos operacionais SUS — Obstétrico | Obstétrico | numero | leitos | Soma de valores numéricos válidos; zero é valor válido. | Ranking, divergência |
| `leitos_sus_pediatrico` | Leitos operacionais SUS — Pediátrico | Pediátrico | numero | leitos | Soma de valores numéricos válidos; zero é valor válido. | Ranking, divergência |
| `leitos_cnes_cirurgico` | Leitos cadastrados no CNES — Cirúrgico | Cirúrgico | numero | leitos | Soma de valores numéricos válidos; zero é valor válido. | Ranking, divergência |
| `leitos_cnes_clinico` | Leitos cadastrados no CNES — Clinico | Clinico | numero | leitos | Soma de valores numéricos válidos; zero é valor válido. | Ranking, divergência |
| `leitos_cnes_obstetrico` | Leitos cadastrados no CNES — Obstétrico | Obstétrico | numero | leitos | Soma de valores numéricos válidos; zero é valor válido. | Ranking, divergência |
| `leitos_cnes_pediatrico` | Leitos cadastrados no CNES — Pediátrico | Pediátrico | numero | leitos | Soma de valores numéricos válidos; zero é valor válido. | Ranking, divergência |

## Sala de emergência e equipamentos (16 campos)

| Chave | Indicador | Grupo | Tipo | Unidade | Regra de limpeza | Visualização |
|---|---|---|---|---|---|---|
| `equip_leitos_sala_emergencia` | Leitos | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_pontos_oxigenio` | Pontos de Oxigênio (Rede/Fluxômetro) | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_pontos_vacuo` | Pontos de Vácuo (Rede/Vacuômetro) | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_pontos_ar_comprimido` | Pontos de Ar Comprimido Medicinal | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_cilindros_o2_transporte` | Cilindros de O2 de Transporte (Carga Cheia) | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_cilindros_reserva` | Cilindros de Reserva | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_tomadas_emergencia` | Tomadas de Emergência (mín. 4 por leito) | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_monitor_multiparametrico` | Monitor Multiparamétrico (com ECG, Oximetria, PNI) | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_ventilador_mecanico` | Ventilador Mecânico Pulmonar (VMP) | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_desfibrilador` | Desfibrilador / Cardioversor com Bateria e Pás | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_bomba_infusao` | Bomba de Infusão (mínimo 02 por leito) | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_carro_emergencia` | Carro de Emergência (Lacrado e Conferido) | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_aspirador_secrecoes` | Aspirador de Secreções (Portátil ou de Parede) | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_kit_laringoscopio` | Kit Laringoscópio Completo (Cabos e Lâminas) | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_ambu` | Ambu (Bolsa-Válvula-Máscara) com reservatório | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |
| `equip_estetoscopio_esfigmomanometro` | Estetoscópio e Esfigmomanômetro | — | numero | unidades | Disponibilidade = quantidade > 0. Percentual usa como denominador unidades com resposta válida. | Matriz de disponibilidade, barras |

## Diagnóstico por imagem (20 campos)

| Chave | Indicador | Grupo | Tipo | Unidade | Regra de limpeza | Visualização |
|---|---|---|---|---|---|---|
| `img_tomografia_quantidade` | Tomografia | Quantidade | numero | aparelhos | Zero é valor válido (unidade sem aparelho). | Barras |
| `img_tomografia_funcionamento` | Tomografia | Funcionamento | categoria | — | Categórico; 'Não possui' tratado como ausência de serviço. | Barras empilhadas |
| `img_tomografia_laudos` | Tomografia | Emissão de laudos | categoria | — | Categórico; usado para calcular ausência de serviço. | Barras empilhadas |
| `img_tomografia_local` | Tomografia | Local de instalação | categoria | — | Separa oferta própria, oferta em outra unidade e ausência de serviço. | Barras empilhadas |
| `img_ressonancia_quantidade` | Ressonância | Quantidade | numero | aparelhos | Zero é valor válido (unidade sem aparelho). | Barras |
| `img_ressonancia_funcionamento` | Ressonância | Funcionamento | categoria | — | Categórico; 'Não possui' tratado como ausência de serviço. | Barras empilhadas |
| `img_ressonancia_laudos` | Ressonância | Emissão de laudos | categoria | — | Categórico; usado para calcular ausência de serviço. | Barras empilhadas |
| `img_ressonancia_local` | Ressonância | Local de instalação | categoria | — | Separa oferta própria, oferta em outra unidade e ausência de serviço. | Barras empilhadas |
| `img_angiografo_quantidade` | Angiógrafo | Quantidade | numero | aparelhos | Zero é valor válido (unidade sem aparelho). | Barras |
| `img_angiografo_funcionamento` | Angiógrafo | Funcionamento | categoria | — | Categórico; 'Não possui' tratado como ausência de serviço. | Barras empilhadas |
| `img_angiografo_laudos` | Angiógrafo | Emissão de laudos | categoria | — | Categórico; usado para calcular ausência de serviço. | Barras empilhadas |
| `img_angiografo_local` | Angiógrafo | Local de instalação | categoria | — | Separa oferta própria, oferta em outra unidade e ausência de serviço. | Barras empilhadas |
| `img_usg_doppler_quantidade` | USG com Doppler | Quantidade | numero | aparelhos | Zero é valor válido (unidade sem aparelho). | Barras |
| `img_usg_doppler_funcionamento` | USG com Doppler | Funcionamento | categoria | — | Categórico; 'Não possui' tratado como ausência de serviço. | Barras empilhadas |
| `img_usg_doppler_laudos` | USG com Doppler | Emissão de laudos | categoria | — | Categórico; usado para calcular ausência de serviço. | Barras empilhadas |
| `img_usg_doppler_local` | USG com Doppler | Local de instalação | categoria | — | Separa oferta própria, oferta em outra unidade e ausência de serviço. | Barras empilhadas |
| `img_raio_x_quantidade` | Aparelho de RX | Quantidade | numero | aparelhos | Zero é valor válido (unidade sem aparelho). | Barras |
| `img_raio_x_funcionamento` | Aparelho de RX | Funcionamento | categoria | — | Categórico; 'Não possui' tratado como ausência de serviço. | Barras empilhadas |
| `img_raio_x_laudos` | Aparelho de RX | Emissão de laudos | categoria | — | Categórico; usado para calcular ausência de serviço. | Barras empilhadas |
| `img_raio_x_local` | Aparelho de RX | Local de instalação | categoria | — | Separa oferta própria, oferta em outra unidade e ausência de serviço. | Barras empilhadas |

## Especialidades médicas (45 campos)

| Chave | Indicador | Grupo | Tipo | Unidade | Regra de limpeza | Visualização |
|---|---|---|---|---|---|---|
| `esp_clinica_medica_plantao24h` | Clínica Médica | Plantão 24h | misto_numero_texto | — | Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza. | Barras, lacunas |
| `esp_clinica_medica_presencial` | Clínica Médica | Presencial | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_clinica_medica_sobreaviso` | Clínica Médica | Sobreaviso | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_clinica_medica_telemedicina` | Clínica Médica | Telemedicina | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_clinica_medica_carga_horaria` | Clínica Médica | Carga horária | duracao_texto | — | Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência. | Tabela, carga horária por especialidade |
| `esp_pediatria_plantao24h` | Pediatria | Plantão 24h | misto_numero_texto | — | Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza. | Barras, lacunas |
| `esp_pediatria_presencial` | Pediatria | Presencial | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_pediatria_sobreaviso` | Pediatria | Sobreaviso | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_pediatria_telemedicina` | Pediatria | Telemedicina | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_pediatria_carga_horaria` | Pediatria | Carga horária | duracao_texto | — | Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência. | Tabela, carga horária por especialidade |
| `esp_cirurgia_geral_plantao24h` | Cirurgia Geral | Plantão 24h | misto_numero_texto | — | Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza. | Barras, lacunas |
| `esp_cirurgia_geral_presencial` | Cirurgia Geral | Presencial | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_cirurgia_geral_sobreaviso` | Cirurgia Geral | Sobreaviso | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_cirurgia_geral_telemedicina` | Cirurgia Geral | Telemedicina | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_cirurgia_geral_carga_horaria` | Cirurgia Geral | Carga horária | duracao_texto | — | Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência. | Tabela, carga horária por especialidade |
| `esp_ginecologia_obstetricia_plantao24h` | Ginecologia/Obstetrícia | Plantão 24h | misto_numero_texto | — | Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza. | Barras, lacunas |
| `esp_ginecologia_obstetricia_presencial` | Ginecologia/Obstetrícia | Presencial | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_ginecologia_obstetricia_sobreaviso` | Ginecologia/Obstetrícia | Sobreaviso | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_ginecologia_obstetricia_telemedicina` | Ginecologia/Obstetrícia | Telemedicina | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_ginecologia_obstetricia_carga_horaria` | Ginecologia/Obstetrícia | Carga horária | duracao_texto | — | Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência. | Tabela, carga horária por especialidade |
| `esp_neurocirurgia_plantao24h` | Neurocirurgia | Plantão 24h | misto_numero_texto | — | Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza. | Barras, lacunas |
| `esp_neurocirurgia_presencial` | Neurocirurgia | Presencial | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_neurocirurgia_sobreaviso` | Neurocirurgia | Sobreaviso | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_neurocirurgia_telemedicina` | Neurocirurgia | Telemedicina | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_neurocirurgia_carga_horaria` | Neurocirurgia | Carga horária | duracao_texto | — | Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência. | Tabela, carga horária por especialidade |
| `esp_cardiologia_plantao24h` | Cardiologia | Plantão 24h | misto_numero_texto | — | Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza. | Barras, lacunas |
| `esp_cardiologia_presencial` | Cardiologia | Presencial | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_cardiologia_sobreaviso` | Cardiologia | Sobreaviso | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_cardiologia_telemedicina` | Cardiologia | Telemedicina | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_cardiologia_carga_horaria` | Cardiologia | Carga horária | duracao_texto | — | Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência. | Tabela, carga horária por especialidade |
| `esp_cirurgia_vascular_plantao24h` | Cirurgia Vascular | Plantão 24h | misto_numero_texto | — | Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza. | Barras, lacunas |
| `esp_cirurgia_vascular_presencial` | Cirurgia Vascular | Presencial | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_cirurgia_vascular_sobreaviso` | Cirurgia Vascular | Sobreaviso | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_cirurgia_vascular_telemedicina` | Cirurgia Vascular | Telemedicina | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_cirurgia_vascular_carga_horaria` | Cirurgia Vascular | Carga horária | duracao_texto | — | Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência. | Tabela, carga horária por especialidade |
| `esp_ortopedia_plantao24h` | Ortopedia | Plantão 24h | misto_numero_texto | — | Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza. | Barras, lacunas |
| `esp_ortopedia_presencial` | Ortopedia | Presencial | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_ortopedia_sobreaviso` | Ortopedia | Sobreaviso | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_ortopedia_telemedicina` | Ortopedia | Telemedicina | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_ortopedia_carga_horaria` | Ortopedia | Carga horária | duracao_texto | — | Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência. | Tabela, carga horária por especialidade |
| `esp_urologia_plantao24h` | Urologia | Plantão 24h | misto_numero_texto | — | Campo misto: valores numéricos e 'Não dispõe da especialidade' separados na limpeza. | Barras, lacunas |
| `esp_urologia_presencial` | Urologia | Presencial | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_urologia_sobreaviso` | Urologia | Sobreaviso | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_urologia_telemedicina` | Urologia | Telemedicina | numero | profissionais | Numérico; zero é valor válido. | Barras empilhadas por regime |
| `esp_urologia_carga_horaria` | Urologia | Carga horária | duracao_texto | — | Texto de duração (ex.: '12h'); 'Não dispõe da especialidade' tratado como ausência. | Tabela, carga horária por especialidade |

## Capacidade de resposta clínica (13 campos)

| Chave | Indicador | Grupo | Tipo | Unidade | Regra de limpeza | Visualização |
|---|---|---|---|---|---|---|
| `cv_trombolise` | Realiza Trombólise | Cardiovascular | categoria | — | Categórico institucional. | Semáforo, barras |
| `cv_hemodinamica` | Hemodinâmica (Cineangiocoronariografia) | Cardiovascular | categoria | — | Categórico institucional. | Semáforo, barras |
| `cv_angioplastia` | Realiza Angioplastia Primária (24h) | Cardiovascular | categoria | — | Categórico institucional. | Semáforo, barras |
| `avc_protocolo_trombolise` | Protocolo de trombólise para AVC isquêmico com neuroimagem 24h | AVC / DRC | categoria | — | Categórico institucional. | Semáforo |
| `drc_hemodialise_uti` | Hemodiálise em ambiente de UTI | AVC / DRC | categoria | — | Categórico institucional. | Semáforo |
| `drc_hemodialise_internacao` | Hemodiálise em unidades de internação/enfermaria | AVC / DRC | categoria | — | Categórico institucional. | Semáforo |
| `sm_leitos_especificos` | Leitos específicos para Saúde Mental | Saúde mental | sim_nao | — | Sim/Não. | Semáforo |
| `sm_protocolo_crise` | Protocolo para crises/surtos psicóticos | Saúde mental | sim_nao | — | Sim/Não. | Semáforo |
| `maternidade_perfil` | Perfil da maternidade/centro obstétrico | Maternidade | categoria | — | Categórico institucional. | Distribuição |
| `incubadora_transporte` | Incubadora de transporte com ventilador mecânico | Maternidade | sim_nao | — | Sim/Não. | Semáforo |
| `leite_banco` | Banco de Leite Humano | Leite humano | sim_nao | — | Sim/Não. | Semáforo |
| `leite_posto` | Posto de Coleta de Leite Humano | Leite humano | sim_nao | — | Sim/Não. | Semáforo |
| `leite_nenhum` | Sem estrutura específica de apoio ao leite humano | Leite humano | sim_nao | — | Sim/Não. | Semáforo |

## Regulação, superlotação e transferências (8 campos)

| Chave | Indicador | Grupo | Tipo | Unidade | Regra de limpeza | Visualização |
|---|---|---|---|---|---|---|
| `nir_ativo` | Núcleo Interno de Regulação (NIR) ativo | — | sim_nao | — | Sim/Não. | Semáforo |
| `vaga_zero_frequencia` | Frequência média diária de "Vaga Zero" | — | numero | pacientes/dia | Numérico (remove zeros à esquerda tipo '00'/'01'); valores extremos (ex.: >100) sinalizados para revisão, não removidos. | Distribuição, alerta de outlier |
| `vaga_zero_corredor` | Pacientes em "Vaga Zero" aguardando em corredores | — | numero | pacientes/dia | Numérico (remove zeros à esquerda); valores extremos sinalizados para revisão. | Distribuição, alerta de outlier |
| `tempo_retencao_maca` | Tempo médio de retenção de maca (SAMU/Bombeiros) | — | categoria | — | Categórico ordinal por faixa de tempo. | Barras ordenadas |
| `tempo_espera_uti` | Tempo médio de espera por leito de UTI | — | categoria | — | Categórico ordinal por faixa de tempo. | Barras ordenadas |
| `tempo_espera_retaguarda` | Tempo médio de espera por leito de retaguarda (pós Sala Vermelha) | — | categoria | — | Categórico ordinal por faixa de tempo. | Barras ordenadas |
| `plano_contingencia` | Plano de Contingência para Superlotação | — | categoria | — | Categórico (inclui estado intermediário 'Em elaboração'). | Semáforo (3 estados) |
| `disponibilidade_ambulancia` | Disponibilidade de ambulância para transferência | — | categoria | — | Categórico institucional. | Distribuição |

## Trauma e suportes estratégicos (7 campos)

| Chave | Indicador | Grupo | Tipo | Unidade | Regra de limpeza | Visualização |
|---|---|---|---|---|---|---|
| `trauma_centro_cirurgico` | Centro Cirúrgico Equipado | Trauma | categoria | — | Categórico institucional. | Semáforo |
| `trauma_cirurgiao_geral` | Cirurgião Geral | Trauma | categoria | — | Categórico institucional. | Semáforo |
| `trauma_ortopedista` | Ortopedista | Trauma | categoria | — | Categórico institucional. | Semáforo |
| `trauma_neurocirurgiao` | Neurocirurgião | Trauma | categoria | — | Categórico institucional. | Semáforo |
| `trauma_anestesiologista` | Anestesiologista | Trauma | categoria | — | Categórico institucional. | Semáforo |
| `suporte_hemoterapico` | Estrutura de suporte hemoterápico 24h | Suporte estratégico | categoria | — | Categórico institucional. | Distribuição |
| `heliporto_ativo` | Ponto de Pouso/Heliporto homologado ANAC (ativo) | Suporte estratégico | sim_nao | — | Sim/Não. | Semáforo |

## Campos de identificação (fora da camada de indicadores agregados)

| Chave | Coluna original | Tipo | Regra |
|---|---|---|---|
| `carimbo` | Carimbo de data/hora | data | Referência de inclusão e ordenação; linhas sem carimbo são descartadas. |
| `municipio` | Município | texto | Normalizar espaços/capitalização apenas na apresentação; manter original para auditoria. |
| `responsavel_preenchimento` | Responsável pelo preenchimento | texto_pessoal | Dado pessoal. Nunca exposto no painel público, em exportações, tooltips ou URLs. |
| `unidade` | Nome da Unidade de Saúde | texto | Normalizar espaços/capitalização na apresentação; validar preferencialmente pelo CNES. |
| `cnes` | Número do CNES | texto | Tratado como texto; remove sufixo decimal do Excel sem eliminar zeros à esquerda; sinaliza dígitos atípicos. |
| `classificacao` | Classificação do Estabelecimento | categoria | 'Opção 8' é categoria residual sinalizada para revisão institucional. |

> O campo `responsavel_preenchimento` (Responsável pelo preenchimento) é dado
> pessoal: é lido apenas para fins de auditoria interna e **nunca** é incluído no
> JSON anonimizado devolvido pela Netlify Function nem em qualquer exportação.
